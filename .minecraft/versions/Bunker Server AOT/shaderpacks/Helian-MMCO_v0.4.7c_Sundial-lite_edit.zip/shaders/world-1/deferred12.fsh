#version 330 compatibility

#define BASIC_LIGHT 1e-1

#include "/programs/deferred/Deferred12.frag"
