#version 450

#define ENTITIES

#include "/programs/gbuffers/Textured.vert"
