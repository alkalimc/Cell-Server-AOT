#version 450

#define EMISSIVE
#define ENTITIES

#include "/programs/gbuffers/Textured.frag"
