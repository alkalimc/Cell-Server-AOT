#version 450

#define SHADOW_AND_SKY

#include "/programs/gbuffers/Shadow.frag"
