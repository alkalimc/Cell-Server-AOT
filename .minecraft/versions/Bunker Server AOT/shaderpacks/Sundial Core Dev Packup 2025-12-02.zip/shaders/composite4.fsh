#version 450

#include "/programs/composite/Composite4.frag"
