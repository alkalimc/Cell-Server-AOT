#version 450

#include "/programs/composite/Composite6.comp"
