#version 450

#include "/programs/deferred/Deferred15.frag"
