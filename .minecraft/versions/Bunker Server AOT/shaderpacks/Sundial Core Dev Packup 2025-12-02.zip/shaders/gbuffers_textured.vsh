#version 450

#define PARTICLE

#include "/programs/gbuffers/Textured.vert"
