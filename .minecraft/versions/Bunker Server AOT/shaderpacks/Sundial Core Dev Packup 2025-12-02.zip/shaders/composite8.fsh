#version 450

#include "/programs/composite/Composite8.frag"
