in vec3 vaPosition;
in vec4 vaColor;
in vec2 vaUV0;
in ivec2 vaUV2;
in vec3 vaNormal;
in vec4 mc_midTexCoord;

// #define GLOWING_OVERLAY

out vec4 color;
out vec4 viewPos;
out vec4 texlmcoord;
out vec3 mcPos;

flat out float materialID;
flat out vec4 coordRange;

uniform vec3 chunkOffset;
uniform mat4 modelViewMatrix;
uniform mat4 projectionMatrix;
uniform mat4 textureMatrix = mat4(1.0);

#ifdef ENTITIES
    uniform vec4 entityColor;
#endif

uniform sampler2D gaux1;

#include "/settings/GlobalSettings.glsl"
#include "/libs/Uniform.glsl"
#include "/libs/Materials.glsl"
#include "/libs/Common.glsl"

void main() {
    viewPos = modelViewMatrix * vec4(vaPosition + chunkOffset, 1.0);
    mcPos = (gbufferModelViewInverse * viewPos).xyz + cameraPosition;

    gl_Position = projectionMatrix * viewPos;
    color = vaColor;
    texlmcoord.st = vec2(textureMatrix * vec4(vaUV0, 0.0, 1.0));
    texlmcoord.pq = vaUV2 / 240.0;
    materialID = MAT_OPAQUE;

    vec2 albedoTexSize = vec2(textureSize(gtexture, 0));
    bool clampCoord = textureSize(gaux1, 0) == albedoTexSize;
    #ifdef MC_ANISOTROPIC_FILTERING
        clampCoord = (spriteBounds.zw - spriteBounds.xy) * textureSize(gaux1, 0) == albedoTexSize;
    #endif
    vec2 minCoord = vec2(0.0);
    vec2 coordSize = vec2(1.0);
    #ifndef COLORWHEEL
    if (clampCoord) {
        vec2 vertexCoord = vaUV0.st;
        if (min(abs(mc_midTexCoord.s - vaUV0.s), abs(mc_midTexCoord.t - vaUV0.t)) < 1e-6) {
            vec2 vertexCoord = vaUV0.st + (mc_midTexCoord.st - vaUV0.st).ts;
        }
        vec2 coordToCenter = abs(vertexCoord - mc_midTexCoord.st);
        minCoord = mc_midTexCoord.st - coordToCenter;
        coordSize = coordToCenter * 2.0;
    }
    #endif
    coordRange = vec4(minCoord, coordSize);

    #ifdef ENTITIES
        color.rgb = mix(color.rgb, entityColor.rgb, vec3(entityColor.a));
    #endif

    #ifdef GLOWING
        #ifdef GLOWING_OVERLAY
            gl_Position.z = (gl_Position.z * 0.5 + 0.5) * 0.02 - 0.01;
        #endif
    #endif

    #ifdef OVERLAY
        gl_Position.z -= 1e-5;
    #endif

    #ifdef TAA
        gl_Position.xy += taaOffset * gl_Position.w;
    #endif

    #ifdef HAND
        materialID = MAT_HAND;
    #endif

    #ifdef PARTICLE
        materialID = MAT_PARTICLE;
    #endif
}
