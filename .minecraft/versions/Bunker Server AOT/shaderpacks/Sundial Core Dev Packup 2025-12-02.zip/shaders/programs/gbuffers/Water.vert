in vec3 vaPosition;
in vec4 vaColor;
in vec2 vaUV0;
in ivec2 vaUV2;
in vec3 vaNormal;
in vec4 mc_Entity;
in vec4 at_tangent;

out vec4 color;
out vec4 viewPos;
out vec4 texlmcoord;
out vec3 mcPos;
out vec3 worldNormal;
out mat3 tbnMatrix;

flat out float isEmissive;
flat out float materialID;

uniform vec3 chunkOffset;
uniform mat3 normalMatrix;
uniform mat4 modelViewMatrix;
uniform mat4 projectionMatrix;

#include "/settings/GlobalSettings.glsl"
#include "/libs/Uniform.glsl"
#include "/libs/Materials.glsl"
#include "/libs/PhysicsOcean.glsl"

#ifdef PHYSICS_OCEAN
    out vec3 physics_localPosition;
    out float physics_localWaviness;
#endif

void main() {
    vec3 worldPos = vaPosition + chunkOffset;
    #ifdef PHYSICS_OCEAN
        physics_localWaviness = texelFetch(physics_waviness, ivec2(worldPos.xz) - physics_textureOffset, 0).r;
        physics_localPosition = worldPos.xyz + vec3(0.0, physics_waveHeight(worldPos.xz, PHYSICS_ITERATIONS_OFFSET, physics_localWaviness, physics_gameTime), 0.0);

        viewPos = modelViewMatrix * vec4(physics_localPosition, 1.0);
    #else
        viewPos = modelViewMatrix * vec4(worldPos, 1.0);
    #endif
    mcPos = (gbufferModelViewInverse * viewPos).xyz + cameraPosition;

    gl_Position = projectionMatrix * viewPos;

    color = vaColor;
    texlmcoord.st = vaUV0;
    texlmcoord.pq = vaUV2 / 240.0;
    #ifdef IS_IRIS
        texlmcoord.pq = clamp(vaUV2 / 232.0 - 8.0 / 232.0, 0.0, 1.0);
    #endif

    isEmissive = floor(mc_Entity.x / 512.0);
    materialID = MAT_STAINED_GLASS;

    if (mc_Entity.x < -0.5) {
        // Used for MOD_LIGHT_DETECTION
        materialID = -1.0;
    }
    if (mc_Entity.x == 501) {
        materialID = MAT_WATER;
    }

    #ifdef MOD_WATER_DETECTION
        if (dot(gl_Color.rgb, vec3(1.0)) < 2.999 && mc_Entity.x < -0.5) {
            materialID = MAT_WATER;
        }
    #endif

    #ifdef TAA
        gl_Position.xy += taaOffset * gl_Position.w;
    #endif

    worldNormal = vaNormal;
    vec3 normal = normalize(normalMatrix * vaNormal);
    vec3 tangent = normalize(normalMatrix * at_tangent.xyz);
    vec3 bitangent = normalize(cross(tangent, normal) * at_tangent.w);
    tbnMatrix = mat3(tangent, bitangent, normal);
}
