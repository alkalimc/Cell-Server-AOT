in vec3 vaPosition;
in vec4 vaColor;
in vec2 vaUV0;
in vec3 vaNormal;

out vec4 color;
out vec2 texcoord;

uniform vec3 chunkOffset;
uniform mat4 modelViewMatrix;
uniform mat4 projectionMatrix;
uniform mat4 textureMatrix = mat4(1.0);

#include "/settings/GlobalSettings.glsl"
#include "/libs/Uniform.glsl"

void main() {
    color = vaColor;
    #ifdef TEXTURE_MATRIX
        texcoord = vec2(textureMatrix * vec4(vaUV0, 0.0, 1.0));
    #else
        texcoord = vaUV0;
    #endif
    gl_Position = (projectionMatrix * modelViewMatrix * vec4(vaPosition + chunkOffset, 1.0));
    #ifdef COLORWHEEL
        color = gl_Color;
        texcoord = (gl_TextureMatrix[0] * gl_MultiTexCoord0).st;
        gl_Position = ftransform();
    #endif

    #ifdef TAA
        gl_Position.xy += taaOffset * gl_Position.w;
    #endif
}
