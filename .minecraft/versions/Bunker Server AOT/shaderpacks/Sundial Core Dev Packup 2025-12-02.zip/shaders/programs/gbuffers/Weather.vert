in vec3 vaPosition;
in vec4 vaColor;
in vec2 vaUV0;

out vec4 color;
out vec3 worldPos;
out vec2 texcoord;

uniform mat4 modelViewMatrix;
uniform mat4 projectionMatrix;
uniform mat4 textureMatrix = mat4(1.0);

#include "/settings/GlobalSettings.glsl"
#include "/libs/Uniform.glsl"

vec3 viewToWorldPos(vec3 viewPos) {
    return mat3(gbufferModelViewInverse) * viewPos + gbufferModelViewInverse[3].xyz;
}

void main() {
    vec4 vertexPosition = vec4(vaPosition, 1.0);
    vec2 playerSpeed = cameraMovement.xz / frameTime;
    vertexPosition.xz += vaPosition.y * playerSpeed * 0.05;

    vec4 viewPos = modelViewMatrix * vertexPosition;
    worldPos = viewToWorldPos(viewPos.xyz);

    gl_Position = projectionMatrix * viewPos;
    color = vaColor;
    texcoord = vec2(textureMatrix * vec4(vaUV0, 0.0, 1.0));

    #ifdef TAA
        gl_Position.xy += taaOffset * gl_Position.w;
    #endif
}