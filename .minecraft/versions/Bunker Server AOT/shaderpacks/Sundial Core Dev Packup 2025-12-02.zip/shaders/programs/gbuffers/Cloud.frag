void main() {
    discard;
}