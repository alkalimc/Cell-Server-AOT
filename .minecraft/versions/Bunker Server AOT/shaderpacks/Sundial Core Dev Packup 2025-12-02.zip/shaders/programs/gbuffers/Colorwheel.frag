#extension GL_ARB_shading_language_packing : enable

layout(location = 0) out vec4 gbufferData0;
layout(location = 1) out vec4 gbufferData1;
layout(location = 2) out vec4 gbufferData2;

#if MC_VERSION < 11300
    in vec3 viewNormal;
    in mat3 tbnMatrix;
#endif

in vec4 color;
in vec4 viewPos;
in vec4 texlmcoord;
in vec3 mcPos;

flat in float materialID;
flat in vec4 coordRange;

#define ENTITY_TEXTURE_RESOLUTION 16 // [4 8 16 32 64 128 256 512 1024 2048 4096 8192]

#include "/settings/GlobalSettings.glsl"
#include "/libs/Uniform.glsl"
#include "/libs/GbufferData.glsl"
#include "/libs/Common.glsl"
#include "/libs/Parallax.glsl"
#include "/libs/GbufferPass.glsl"

#if defined PARTICLE && defined ENTITY_PARALLAX
    #undef ENTITY_PARALLAX
#endif

vec2 calcTextureScale(vec2 dCoordDX, vec2 dCoordDY, vec3 position) {
    vec3 dPosDX = dFdx(position);
    vec3 dPosDY = dFdy(position);

    vec3 normal = cross(dPosDX, dPosDY);
    normal *= signI(-dot(normal, position)) * inversesqrt(dot(normal, normal));

    vec3 dPosPerpX = cross(normal, dPosDX);
    vec3 dPosPerpY = cross(dPosDY, normal);

    dPosPerpX /= dot(dPosDY, dPosPerpX);
    dPosPerpY /= dot(dPosDX, dPosPerpY);

    vec3 tangent = dPosPerpY * dCoordDX.x + dPosPerpX * dCoordDY.x;
    vec3 bitangent = dPosPerpY * dCoordDX.y + dPosPerpX * dCoordDY.y;

    float tangentLen = length(tangent);
    float bitangentLen = length(bitangent);

    vec2 textureScale = vec2(tangentLen, bitangentLen);

    return textureScale;
}

mat3 calcTbnMatrix(vec2 dCoordDX, vec2 dCoordDY, vec3 position, out vec3 normal, out vec2 textureScale) {
    vec3 dPosDX = dFdx(position);
    vec3 dPosDY = dFdy(position);

    normal = normalize(cross(dPosDX, dPosDY));

    vec3 dPosPerpX = cross(normal, dPosDX);
    vec3 dPosPerpY = cross(dPosDY, normal);

    dPosPerpX /= dot(dPosDY, dPosPerpX);
    dPosPerpY /= dot(dPosDX, dPosPerpY);

    vec3 tangent = dPosPerpY * dCoordDX.x + dPosPerpX * dCoordDY.x;
    vec3 bitangent = dPosPerpY * dCoordDX.y + dPosPerpX * dCoordDY.y;

    float tangentLen = inversesqrt(dot(tangent, tangent));
    float bitangentLen = inversesqrt(dot(bitangent, bitangent));

    textureScale = 1.0 / vec2(tangentLen, bitangentLen);

    return mat3(tangent * tangentLen, bitangent * bitangentLen, normal);
}

void main() {
    GbufferData rawData;

    vec2 texcoord = texlmcoord.st;
    vec2 texGradX = dFdx(texcoord);
    vec2 texGradY = dFdy(texcoord);
    vec2 textureScale;
    #if MC_VERSION >= 11300
        vec3 viewNormal;
        mat3 tbnMatrix = calcTbnMatrix(texGradX, texGradY, viewPos.xyz, viewNormal, textureScale);
    #else
        textureScale = calcTextureScale(texGradX, texGradY, viewPos.xyz);
    #endif
    float viewDepthInv = inversesqrt(dot(viewPos.xyz, viewPos.xyz));
    vec3 viewDir = viewPos.xyz * (-viewDepthInv);

    rawData.lightmap = texlmcoord.pq;
    rawData.geoNormal = viewNormal;
    rawData.normal = viewNormal;
    rawData.materialID = materialID;
    rawData.parallaxOffset = 0.0;
    rawData.depth = 0.0;

    vec2 albedoTexSize = vec2(textureSize(gtexture, 0));
    vec2 albedoTexelSize = 1.0 / albedoTexSize;
    int textureResolutionFixed = (floatBitsToInt(max(textureScale.x * albedoTexSize.x, textureScale.y * albedoTexSize.y)) & 0x7FC00000) >> 22;
    textureResolutionFixed = ((textureResolutionFixed >> 1) + (textureResolutionFixed & 1)) - 0x0000007F;
    textureResolutionFixed = 1 << textureResolutionFixed;
    float parallaxScale = float(textureResolutionFixed) / ENTITY_TEXTURE_RESOLUTION;
    vec2 pixelScale = albedoTexelSize * parallaxScale / textureScale;
    vec2 quadSize = 1.0 / coordRange.zw;
    #if (defined ENTITY_PARALLAX && defined PARALLAX) || ANISOTROPIC_FILTERING_QUALITY > 0
        #ifdef ENTITY_PARALLAX
            #ifdef PARALLAX
                float parallaxOffset = 0.0;
                vec3 parallaxTexNormal = vec3(0.0, 0.0, 1.0);
                vec3 textureViewer = -viewDir * tbnMatrix;
                textureViewer.xy *= textureScale / parallaxScale;
                #ifdef VOXEL_PARALLAX
                    texcoord = perPixelParallax(
                        texcoord, textureViewer, albedoTexSize, albedoTexelSize, coordRange, parallaxTexNormal, parallaxOffset
                    );
                #else
                    texcoord = calculateParallax(texcoord, textureViewer, coordRange, quadSize, albedoTexSize, albedoTexelSize, parallaxOffset);
                #endif
                rawData.parallaxOffset = clamp(parallaxOffset / parallaxScale, 0.0, 1.0);
            #endif
        #endif
    #endif

    #if ANISOTROPIC_FILTERING_QUALITY > 0 && !defined PARTICLE && !defined MC_ANISOTROPIC_FILTERING
        vec4 texAlbedo = anisotropicFilter(texcoord, albedoTexSize, albedoTexelSize, texGradX, texGradY, coordRange, quadSize);
    #else
        vec4 texAlbedo = textureGrad(gtexture, texcoord, texGradX, texGradY);
    #endif
    #ifdef MC_NORMAL_MAP
        vec2 grad = min(abs(texGradX) , abs(texGradY));
        vec4 normalData = textureGrad(normals, texcoord, grad, grad);
        #ifdef LABPBR_TEXTURE_AO
            texAlbedo.rgb *= pow(normalData.b, 1.0 / 2.2);
        #endif
    #endif
    vec4 albedoData = color * texAlbedo;
    float ao;
    vec4 overlayColor;
    clrwl_computeFragment(albedoData, albedoData, rawData.lightmap, ao, overlayColor);
    albedoData.rgb = mix(albedoData.rgb, overlayColor.rgb, overlayColor.a);

    if (albedoData.w < 0.001) discard;

    rawData.albedo = albedoData;
    rawData.smoothness = 0.0;
    rawData.metalness = 0.0;
    rawData.porosity = 0.0;
    rawData.emissive = 0.0;

    #ifdef MC_SPECULAR_MAP
        vec4 specularData = texture(specular, texcoord);
        SPECULAR_FORMAT(rawData, specularData);
    #endif

    #ifndef SPECULAR_EMISSIVE
        rawData.emissive = 0.0;
    #endif

    #ifndef LABPBR_POROSITY
        rawData.porosity = 0.0;
    #endif

    float wetStrength = 0.0;
    vec3 rippleNormal = vec3(0.0, 0.0, 1.0);
    if (rainyStrength > 0.0) {
        float porosity = rawData.porosity * 255.0 / 64.0;
        porosity *= step(porosity, 1.0);
        float outdoor = clamp(15.0 * rawData.lightmap.y - 14.0, 0.0, 1.0);

        float porosityDarkness = porosity * outdoor * rainyStrength;
        rawData.albedo.rgb = pow(rawData.albedo.rgb, vec3(1.0 + porosityDarkness)) * (1.0 - 0.2 * porosityDarkness);

        vec3 worldNormal = mat3(gbufferModelViewInverse) * rawData.geoNormal;
        #if RAIN_PUDDLE == 0 || !defined USE_RAIN_PUDDLE
        #elif RAIN_PUDDLE == 1
            wetStrength = (1.0 - rawData.metalness) * clamp(worldNormal.y * 10.0 - 0.1, 0.0, 1.0) * outdoor * rainyStrength * (1.0 - porosity);
        #elif RAIN_PUDDLE == 2
            wetStrength = groundWetStrength(mcPos, worldNormal.y, rawData.metalness, porosity, outdoor);
        #endif
        rawData.smoothness += (1.0 - rawData.smoothness) * wetStrength;

        #ifdef RAIN_RIPPLES
            rippleNormal = rainRippleNormal(mcPos);
            rippleNormal.xy *= viewDepthInv / (viewDepthInv + 0.1 * RIPPLE_FADE_SPEED);
        #endif
    }

    vec2 quadTexelSize = albedoTexelSize * quadSize;
    #if (defined PARALLAX_BASED_NORMAL) || (defined VOXEL_PARALLAX)
        #if defined ENTITY_PARALLAX && defined PARALLAX
            if (rawData.parallaxOffset > 0.0
                #ifdef VOXEL_PARALLAX
                    && parallaxTexNormal.z < 0.5
                #endif
            ) {
                #ifdef VOXEL_PARALLAX
                    rawData.normal = tbnMatrix * parallaxTexNormal;
                #else
                    #ifdef SMOOTH_PARALLAX
                        rawData.normal = heightBasedNormal(normals, texcoord, coordRange, quadTexelSize, albedoTexSize, pixelScale);
                    #else
                        const float eps = 1e-4;
                        vec2 tileCoord = (texcoord - coordRange.xy) * quadTexelSize;
                        float rD = textureGrad(normals, clampCoordRange(tileCoord + vec2(eps * quadTexelSize.x, 0.0), coordRange), grad, grad).a;
                        float lD = textureGrad(normals, clampCoordRange(tileCoord - vec2(eps * quadTexelSize.x, 0.0), coordRange), grad, grad).a;
                        float uD = textureGrad(normals, clampCoordRange(tileCoord + vec2(0.0, eps * quadTexelSize.y), coordRange), grad, grad).a;
                        float dD = textureGrad(normals, clampCoordRange(tileCoord - vec2(0.0, eps * quadTexelSize.y), coordRange), grad, grad).a;
                        rawData.normal = vec3((lD - rD), (dD - uD), step(abs(lD - rD) + abs(dD - uD), 1e-3));
                    #endif
                    rawData.normal = mix(rawData.normal, rippleNormal, wetStrength);
                    rawData.normal = normalize(tbnMatrix * rawData.normal);
                #endif
                texGradX *= albedoTexSize;
                texGradY *= albedoTexSize;
                rawData.normal = normalize(mix(rawData.geoNormal, rawData.normal, exp2(-sqrt(dot(vec4(texGradX, texGradY), vec4(texGradX, texGradY))))));
            } else
        #endif
    #endif
    {
        #ifdef SMOOTH_NORMAL
            normalData = bilinearNormalSample(normals, texcoord, coordRange, quadTexelSize, albedoTexSize);
        #endif
        #ifdef MC_NORMAL_MAP
            rawData.normal = NORMAL_FORMAT(normalData.xyz);
            rawData.normal.xy *= NORMAL_STRENGTH;
        #else
            rawData.normal = vec3(0.0, 0.0, 1.0);
        #endif
        rawData.normal = mix(rawData.normal, rippleNormal, wetStrength);
        rawData.normal = normalize(tbnMatrix * rawData.normal);

        float NdotV = dot(rawData.normal, viewDir) * inversesqrt(dot(rawData.normal, rawData.normal));
        vec3 edgeNormal = rawData.normal - viewDir * NdotV;
        float curveStart = dot(viewDir, rawData.geoNormal);
        float weight = clamp(curveStart - curveStart * exp(NdotV / curveStart - 1.0), 0.0, 1.0);
        weight = max(NdotV, curveStart) - weight;
        rawData.normal = viewDir * weight + edgeNormal * inversesqrt(dot(edgeNormal, edgeNormal) / (1.0 - weight * weight));
    }

    packUpGbufferDataSolid(rawData, gbufferData0, gbufferData1, gbufferData2);
}

/* DRAWBUFFERS:012 */
