layout(location = 0) out vec4 shadowColor0;
layout(location = 1) out vec4 shadowColor1;

in vec4 worldPos;           // Used as vec3(emissive, materialID, textureResolution) on voxel pixel. W reference to isVoxel.
in vec3 color;
in vec2 texlmcoord;         // texcoord in common shadow pixel, lmcoord in voxel pixel

flat in vec2 midTexCoord;   // Used as shadowOffset in common shadow mapping

// #define SHADOW_DISTORTION_FIX

#include "/settings/GlobalSettings.glsl"
#include "/libs/Uniform.glsl"
#include "/libs/Common.glsl"

uniform sampler2D gaux1;

const int shadowMapResolution = 4096; // [4096 8192 16384]
const float realShadowMapResolution = shadowMapResolution * MC_SHADOW_QUALITY;

float waterCaustic(vec3 mcPos, vec3 lightDir) {

    float causticStrength = 0.5;

    #ifdef WATER_CAUSTIC
        vec3 causticPos = mcPos + vec3(1.0, 0.0, 0.5) * frameTimeCounter * WATER_WAVE_SPEED;
        vec2 causticCoord = causticPos.xz + (causticPos.y / lightDir.y) * lightDir.xz;

        vec3 position = vec3(causticCoord, frameTimeCounter);

        const mat3 rotation = mat3(
            -0.6666667,-0.3333333, 0.6666667,
             0.6666667,-0.6666667, 0.3333333,
             0.3333333, 0.6666667, 0.6666667
        );

        float dist = 1.0;

        for (int i = 0; i < 4; i++) {
            position = rotation * position * 0.9 + 114.514;
            vec3 offset = 0.5 - fract(position);
            dist = min(dist, dot(offset, offset));
        }

        causticStrength = dist * sqrt(dist) * (3.0 - 2.0 * dist) * 0.9 + 0.1;
    #endif

    return causticStrength;
}

vec3 shadowCoordToWorldPos(vec3 shadowCoord) {
    float clipLengthInv = inversesqrt(dot(shadowCoord.xy, shadowCoord.xy));
    float shadowDistortion = pow(distortionStrength + 1.0, 1.0 / clipLengthInv) / distortionStrength - 1.0 / distortionStrength;
    shadowCoord.xy *= shadowDistortion * clipLengthInv;

    vec3 shadowViewPos = vec3(shadowProjectionInverse[0].x, shadowProjectionInverse[1].y, shadowProjectionInverse[2].z) * shadowCoord + shadowProjectionInverse[3].xyz;
    vec3 shadowPos = mat3(shadowModelViewInverse) * shadowViewPos + shadowModelViewInverse[3].xyz;
    return shadowPos;
}

void main() {
    #ifdef SHADOW_AND_SKY
        if (worldPos.w < 0.5) {
            vec4 albedo = textureLod(gtexture, texlmcoord, 0.0);
            albedo.rgb *= color;
            vec2 centerTexelOffset = gl_FragCoord.st - midTexCoord;
            if (any(greaterThan(abs(centerTexelOffset), vec2(1024.0)))
                #ifdef ALPHA_TEST
                    || albedo.w < alphaTestRef
                #endif
            ) discard;

            vec3 dPosDX = dFdx(worldPos.xyz);
            vec3 dPosDY = dFdy(worldPos.xyz);
            vec3 worldNormal = cross(dPosDX, dPosDY);

            #ifdef SHADOW_DISTORTION_FIX
                vec3 shadowProjPos = vec3(centerTexelOffset / 1024.0, gl_FragCoord.z * 10.0 - 5.0);
                vec3 pixelWorldPos = shadowCoordToWorldPos(shadowProjPos);
                vec3 positionDiff = worldPos.xyz - pixelWorldPos;
                float pixelDistanceToFace = dot(positionDiff, worldNormal);
                float NdotL = dot(worldNormal, shadowDirection);
                float offsetLength = signMul(pixelDistanceToFace / max(1e-5, abs(NdotL)), NdotL);
                gl_FragDepth = gl_FragCoord.z + offsetLength * shadowProjection[2].z * 0.1;
            #endif

            vec3 mcPos = worldPos.xyz + cameraPosition;
            mcPos.y += 128.0;
            float floorMcHeight = floor(mcPos.y / 2.0);
            shadowColor1 = vec4(1.0);
            if (midTexCoord.y < 0.5 * realShadowMapResolution) {
                float caustic = waterCaustic(mcPos, shadowDirection);
                albedo = vec4(caustic, mcPos.y * 0.5 - floorMcHeight, 1.0 - floorMcHeight / 255.0, 1.0);
            }
            shadowColor0 = albedo;
        }
        else
    #endif
    {
        if (worldPos.w > 1.5) {
            shadowColor0 = vec4(1.0);
            shadowColor1 = vec4(1.0);
        }
        else {
            float tileSize = 1.0 / TEXTURE_RESOLUTION;
            uint log2ResolutionU = (floatBitsToUint(worldPos.z) - 0x3F400000u) >> 23u;
            #if TEXTURE_RESOLUTION == 0
                tileSize = uintBitsToFloat(0x3F800000u - (log2ResolutionU << 23u));
            #endif
            ivec2 blockAtlasSize = textureSize(gaux1, 0);
            vec2 atlasSizeDiff = abs(blockAtlasSize - atlasSize);
            if (atlasSizeDiff.x + atlasSizeDiff.y > 0.1) discard;
            vec2 atlasTiles = atlasSize * tileSize;
            vec2 midCoord = (floor(midTexCoord * atlasTiles) + vec2(0.5)) / atlasTiles;
            shadowColor0 = vec4(color.rgb, texlmcoord.y * 128.0 / 255.0 + 32.0 / 255.0);
            shadowColor1 = vec4(midCoord, worldPos.y / 65535.0, float(log2ResolutionU) / 255.0 + clamp(worldPos.x, 0.0, 1.0) * 128.0 / 255.0);
        }
        #ifdef SHADOW_DISTORTION_FIX
            gl_FragDepth = gl_FragCoord.z;
        #endif
    }
}
