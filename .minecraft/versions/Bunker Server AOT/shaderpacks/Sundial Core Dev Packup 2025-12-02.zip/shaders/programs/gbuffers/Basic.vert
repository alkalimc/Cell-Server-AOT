in vec3 vaPosition;
in vec4 vaColor;
in vec3 vaNormal;

flat out vec4 color;

uniform int renderStage;
uniform mat4 modelViewMatrix;
uniform mat4 projectionMatrix;

const float lineWidth = 2.5;
const mat4 viewScale = mat4(mat3(1.0 - (1.0 / 256.0)));

#include "/settings/GlobalSettings.glsl"
#include "/libs/Uniform.glsl"
#include "/libs/GbufferData.glsl"

void main() {
    color = vaColor;
    vec3 viewPos = (modelViewMatrix * vec4(vaPosition, 1.0)).xyz;

    if (renderStage != MC_RENDER_STAGE_OUTLINE) {
        gl_Position = projectionMatrix * vec4(viewPos, 1.0);
    }
    else {
        vec4 linePosStart = projectionMatrix * viewScale * vec4(viewPos, 1.0);
        vec4 linePosEnd = projectionMatrix * viewScale * modelViewMatrix * vec4(vaPosition + vaNormal, 1.0);
        vec3 ndc1 = linePosStart.xyz / linePosStart.w;
        vec3 ndc2 = linePosEnd.xyz / linePosEnd.w;
        vec2 lineScreenDirection = normalize((ndc2.xy - ndc1.xy) * screenSize);
        vec2 lineOffset = vec2(-lineScreenDirection.y, lineScreenDirection.x) * lineWidth * texelSize;
        if (lineOffset.x < 0.0)
            lineOffset *= -1.0;
        if (gl_VertexID % 2 == 0)
            gl_Position = vec4((ndc1 + vec3(lineOffset, 0.0)) * linePosStart.w, linePosStart.w);
        else
            gl_Position = vec4((ndc1 - vec3(lineOffset, 0.0)) * linePosStart.w, linePosStart.w);
        vec3 projectionPos = gl_Position.xyz / gl_Position.w;
        viewPos = projectionToViewPos(projectionPos);
    }

    #ifdef TAA
        gl_Position.xy += taaOffset * gl_Position.w;
    #endif
}
