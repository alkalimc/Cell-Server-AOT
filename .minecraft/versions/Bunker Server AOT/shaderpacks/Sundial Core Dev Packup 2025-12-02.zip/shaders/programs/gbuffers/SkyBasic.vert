in vec3 vaPosition;
in vec4 vaColor;

out vec3 color;

uniform mat4 modelViewMatrix;
uniform mat4 projectionMatrix;

#include "/settings/GlobalSettings.glsl"
#include "/libs/Uniform.glsl"

void main() {
    color = vec3(0.0);
    if (abs(vaColor.r - vaColor.g) + abs(vaColor.g - vaColor.b) < 1e-3) {
        color = vaColor.rgb;
    }
    gl_Position = projectionMatrix * modelViewMatrix * vec4(vaPosition, 1.0);

    #ifdef TAA
        gl_Position.xy += taaOffset * gl_Position.w;
    #endif
}
