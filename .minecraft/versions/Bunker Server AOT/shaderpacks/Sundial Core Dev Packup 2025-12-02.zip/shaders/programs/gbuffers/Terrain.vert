in vec3 vaPosition;
in vec4 vaColor;
in vec2 vaUV0;
in ivec2 vaUV2;
in vec3 vaNormal;
in vec4 mc_Entity;

out vec4 vTexlmCoord;
out vec3 vColor;

out uint vMaterial;

uniform vec3 chunkOffset;
uniform mat4 modelViewMatrix;
uniform mat4 projectionMatrix;

// #define MOD_PLANT_DETECTION

#include "/settings/GlobalSettings.glsl"
#include "/libs/Uniform.glsl"
#include "/libs/GbufferData.glsl"

void main() {
    vec3 viewPos = (modelViewMatrix * vec4(vaPosition + chunkOffset, 1.0)).xyz;

    gl_Position = projectionMatrix * vec4(viewPos, 1.0);
    vColor = vaColor.rgb;
    vTexlmCoord.st = vaUV0;
    vTexlmCoord.pq = vaUV2 / 240.0;
    #ifdef IS_IRIS
        vTexlmCoord.pq = clamp(vaUV2 / 232.0 - 8.0 / 232.0, 0.0, 1.0);
    #endif

    uint isEmissive = uint(511.5 < mc_Entity.x && mc_Entity.x < 2048.5);
    int materialID = MAT_OPAQUE;

    if (mc_Entity.x < -0.5) {
        // Used for MOD_LIGHT_DETECTION
        materialID = 0;
        #ifdef MOD_PLANT_DETECTION
            if (abs(max(abs(vaNormal.x), abs(vaNormal.z)) - 0.5) < 0.45) {
                materialID = MAT_GRASS;
            }
        #endif
    }
    // Early break for common blocks
    else if (mc_Entity.x > 1) {
        vec3 blockPos = fract(vaPosition);
        if (abs(mc_Entity.x - 274.5) < 1.0 || mc_Entity.x == 502 || abs(mc_Entity.x - 311.5) < 31 || abs(mc_Entity.x - 822.5) < 31) {
            materialID = MAT_GRASS;
        }
        else if (mc_Entity.x == 2) {
            materialID = MAT_LEAVES;
        }
        else if (mc_Entity.x == 195) {
            materialID = MAT_CAULDRON;
            if (abs(vaColor.r - vaColor.b) > 1e-5) {
                materialID = MAT_WATER;
                vColor *= 0.5;
            }
        }
        else if (mc_Entity.x == 513 || abs(mc_Entity.x - 750) < 5.5) {
            materialID = MAT_TORCH;
        }
        else if (mc_Entity.x == 514) {
            materialID = MAT_LAVA;
        }
        else if (mc_Entity.x == 706) {
            isEmissive = uint(vaNormal.y > 0.5 && abs(blockPos.y - 0.9375) < 0.01);
            materialID = MAT_LAVA_CAULDRON;
        }
        else if (abs(mc_Entity.x - 762.5) < 1.0) {
            isEmissive = uint(abs(dot(vaNormal * vec3(16.0, 16.0 / 7.0, 16.0), blockPos - vec3(0.5, 0.4375, 0.5)) - 1.0) < 0.1);
            materialID = MAT_BREWING_STAND;
        }
        else if (mc_Entity.x == 768) {
            isEmissive = uint(abs(dot(vaNormal * vec3(16.0 / 5.0, 16.0 / 5.5, 16.0 / 5.0), blockPos - vec3(0.5, 8.5 / 16.0, 0.5)) - 1.0) < 0.1);
            materialID = MAT_BEACON;
        }
        else if (abs(mc_Entity.x - 788.5) < 3.0) {
            materialID = MAT_GLOWING_BERRIES;
        }
    }

    vMaterial = isEmissive;
    vMaterial |= uint(materialID) << 1;

    #ifdef TAA
        gl_Position.xy += taaOffset * gl_Position.w;
    #endif
}
