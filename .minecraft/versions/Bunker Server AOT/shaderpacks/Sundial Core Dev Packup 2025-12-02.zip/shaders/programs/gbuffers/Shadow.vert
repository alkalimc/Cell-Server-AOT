in vec3 vaPosition;
in vec4 vaColor;
in vec2 vaUV0;
in ivec2 vaUV2;
in vec3 vaNormal;
in vec4 mc_Entity;

#ifdef SHADOW_AND_SKY
    out vec2 vShadowOffset;
#endif

out vec4 vColor;
out vec3 vWorldPos;
out vec3 vWorldNormal;
out vec2 vLmcoord;
out vec2 vTexcoord;
out vec2 voxelCoordOffset;
out float edgeCheck;
out float voxelDepth;
out float vMaterialID;
out float vIsEmissive;
out float vDiscardVoxel;

uniform vec3 chunkOffset;
uniform vec3 camearPositionFract;
uniform mat3 normalMatrix;
uniform mat4 modelViewMatrix;
uniform mat4 projectionMatrix;
uniform mat4 textureMatrix = mat4(1.0);

#include "/settings/GlobalSettings.glsl"
#include "/libs/Uniform.glsl"
#include "/libs/PhysicsOcean.glsl"

const int shadowMapResolution = 4096; // [4096 8192 16384]
const float realShadowMapResolution = shadowMapResolution * MC_SHADOW_QUALITY;

uniform ivec2 eyeBrightness;

void main() {
    vColor = vaColor;
    vWorldNormal = normalize(mat3(shadowModelViewInverse) * normalMatrix * vaNormal);
    vTexcoord = (textureMatrix * vec4(vaUV0, 0.0, 1.0)).st;
    vLmcoord = vaUV2 / 240.0;
    #ifdef IS_IRIS
        vLmcoord = clamp(vaUV2 / 232.0 - 8.0 / 232.0, 0.0, 1.0);
    #endif
    vIsEmissive = step(511.5, mc_Entity.x);
    vMaterialID = mc_Entity.x - step(1.5, mc_Entity.x) - 511.0 * vIsEmissive;
    vMaterialID *= float(mc_Entity.x != 2);
    vec3 worldPos = vaPosition + chunkOffset;
    #ifdef PHYSICS_OCEAN
        float physics_localWaviness = texelFetch(physics_waviness, ivec2(worldPos.xz) - physics_textureOffset, 0).r;
        vec3 physics_localPosition = worldPos + vec3(0.0, physics_waveHeight(worldPos.xz, PHYSICS_ITERATIONS_OFFSET, physics_localWaviness, physics_gameTime), 0.0);

        vec3 viewPos = mat3(modelViewMatrix) * physics_localPosition + modelViewMatrix[3].xyz;
    #else
        vec3 viewPos = mat3(modelViewMatrix) * worldPos + modelViewMatrix[3].xyz;
    #endif
    vWorldPos = mat3(shadowModelViewInverse) * viewPos + shadowModelViewInverse[3].xyz;

    vDiscardVoxel = 0.0;
    voxelDepth = -0.5;
    vec3 vertexPos = vaPosition;
    vec3 absNormal = abs(vaNormal);
    float normalCheck = step(0.9, max(absNormal.x, max(absNormal.y, absNormal.z)));
    edgeCheck = step(0.4, dot(abs(floor(vertexPos - vaNormal * 1e-5) - floor(vertexPos - vaNormal * 0.01)), absNormal));
    vec3 blockPos = abs(fract(vertexPos) - 0.5);
    float isNoCubik = 1.0 - normalCheck * step(0.49, min(blockPos.x, min(blockPos.y, blockPos.z)));
    voxelDepth += step(mc_Entity.x, 0.5) * 0.6;
    voxelDepth += (isNoCubik + 1.0 - normalCheck) * 0.25;
    voxelDepth += abs(eyeBrightness.y - int(vaUV2.t)) / 240.0 * 0.1;
    if (mc_Entity.x < 1.5) {
        vDiscardVoxel = isNoCubik;
    }
    else if (vMaterialID == 194) {
        voxelDepth -= 0.1 * float(vaNormal.y > 0.5) + 0.1 * float(abs(blockPos.y - 7.0 / 16.0) < 0.5 / 16.0);
    }
    else if (mc_Entity.x == 230) {
        vec3 pixelPos = abs(fract(vertexPos * 16.0) - 0.5);
        vDiscardVoxel = step(max(pixelPos.x, max(pixelPos.y, pixelPos.z)), 0.49);
    }
    else if (abs(vMaterialID - 235.5) < 2.0) {
        vDiscardVoxel = step(vaNormal.y, 0.5);
    }
    else if (mc_Entity.x == 514) {
        float height = floor(fract(vertexPos.y + 0.4 / 16.0) * 16.0);
        voxelDepth = height * (0.3 / 16.0) + 0.3 * float(height < 0.5) - float(absNormal.y > 0.01);
        vMaterialID = vMaterialID - 1.0 + height;
    }
    else if (abs(mc_Entity.x - 1536.0) < 512.5) {
        vMaterialID = 249.0;
        if (abs(mc_Entity.x - 1025.5) < 2.0) {
            vColor.rgb = vec3(.8,1.,.8) * (mc_Entity.x - 1023.0) * 0.25;
        }
    }
    #ifdef IS_IRIS
        else if (abs(vMaterialID - 240.5) < 1.0) {
            voxelDepth -= 0.2 * float(abs(fract(vertexPos.y) - 1.0 / 16.0) < 0.5 / 16.0);
        }
    #endif
    vDiscardVoxel = clamp(vDiscardVoxel + step(499.5, vMaterialID), 0.0, 1.0);

    ivec2 corner;
    corner.y = (gl_VertexID & 2) >> 1;
    corner.x = (corner.y + gl_VertexID) & 1;
    corner = (1 - corner) << 31;
    voxelCoordOffset = intBitsToFloat(floatBitsToInt(1.0 / realShadowMapResolution) | corner);

    #ifdef SHADOW_AND_SKY
        vShadowOffset = vec2(0.0, 0.0);
        #ifdef TRANSPARENT
            float isWater = float(mc_Entity.x == 501);
            vShadowOffset.y = -isWater;
        #endif

        gl_Position = projectionMatrix * vec4(viewPos, 1.0);
        float clipLengthInv = inversesqrt(dot(gl_Position.xy, gl_Position.xy));
        float shadowDistortion = log(distortionStrength / clipLengthInv + 1.0) / log(distortionStrength + 1.0) * (2048 / realShadowMapResolution);
        gl_Position.xy *= max(0.0, clipLengthInv * shadowDistortion);
        gl_Position.xy = gl_Position.xy + (realShadowMapResolution - 2048) / realShadowMapResolution + vShadowOffset;
        gl_Position.z *= 0.2;

        vShadowOffset = vShadowOffset * 0.5 * realShadowMapResolution + vec2(realShadowMapResolution - 1024.0);
    #else
        gl_Position = vec4(0.0, 0.0, 0.0, 1.0);
    #endif
}
