layout(location = 0) out vec4 texBuffer6;
layout(location = 1) out uvec4 texBuffer8;

#ifdef SHADOW_AND_SKY
    in vec3 skyColorUp;

    #define LQ_REALISTIC_CLOUD
#endif

in vec2 texcoord;

uniform int worldTime;
uniform vec2 prevTaaOffset;

#define DISTANCE_GI_CULLING
#define MAX_BLENDED_FRAMES 48.0 // [8.0 12.0 16.0 20.0 24.0 28.0 32.0 36.0 40.0 48.0 56.0 64.0 72.0 80.0 96.0 112.0 128.0 144.0 160.0 192.0 224.0 256.0]
#define IRRADIANCE_CACHE_SAMPLES 1 // [1 2 3 4 5 6 7 8]
#define IRRADIANCE_CACHE_MAX_STEP 64 // [16 24 32 64 114 256 365 514]

#include "/settings/CloudSettings.glsl"
#include "/settings/GlobalSettings.glsl"
#include "/settings/PathTraceSettings.glsl"
#include "/libs/Uniform.glsl"
#include "/libs/Common.glsl"
#include "/libs/Atmosphere.glsl"
#include "/libs/Cloud.glsl"
#include "/libs/GbufferData.glsl"
#include "/libs/Shadow.glsl"
#include "/libs/PathTrace.glsl"

vec3 getIrCachePos() {
    vec3 irCachePos = vec3(0.0);
    vec2 texelcoord = floor(gl_FragCoord.st);
    irCachePos.z = mod(texelcoord.y, irCacheDiameter);
    float totalLengthX = floor(texelcoord.y / irCacheDiameter) * screenSize.x + texelcoord.x;
    irCachePos.x = mod(totalLengthX, irCacheDiameter);
    irCachePos.y = floor(totalLengthX / irCacheDiameter);
    return irCachePos;
}

uvec3 packUpIrCache(vec3 irCacheColor, vec3 irCacheDir) {
    uvec3 irradianceCache = uvec3(
        packHalf2x16(vec2(irCacheColor.x, irCacheDir.x)),
        packHalf2x16(vec2(irCacheColor.y, irCacheDir.y)),
        packHalf2x16(vec2(irCacheColor.z, irCacheDir.z))
    );
    return irradianceCache;
}

vec3 directionDistribution(vec2 randVec2) {
    float angle = 2.0 * PI * randVec2.x;
    float u = 2.0 * randVec2.y - 1.0;
    return vec3(sqrt(1.0 - u * u) * vec2(cos(angle), sin(angle)), u);
}

void currIrradianceCache(vec3 currIrCachePos, inout vec3 currIrCacheColor, inout vec3 currIrCacheDir, float blendFactor) {
    vec3 shadowVoxelPos = currIrCachePos - irCacheRadius;
    shadowVoxelPos.y -= voxelOriginY;
    vec3 voxelDistance = abs(shadowVoxelPos + 0.5);
    vec2 prevIrCacheCoord = calcIrCacheTexel(currIrCachePos + voxelMovement);

    if (all(lessThan(voxelDistance, voxelizationRadius))) {
        shadowVoxelPos = round(shadowVoxelPos + voxelizationRadius);
        vec3 traceDirection = vec3(0.0);
        vec3 traceDirectionInv = vec3(0.0);

        ivec2 nearbyVoxelTexel = ivec2(calcVoxelShadowTexel(shadowVoxelPos + vec3(1.0, 0.0, 0.0)));
        float nearbyVoxel = texelFetch(shadowcolor1, nearbyVoxelTexel, 0).z;
        float nearbyVoxelData = texelFetch(shadowcolor0, nearbyVoxelTexel, 0).w;
        float originSkyLight = (nearbyVoxelData * 255.0 / 128.0 - 32.0 / 128.0) * step(nearbyVoxelData, 0.999);
        traceDirection.x += step(nearbyVoxel, 46.5 / 65535.0);
        float hasVoxel = nearbyVoxel;

        nearbyVoxelTexel = ivec2(calcVoxelShadowTexel(shadowVoxelPos + vec3(-1.0, 0.0, 0.0)));
        nearbyVoxel = texelFetch(shadowcolor1, nearbyVoxelTexel, 0).z;
        nearbyVoxelData = texelFetch(shadowcolor0, nearbyVoxelTexel, 0).w;
        originSkyLight = max(originSkyLight, (nearbyVoxelData * 255.0 / 128.0 - 32.0 / 128.0) * step(nearbyVoxelData, 0.999));
        traceDirectionInv.x += step(nearbyVoxel, 46.5 / 65535.0);
        hasVoxel = min(nearbyVoxel, hasVoxel);

        nearbyVoxelTexel = ivec2(calcVoxelShadowTexel(shadowVoxelPos + vec3(0.0, 1.0, 0.0)));
        nearbyVoxel = texelFetch(shadowcolor1, nearbyVoxelTexel, 0).z;
        nearbyVoxelData = texelFetch(shadowcolor0, nearbyVoxelTexel, 0).w;
        originSkyLight = max(originSkyLight, (nearbyVoxelData * 255.0 / 128.0 - 32.0 / 128.0) * step(nearbyVoxelData, 0.999));
        traceDirection.y += step(nearbyVoxel, 46.5 / 65535.0);
        hasVoxel = min(nearbyVoxel, hasVoxel);

        nearbyVoxelTexel = ivec2(calcVoxelShadowTexel(shadowVoxelPos + vec3(0.0,-1.0, 0.0)));
        nearbyVoxel = texelFetch(shadowcolor1, nearbyVoxelTexel, 0).z;
        nearbyVoxelData = texelFetch(shadowcolor0, nearbyVoxelTexel, 0).w;
        originSkyLight = max(originSkyLight, (nearbyVoxelData * 255.0 / 128.0 - 32.0 / 128.0) * step(nearbyVoxelData, 0.999));
        traceDirectionInv.y += step(nearbyVoxel, 46.5 / 65535.0);
        hasVoxel = min(nearbyVoxel, hasVoxel);

        nearbyVoxelTexel = ivec2(calcVoxelShadowTexel(shadowVoxelPos + vec3(0.0, 0.0, 1.0)));
        nearbyVoxel = texelFetch(shadowcolor1, nearbyVoxelTexel, 0).z;
        nearbyVoxelData = texelFetch(shadowcolor0, nearbyVoxelTexel, 0).w;
        originSkyLight = max(originSkyLight, (nearbyVoxelData * 255.0 / 128.0 - 32.0 / 128.0) * step(nearbyVoxelData, 0.999));
        traceDirection.z += step(nearbyVoxel, 46.5 / 65535.0);
        hasVoxel = min(nearbyVoxel, hasVoxel);

        nearbyVoxelTexel = ivec2(calcVoxelShadowTexel(shadowVoxelPos + vec3(0.0, 0.0,-1.0)));
        nearbyVoxel = texelFetch(shadowcolor1, nearbyVoxelTexel, 0).z;
        nearbyVoxelData = texelFetch(shadowcolor0, nearbyVoxelTexel, 0).w;
        originSkyLight = max(originSkyLight, (nearbyVoxelData * 255.0 / 128.0 - 32.0 / 128.0) * step(nearbyVoxelData, 0.999));
        traceDirectionInv.z += step(nearbyVoxel, 46.5 / 65535.0);
        hasVoxel = min(nearbyVoxel, hasVoxel);

        ivec2 originVoxelTexel = ivec2(calcVoxelShadowTexel(shadowVoxelPos));
        vec4 originVoxel = texelFetch(shadowcolor1, originVoxelTexel, 0);
        float originVoxelData = texelFetch(shadowcolor0, originVoxelTexel, 0).w;
        originSkyLight = max(originSkyLight, (originVoxelData * 255.0 / 128.0 - 32.0 / 128.0) * step(originVoxelData, 0.999));
        hasVoxel = min(originVoxel.z, hasVoxel);

        originVoxel.z = step(originVoxel.z, 46.5 / 65535.0);
        float discardIrCache = step(0.999, hasVoxel) + originVoxel.z * step(0.999, textureLod(depthtex0, originVoxel.xy, 0.0).w);
        if (discardIrCache < 0.5) {
            float stepFirst = 1.0 - originVoxel.z;
            vec2 atlasTexSize = vec2(textureSize(depthtex0, 0));
            traceDirection = (traceDirection - traceDirectionInv) * step(dot(traceDirection + traceDirectionInv, vec3(1.0)), 1.5);
            vec3 rayOrigin = shadowVoxelPos + vec3(0.5) - traceDirection * 0.4;
            vec3 rayDirOffset = traceDirection * 0.5;
            NoiseGenerator noiseGenerator = initNoiseGenerator(uvec2(gl_FragCoord.st), uint(frameCounter));

            float skyLightFactor = 1.0;
            #ifdef LIGHT_LEAKING_FIX
                skyLightFactor = clamp(originSkyLight * 10.0, 0.0, 1.0);
            #endif

            vec3 voxelPosToWorldPos = -voxelOffset - voxelizationRadius;
            voxelPosToWorldPos.y += voxelOriginY;
            float sampleWeight = (1.0 + step(dot(abs(traceDirection), vec3(1.0)), 0.01)) / IRRADIANCE_CACHE_SAMPLES;

            for (int i = 0; i < IRRADIANCE_CACHE_SAMPLES; i++) {
                vec3 rayDir = normalize(directionDistribution(nextVec2(noiseGenerator)) - rayDirOffset);
                vec3 dirSigned = signI(rayDir);

                vec3 voxelIndex = dirSigned * shadowVoxelPos;
                vec3 mirroredOrigin = (rayOrigin - 0.5) * dirSigned - 0.5;
                // Turns specularData when hit
                vec3 stepLength = 1.0 / max(vec3(1e-6), abs(rayDir));
                // Turns albedo when hit
                vec3 nextLength = (voxelIndex - mirroredOrigin) * stepLength.rgb;

                bool hitSky = true;
                // Turns targetSkyLight when hit
                float prevID = 1.0;
                float rayLength = 114514.0;
                vec3 stainedColor = vec3(sampleWeight);
                vec3 singleIrCache = vec3(0.0);
                // Turns targetNormal when hit
                vec3 nextBlock = step(nextLength, vec3(min(nextLength.x, min(nextLength.y, nextLength.z)))) * stepFirst;

                int tracedSteps;
                float manhattanDistance = 0.0;
                for (tracedSteps = 0; tracedSteps < IRRADIANCE_CACHE_MAX_STEP; tracedSteps++) {
                    nextLength += nextBlock * stepLength.rgb;
                    voxelIndex += nextBlock;
                    manhattanDistance -= 1.0;
                    if (manhattanDistance < 0.5) {
                        vec3 realVoxelIndex = dirSigned * voxelIndex;
                        ivec2 shadowTexel = ivec2(calcVoxelShadowTexel(realVoxelIndex));
                        vec4 voxelData0 = texelFetch(shadowcolor0, shadowTexel, 0);
                        vec4 voxelData1 = texelFetch(shadowcolor1, shadowTexel, 0);
                        vec3 voxelDistance = abs(realVoxelIndex - voxelizationRadius + 0.5);
                        if (any(greaterThan(voxelDistance, voxelizationRadius)))
                            break;
                        float prevIDCopy = prevID;
                        prevID = 1.0;
                        manhattanDistance = floor(voxelData0.x * 5.0) * float(voxelData0.w == 1.0);
                        if (voxelData0.w < 1.0 && (voxelData1.z < 46.5 / 65535.0 || voxelData1.w > 0.4)) {
                            vec3 dirInv = dirSigned * stepLength;
                            vec3 rayLength1 = (realVoxelIndex - 1e-5 - rayOrigin) * dirInv;
                            vec3 rayLength2 = rayLength1 + (1.0 + 2e-5) * dirInv;
                            vec3 lengthRequired = min(rayLength2, rayLength1);
                            rayLength = max(lengthRequired.x, max(lengthRequired.y, lengthRequired.z));
                            nextBlock = -nextBlock * dirSigned;
                            vec3 rayHitPos = fract(rayOrigin + rayLength * rayDir) - 0.5;
                            vec2 coordOffset = vec2(0.0);
                            coordOffset.x = rayHitPos.x * (abs(nextBlock.y) + nextBlock.z) - rayHitPos.z * nextBlock.x;
                            coordOffset.y = rayHitPos.z * nextBlock.y + rayHitPos.y * (abs(nextBlock.y) - 1.0);
                            float textureResolution = 1.0 / TEXTURE_RESOLUTION;
                            #if TEXTURE_RESOLUTION == 0
                                textureResolution = uintBitsToFloat((0x7Fu - (uint(round(voxelData1.w * 255.0)) & 0x7Fu)) << 23u);
                            #endif
                            vec2 atlasTiles = atlasTexSize * textureResolution;
                            vec2 targetCoord = (floor(voxelData1.xy * atlasTiles) + 0.5 + coordOffset.xy) / atlasTiles;
                            vec4 texColor = textureLod(depthtex0, targetCoord, 0.0);
                            texColor.w += float(texColor.w < 1e-3 && 0.4 < voxelData1.w);
                            texColor.rgb *= voxelData0.xyz;
                            if (abs(voxelData1.z - 249.0 / 65535.0) < 0.4 / 65535.0) {
                                texColor = vec4(voxelData0.rgb, 1.0);
                            }
                            voxelData1.w = clamp(float(abs(voxelData1.z - 118.0 / 65535.0) > 0.5 / 65535.0) + clamp(nextBlock.y, 0.0, 1.0), 0.0, 1.0) * voxelData1.w;
                            voxelData1.w = step(0.4, voxelData1.w);
                            if (texColor.w > 0.999) {
                                hitSky = false;
                                prevID = voxelData0.w;
                                nextLength = texColor.rgb;
                                stepLength = vec3(targetCoord, voxelData1.w);
                                break;
                            }
                            if (abs(voxelData1.z - 249.0 / 65535.0) < 0.4 / 65535.0) {
                                vec3 lightColor = pow(texColor.rgb, vec3(2.2));
                                singleIrCache += lightColor * PI * BLOCK_LIGHT_BRIGHTNESS * stainedColor;
                            }
                            else if (texColor.w * prevIDCopy > 0.001) {
                                texColor.rgb = 2.2 * log2(texColor.rgb);
                                vec3 glassColor = exp2(sqrt(texColor.w * 1.5) * (texColor.rgb + log2(1.0 - 0.5 * texColor.w * texColor.w)));
                                SpecularData specularData = SpecularData(0.0, 0.0, 0.0, 0.0);
                                #ifdef MC_SPECULAR_MAP
                                    specularData = SPECULAR_FORMAT(textureLod(depthtex2, targetCoord, 0.0));
                                #endif
                                #ifndef SPECULAR_EMISSIVE
                                    specularData.emissive = 0.0;
                                #endif
                                #ifdef HARDCODED_EMISSIVE
                                    specularData.emissive += step(specularData.emissive, 1e-3) * voxelData1.w;
                                #endif
                                specularData.emissive *= PI * BLOCK_LIGHT_BRIGHTNESS;
                                singleIrCache += exp2(texColor.rgb) * stainedColor * specularData.emissive * texColor.w;
                                stainedColor *= glassColor;
                                prevID = 0.0;
                            }
                        }
                    }
                    nextBlock = step(nextLength, vec3(min(nextLength.x, min(nextLength.y, nextLength.z))));
                }
                if (hitSky) {
                    rayLength = 114514.0;
                    #ifdef SHADOW_AND_SKY
                        vec3 atmosphere;
                        vec3 worldOrigin = rayOrigin + voxelPosToWorldPos;
                        vec4 intersectionData = planetIntersectionData(worldOrigin, rayDir);
                        vec3 skylightColor = singleAtmosphereScattering(vec3(0.0), worldOrigin, rayDir, sunDirection, intersectionData, 30.0, atmosphere);
                        #ifdef CLOUD_IN_GI
                            float cloudDepth;
                            skylightColor = sampleClouds(
                                skylightColor, atmosphere, worldOrigin, rayDir, shadowDirection, sunDirection, skyColorUp, intersectionData.xyz, 0.0, cloudDepth
                            ).rgb;
                        #endif
                        singleIrCache += skylightColor * stainedColor * skyLightFactor;
                    #endif
                }
                else {
                    vec3 n = vec3(1.5);
                    vec3 k = vec3(0.0);
                    SpecularData specularData = SpecularData(0.0, 0.0, 0.0, 0.0);
                    #ifdef MC_SPECULAR_MAP
                        specularData = SPECULAR_FORMAT(textureLod(depthtex2, stepLength.xy, 0.0));
                    #endif
                    #ifndef SPECULAR_EMISSIVE
                        specularData.emissive = 0.0;
                    #endif
                    #ifdef HARDCODED_EMISSIVE
                        specularData.emissive += step(specularData.emissive, 1e-3) * stepLength.z;
                    #endif
                    specularData.emissive *= PI * BLOCK_LIGHT_BRIGHTNESS;
                    #ifdef LABPBR_F0
                        n = mix(n, vec3(f0ToIor(specularData.metalness)), step(0.001, specularData.metalness));
                        hardcodedMetal(specularData.metalness, n, k);
                        specularData.metalness = step(229.5 / 255.0, specularData.metalness);
                    #endif
                    vec3 albedo = pow(nextLength.rgb, vec3(2.2));

                    vec3 realVoxelIndex = dirSigned * voxelIndex;
                    vec3 prevIrCache =
                        getIrradianceCachePrev(realVoxelIndex + vec3(0.5) + nextBlock * 1.01, nextBlock) *
                        ((1.0 - specularData.metalness + pow(1.0 - specularData.smoothness, 5.0)) / PI);
                    vec3 sampleLight = albedo * (specularData.emissive + prevIrCache);
                    sampleLight *= mix(1.0, 1.0 / PI, float(tracedSteps < 0.5));

                    #ifdef SHADOW_AND_SKY
                        float shadowLightFactor = 1.0;
                        prevID = prevID * 255.0 / 128.0 - 32.0 / 128.0;
                        #ifdef LIGHT_LEAKING_FIX
                            shadowLightFactor = clamp(prevID * 10.0, 0.0, 1.0);
                        #endif
                        float NdotL = clamp(dot(nextBlock, shadowDirection), 0.0, 1.0);
                        vec3 targetWorldPos = realVoxelIndex + (nextBlock * 0.51 + 0.5) + voxelPosToWorldPos;
                        vec3 shadow = directShadow(
                            targetWorldPos, nextBlock, NdotL, shadowLightFactor,
                            specularData.smoothness, specularData.porosity, prevID, 1.0
                        );
                        #ifdef CLOUD_SHADOW
                            shadow *= cloudShadow(targetWorldPos, shadowDirection);
                        #endif
                        shadow *=
                            albedo * (1.0 - specularData.metalness) + (1.0 + log2(specularData.smoothness + 1.0) * 3.0) *
                            sunlightSpecular(
                                rayDir, shadowDirection, nextBlock, albedo, 0.5 * log2(specularData.smoothness + 1.0),
                                specularData.metalness, NdotL, dot(-rayDir, nextBlock), n, k
                            );
                        sampleLight += shadow * sunColor;
                    #endif

                    #ifdef DISTANCE_GI_CULLING
                        sampleLight *= exp(-tracedSteps * 0.1);
                    #endif

                    singleIrCache += sampleLight * stainedColor;
                }
                #ifdef NETHER
                    singleIrCache *= netherFogAbsorption(rayLength);
                    singleIrCache += netherFogScattering(rayLength) * stainedColor;
                #endif
                #ifdef THE_END
                    singleIrCache *= endFogAbsorption(rayLength);
                    singleIrCache += endFogScattering(rayLength) * stainedColor;
                #endif
                currIrCacheColor += singleIrCache;
                currIrCacheDir += rayDir * dot(singleIrCache, vec3(0.3333333));
            }
            currIrCacheDir /= IRRADIANCE_CACHE_SAMPLES;

            vec3 prevIrCacheColor, prevIrCacheDir;
            irradianceCacheData(prevIrCacheCoord, prevIrCacheColor, prevIrCacheDir);

            currIrCacheColor = mix(currIrCacheColor * blendFactor, prevIrCacheColor, vec3(0.99 * blendFactor));
            currIrCacheDir = mix(currIrCacheDir * blendFactor, prevIrCacheDir, vec3(0.99 * blendFactor));
            currIrCacheColor = clamp(currIrCacheColor, vec3(1e-5), vec3(1e+5));
        }
    }
}

vec2 getPrevCoord(inout vec3 prevWorldPos, vec3 viewPos, vec3 worldGeoNormal, float parallaxOffset, float materialID) {
    vec3 prevScreenPos;
    vec3 prevViewPos;
    if (materialID == MAT_HAND) {
        prevViewPos = viewPos;
        prevViewPos -= gbufferModelView[3].xyz * MC_HAND_DEPTH;
        prevViewPos += gbufferPreviousModelView[3].xyz * MC_HAND_DEPTH;
        vec3 prevViewNormal = mat3(gbufferModelView) * worldGeoNormal;
        prevViewPos -= parallaxOffset * prevViewPos / max(dot(prevViewPos, -prevViewNormal), 1e-5);
        prevScreenPos = viewToProjectionPos(prevViewPos);
    } else {
        prevWorldPos += cameraMovement;
        prevViewPos = prevWorldToViewPos(prevWorldPos);
        vec3 prevViewNormal = mat3(gbufferPreviousModelView) * worldGeoNormal;
        prevViewPos -= parallaxOffset * prevViewPos / max(dot(prevViewPos, -prevViewNormal), 1e-5);
        prevScreenPos = prevViewToProjectionPos(prevViewPos);
    }
    prevWorldPos = prevViewToWorldPos(prevViewPos);
    vec2 prevCoord = prevScreenPos.st * 0.5 + 0.5;
    return prevCoord;
}

vec4 samplePrevData(vec2 sampleTexelCoord, vec3 prevWorldPos, vec3 currNormal, vec3 geoNormal, float materialID, out float sampleBlendWeight) {
    ivec2 sampleTexel = ivec2(sampleTexelCoord);
    vec4 prevSampleData = max(vec4(0.0, 0.0, 0.0, 1e-5), texelFetch(colortex6, sampleTexel, 0));
    vec3 prevSampleColor = prevSampleData.rgb;
    float prevSampleDepth = min(1.0, uintBitsToFloat(texelFetch(colortex8, sampleTexel, 0).w));
    sampleBlendWeight = prevSampleData.w;

    vec2 sampleCoord = sampleTexelCoord * texelSize;
    vec2 screenCoord = sampleCoord;
    #ifdef TAA
        screenCoord -= prevTaaOffset;
    #endif
    vec3 prevSampleViewPos;
    #ifdef LOD
        if (prevSampleDepth < 0.0) {
            prevSampleViewPos = prevProjectionToViewPosLod(vec3(screenCoord, -prevSampleDepth) * 2.0 - 1.0);
        } else
    #endif
    {
        prevSampleViewPos = prevProjectionToViewPos(vec3(screenCoord, prevSampleDepth) * 2.0 - 1.0);
    }

    vec3 prevNormal = texelFetch(colortex5, sampleTexel, 0).xyz;
    float normalFactor = pow(clamp(dot(currNormal, prevNormal) + 1e-5, 0.0, 1.0), sampleBlendWeight * 128.0 * inversesqrt(1.0 + dot(prevSampleViewPos, prevSampleViewPos)));
    float isPrevValid = step(dot(abs(sampleCoord - clamp(sampleCoord, 0.0, 1.0)) * screenSize, vec2(1.0)), 0.5) * normalFactor;

    vec3 prevSampleWorldPos = prevViewToWorldPos(prevSampleViewPos);
    vec3 positionDiff = prevSampleWorldPos - prevWorldPos;
    float positionDistance = inversesqrt((dot(prevSampleViewPos, prevSampleViewPos) + 2.0) / max(1e-8, abs(dot(positionDiff, geoNormal)))) *
                             clamp(sampleBlendWeight * 2.0 + 0.1, 0.0, 1.0) * 100.0;
    if (materialID == MAT_HAND) {
        positionDistance *= 0.3;
    }
    isPrevValid *= clamp(1.0 - positionDistance * positionDistance, 0.0, 1.0) * step(prevSampleDepth, 0.999999);

    return vec4(prevSampleColor, isPrevValid);
}

vec4 blendGlobalIllumination(vec2 prevCoord, vec3 currColor, vec3 prevWorldPos, vec3 currNormal, vec3 geoNormal, float materialID) {
    vec2 sampleCoord = prevCoord;
    const float offset = 0.25;
    sampleCoord += prevTaaOffset * offset - taaOffset * 0.5 * offset;
    #ifdef TAA
        sampleCoord += taaOffset * 0.5;
    #endif

    float isPrevValid = 0.0;
    vec2 prevTexel = sampleCoord * screenSize;
    vec2 sampleCenter = round(prevTexel);
    vec4 dataAccum = vec4(0.0);
    float weightAccum = 0.0;
    float sampleOffsetX = -0.5;
    for (int i = 0; i < 2; i++) {
        float sampleOffsetY = -0.5;
        for (int j = 0; j < 2; j++) {
            vec2 sampleTexel = sampleCenter + vec2(sampleOffsetX, sampleOffsetY);
            float sampleBlendWeight;
            vec4 sampleData = samplePrevData(sampleTexel, prevWorldPos, currNormal, geoNormal, materialID, sampleBlendWeight);
            float weight = (1.0 - abs(sampleTexel.x - prevTexel.x)) * (1.0 - abs(sampleTexel.y - prevTexel.y)) * sampleData.w;
            sampleBlendWeight *= weight;
            dataAccum += vec4(sampleData.rgb * sampleBlendWeight, sampleBlendWeight);
            weightAccum += weight;
            isPrevValid = max(isPrevValid, sampleData.w);
            sampleOffsetY += 1.0;
        }
        sampleOffsetX += 1.0;
    }
    vec3 prevColor = dataAccum.rgb / max(1e-5, dataAccum.w);
    float prevBlendWeight = dataAccum.w / max(1e-5, weightAccum);

    float blendWeight = prevBlendWeight * 255.0 * isPrevValid + 1.0;
    vec3 blendedColor = mix(prevColor, currColor, vec3(1.0 / blendWeight));
    blendWeight = min(blendWeight, MAX_BLENDED_FRAMES) / 255.0;
    return vec4(blendedColor, blendWeight);
}

void main() {
    int prevWorldTime = floatBitsToInt(texelFetch(colortex3, ivec2(1, 0), 0).r);
    int worldTimeDiff = worldTime - prevWorldTime;
    worldTimeDiff = min(abs(worldTimeDiff + 24000), abs(worldTimeDiff));
    float blendFactor = float(worldTimeDiff < 100);
    #ifndef SHADOW_AND_SKY
        blendFactor = 1.0;
    #endif


    /********************************************************** Irradiance Cache **********************************************************/

    vec3 currIrCachePos = getIrCachePos();

    vec3 currIrCacheColor = vec3(0.0);
    vec3 currIrCacheDir = vec3(0.0);
    currIrradianceCache(currIrCachePos, currIrCacheColor, currIrCacheDir, blendFactor);

    texBuffer8.rgb = packUpIrCache(currIrCacheColor, currIrCacheDir);
    float depth = textureLod(depthtex1, texcoord, 0.0).r;
    #ifdef LOD
        depth -= float(depth == 1.0) * (1.0 + getLodDepthSolidDeferred(texcoord));
    #endif
    texBuffer8.w = floatBitsToUint(depth);


    /************************************************************* GI Blending *************************************************************/

    vec4 blendedColor = vec4(0.0);
    if (abs(depth) < 0.999999) {
        ivec2 texel = ivec2 (gl_FragCoord.st);
        GbufferData gbufferData = getGbufferData(texel, texcoord);
        gbufferData.parallaxOffset *= PARALLAX_DEPTH * 0.2;
        vec3 viewPos;
        #ifdef LOD
            if (depth < 0.0) {
                viewPos = screenToViewPosLod(texcoord, -depth);
            } else
        #endif
        {
            viewPos = screenToViewPos(texcoord, depth);
        }
        float NdotV = max(dot(viewPos, -gbufferData.geoNormal), 1e-6);
        viewPos += gbufferData.parallaxOffset * viewPos / NdotV;
        vec3 worldPos = viewToWorldPos(viewPos);
        vec3 worldNormal = normalize(mat3(gbufferModelViewInverse) * gbufferData.normal);
        vec3 worldGeoNormal = normalize(mat3(gbufferModelViewInverse) * gbufferData.geoNormal);

        vec3 prevWorldPos = worldPos;
        vec2 prevCoord = getPrevCoord(prevWorldPos, viewPos, worldGeoNormal, gbufferData.parallaxOffset, gbufferData.materialID);

        blendedColor.rgb = texelFetch(colortex4, texel, 0).rgb;
        if (blendFactor > 0.5) {
            blendedColor = blendGlobalIllumination(prevCoord, blendedColor.rgb, prevWorldPos, worldNormal, worldGeoNormal, gbufferData.materialID);
        }
    }
    texBuffer6 = blendedColor;
}

/* RENDERTARGETS: 6,8 */
