layout(location = 0) out vec4 texBuffer5;

#define GI_COLOR_VARIANCE_STRICTNESS 1.0 // [0.01 0.02 0.03 0.04 0.05 0.06 0.08 0.1 0.12 0.14 0.16 0.18 0.2 0.22 0.24 0.26 0.28 0.3 0.33 0.36 0.4 0.43 0.46 0.5 0.55 0.6 0.65 0.7 0.75 0.8 0.85 0.9 0.95 1.0 1.1 1.2 1.3 1.4 1.5 1.6 1.7 1.8 1.9 2.0 2.2 2.4 2.6 2.8 3.0 3.2 3.4 3.6 3.8 4.0 4.2 4.4 4.6 4.8 5.0 5.5 6.0 6.5 7.0 7.5 8.0 9.5 10.0 11.0 12.0 13.0 14.0 15.0 16.0 17.0 18.0 19.0 20.0]

#include "/settings/GlobalSettings.glsl"
#include "/settings/PathTraceSettings.glsl"
#include "/libs/Uniform.glsl"
#include "/libs/Common.glsl"
#include "/libs/GbufferData.glsl"

void main() {
    ivec2 texel = ivec2(gl_FragCoord.st);
    vec4 colorData = texelFetch(colortex6, texel, 0);
    float originDepth = texelFetch(depthtex1, texel, 0).r;
    #ifdef LOD
        originDepth += float(originDepth == 1.0) * getLodDepthSolidDeferred(gl_FragCoord.st * texelSize);
    #endif

    if (originDepth - float(originDepth > 1.0) < 0.999999) {
        vec3 originNormal = decodeNormal(texelFetch(colortex1, texel, 0).zw);

        vec3 colorAccum1 = colorData.rgb;
        vec3 colorAccum2 = colorData.rgb * colorData.rgb;
        ivec2 offset = ivec2(-1, -1);
        ivec2 direction = ivec2(1, 0);
        for (int i = 0; i < 4; i++) {
            for (int j = 0; j < 2; j++) {
                offset += direction;
                ivec2 sampleTexel = texel + offset;
                vec4 sampleData = texelFetch(colortex6, sampleTexel, 0);
                colorAccum1 += sampleData.rgb;
                colorAccum2 += sampleData.rgb * sampleData.rgb;
                vec3 sampleNormal = decodeNormal(texelFetch(colortex1, sampleTexel, 0).zw);
                float sampleDepth = texelFetch(depthtex1, sampleTexel, 0).r;
                #ifdef LOD
                    sampleDepth += float(sampleDepth == 1.0) * getLodDepthSolidDeferred((sampleTexel + 0.5) * texelSize);
                #endif
                colorData.w = mix(
                    colorData.w, max(sampleData.w, colorData.w),
                    exp2(-14426.9502 * abs(sampleDepth - originDepth) + 64.0 * log2(clamp(dot(sampleNormal, originNormal), 0.0, 1.0)))
                );
            }
            direction = ivec2(-direction.y, direction.x);
        }
        colorAccum1 /= 9.0;
        colorAccum2 /= 9.0;
        float colorVariance = dot(max(colorAccum2 - colorAccum1 * colorAccum1, vec3(0.0)), vec3(50.0));
        #ifdef SHARP_GI_FILTER
            colorVariance *= 0.02;
        #endif
        float totalVariance = 0.04 / max(1e-5, exp(pow(max(1e-5, colorData.w - 0.01) * 6.5 * GI_SAMPLES, 8.0)) - 1.0) * (dot(colorAccum1, colorAccum1) + 0.1) + colorVariance;
        colorData.w = max(totalVariance / GI_COLOR_VARIANCE_STRICTNESS, 1e-5);
    }
    texBuffer5 = colorData;
}

/* RENDERTARGETS: 5 */
