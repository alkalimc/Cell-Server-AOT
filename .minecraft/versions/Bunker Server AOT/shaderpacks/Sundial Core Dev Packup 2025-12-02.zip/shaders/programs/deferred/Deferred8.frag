layout(location = 0) out vec4 texBuffer5;

in vec2 texcoord;

#include "/settings/GlobalSettings.glsl"
#include "/libs/Uniform.glsl"
#include "/libs/Common.glsl"
#include "/libs/GbufferData.glsl"
#include "/libs/GlobalIllumination.glsl"

void main() {
    texBuffer5 = globalIlluminationFilter(vec2(7.0, -7.0));
}

/* RENDERTARGETS: 5 */
