in vec3 vaPosition;
in vec2 vaUV0;

out vec2 texcoord;

uniform mat4 modelViewMatrix;
uniform mat4 projectionMatrix;

#ifdef SKY_COLOR_UP
    out vec3 skyColorUp;

    #include "/settings/GlobalSettings.glsl"
    #include "/libs/Uniform.glsl"
    #include "/libs/Atmosphere.glsl"
#else
    #include "/settings/GlobalSettings.glsl"
    #include "/libs/Uniform.glsl"
#endif

void main() {
    ivec2 offset = ivec2((min(gl_VertexID, 2) & 1) << 1, gl_VertexID & 2);
    texcoord = offset;
    gl_Position = vec4(offset * 2.0 - 1.0, 0.0, 1.0);

    #ifdef SKY_COLOR_UP
        vec3 atmosphere;
        skyColorUp = atmosphereScatteringUp(sunDirection.y, 30.0);
    #endif
}
