layout(location = 0) out vec4 shadowColor0;

void main() {
    discard;
}

/* RENDERTARGETS: 0 */
