layout(location = 0) out vec4 texBuffer1;
layout(location = 1) out vec4 texBuffer2;
layout(location = 2) out vec4 texBuffer4;
layout(location = 3) out vec4 texBuffer5;

in vec2 texcoord;

#include "/settings/CloudSettings.glsl"
#include "/settings/GlobalSettings.glsl"
#include "/settings/PathTraceSettings.glsl"

#ifdef SHADOW_AND_SKY
    in vec3 skyColorUp;
#else
    const vec3 skyColorUp = vec3(0.0);
#endif

#ifdef THE_END
    #include "/libs/Galaxy.glsl"
#endif

#include "/libs/Uniform.glsl"
#include "/libs/Common.glsl"
#include "/libs/Atmosphere.glsl"
#include "/libs/Cloud.glsl"
#include "/libs/GbufferData.glsl"
#include "/libs/Shadow.glsl"
#include "/libs/VoxelShape.glsl"
#include "/libs/PathTrace.glsl"
#include "/libs/Parallax.glsl"
#include "/libs/Reflection.glsl"

void main() {
    ivec2 texel = ivec2(gl_FragCoord.st);
    float waterDepth = textureLod(depthtex0, texcoord, 0.0).r;
    float solidDepth = textureLod(depthtex1, texcoord, 0.0).r;
    #ifdef LOD
        waterDepth += float(waterDepth == 1.0) * getLodDepthWater(texcoord);
        solidDepth += float(solidDepth == 1.0) * getLodDepthSolid(texcoord);
    #endif
    float parallaxOffset = texelFetch(colortex2, texel, 0).w;

    texBuffer1 = texelFetch(colortex1, texel, 0);
    texBuffer2.w = parallaxOffset;
    vec4 diffuseData = texelFetch(colortex5, texel, 0);

    vec4 waterReflectionColor = vec4(0.0);
    vec3 mirrorColor = diffuseData.rgb;
    float n = diffuseData.w;
    vec3 mirrorWeight = texelFetch(colortex4, texel, 0).rgb;
    float reflectionDepth = 0.0;

    if (waterDepth < solidDepth) {
        GbufferData gbufferData = getGbufferData(texel, texcoord);
        gbufferData.depth = waterDepth;
        texBuffer2.w = gbufferData.parallaxOffset;

        #ifdef REFLECTION
            if (gbufferData.smoothness > 0.01) {
                vec3 reflectionNormal;
                reflection(
                    gbufferData, vec3(n), vec3(0.0), 1.0, colortex6, colortex7, colortex3,
                    reflectionDepth, mirrorColor, waterReflectionColor, reflectionNormal, mirrorWeight
                );

                mirrorColor = max(mirrorColor, vec3(0.0));
                reflectionDepth = max(reflectionDepth, 0.0);
                waterReflectionColor = max(waterReflectionColor, vec4(0.0));

                texBuffer1.rg = encodeNormal(mat3(gbufferModelView) * reflectionNormal);
            }
        #endif
    }

    texBuffer2.rgb = mirrorWeight;

    texBuffer4 = waterReflectionColor;
    texBuffer5 = vec4(mirrorColor, reflectionDepth);
}

/* RENDERTARGETS: 1,2,4,5 */
