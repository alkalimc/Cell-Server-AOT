layout(location = 0) out vec4 shadowColor0;

const int shadowMapResolution = 4096; // [4096 8192 16384]
const float realShadowMapResolution = shadowMapResolution * MC_SHADOW_QUALITY;

layout(rgba8) uniform image2D shadowcolorimg0;

#include "/settings/GlobalSettings.glsl"
#include "/libs/Uniform.glsl"
#include "/libs/PathTrace.glsl"
#include "/libs/DistanceField.glsl"

void main() {
    ivec2 texelcoord = ivec2(gl_FragCoord.st);
    vec4 shadowColor0 = texelFetch(shadowcolor0, texelcoord, 0);
    vec3 voxelIndex = getVoxelIndex(texelcoord);
    // Does not contains blocks, or voxel index invalid
    if (shadowColor0.a < 0.999 && isVoxelIndexValid(voxelIndex)) {
        {
            ivec2 neighborTexel = texelcoord - ivec2(1, 0);
            normalizeVoxelTexel(neighborTexel);
            vec4 neighborData = texelFetch(shadowcolor0, neighborTexel, 0);
            if (abs((voxelIndex.x - 1.0) / voxelizationRadius.x - 1.0 + 0.5 / voxelizationRadius.x) < 1.0 && neighborTexel.y < voxelMapResolution) {
                if (neighborData.a > 0.999) {
                    imageStore(shadowcolorimg0, neighborTexel, vec4(1.3 / 5.0, 1.0, 1.0, 1.0));
                }
            }
        }
        {
            ivec2 neighborTexel = texelcoord + ivec2(1, 0);
            normalizeVoxelTexel(neighborTexel);
            vec4 neighborData = texelFetch(shadowcolor0, neighborTexel, 0);
            if (abs((voxelIndex.x + 1.0) / voxelizationRadius.x - 1.0 + 0.5 / voxelizationRadius.x) < 1.0 && neighborTexel.y < voxelMapResolution) {
                if (neighborData.a > 0.999) {
                    imageStore(shadowcolorimg0, neighborTexel, vec4(1.3 / 5.0, 1.0, 1.0, 1.0));
                }
            }
        }
        {
            ivec2 neighborTexel = texelcoord - ivec2(int(voxelizationDiameter), 0);
            normalizeVoxelTexel(neighborTexel);
            vec4 neighborData = texelFetch(shadowcolor0, neighborTexel, 0);
            if (abs((voxelIndex.y - 1.0) / voxelizationRadius.y - 1.0 + 0.5 / voxelizationRadius.y) < 1.0 && neighborTexel.y < voxelMapResolution) {
                if (neighborData.a > 0.999) {
                    imageStore(shadowcolorimg0, neighborTexel, vec4(1.3 / 5.0, 1.0, 1.0, 1.0));
                }
            }
        }
        {
            ivec2 neighborTexel = texelcoord + ivec2(int(voxelizationDiameter), 0);
            normalizeVoxelTexel(neighborTexel);
            vec4 neighborData = texelFetch(shadowcolor0, neighborTexel, 0);
            if (abs((voxelIndex.y + 1.0) / voxelizationRadius.y - 1.0 + 0.5 / voxelizationRadius.y) < 1.0 && neighborTexel.y < voxelMapResolution) {
                if (neighborData.a > 0.999) {
                    imageStore(shadowcolorimg0, neighborTexel, vec4(1.3 / 5.0, 1.0, 1.0, 1.0));
                }
            }
        }
        {
            ivec2 neighborTexel = texelcoord - ivec2(0, 1);
            vec4 neighborData = texelFetch(shadowcolor0, neighborTexel, 0);
            if (abs((voxelIndex.z - 1.0) / voxelizationRadius.z - 1.0 + 0.5 / voxelizationRadius.z) < 1.0 && neighborTexel.y < voxelMapResolution) {
                if (neighborData.a > 0.999) {
                    imageStore(shadowcolorimg0, neighborTexel, vec4(1.3 / 5.0, 1.0, 1.0, 1.0));
                }
            }
        }
        {
            ivec2 neighborTexel = texelcoord + ivec2(0, 1);
            vec4 neighborData = texelFetch(shadowcolor0, neighborTexel, 0);
            if (abs((voxelIndex.z + 1.0) / voxelizationRadius.z - 1.0 + 0.5 / voxelizationRadius.z) < 1.0 && neighborTexel.y < voxelMapResolution) {
                if (neighborData.a > 0.999) {
                    imageStore(shadowcolorimg0, neighborTexel, vec4(1.3 / 5.0, 1.0, 1.0, 1.0));
                }
            }
        }
    }
    discard;
}

/* RENDERTARGETS: 0 */
