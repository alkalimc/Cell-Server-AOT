in vec3 vaPosition;
in vec2 vaUV0;

#include "/settings/GlobalSettings.glsl"

const int shadowMapResolution = 4096; // [4096 8192 16384]
const float realShadowMapResolution = shadowMapResolution * MC_SHADOW_QUALITY;
#ifdef SHADOW_AND_SKY
    const float shadowcompScale = (realShadowMapResolution - 2048.0) / realShadowMapResolution;
#else
    const float shadowcompScale = 1.0;
#endif

void main() {
    gl_Position = vec4(vaPosition * shadowcompScale * 2.0 - 1.0, 1.0);
}
