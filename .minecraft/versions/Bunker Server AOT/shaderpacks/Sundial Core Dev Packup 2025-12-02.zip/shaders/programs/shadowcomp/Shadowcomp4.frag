layout(location = 0) out vec4 shadowColor0;

const int shadowMapResolution = 4096; // [4096 8192 16384]
const float realShadowMapResolution = shadowMapResolution * MC_SHADOW_QUALITY;

layout(rgba8) uniform image2D shadowcolorimg0;

#include "/settings/GlobalSettings.glsl"
#include "/libs/Uniform.glsl"
#include "/libs/PathTrace.glsl"
#include "/libs/DistanceField.glsl"

void main() {
    buildManhattanDistanceField(2.0);
    discard;
}

/* RENDERTARGETS: 0 */
