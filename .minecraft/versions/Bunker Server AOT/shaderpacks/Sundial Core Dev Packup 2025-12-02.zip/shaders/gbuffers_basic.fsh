#version 450

#include "/programs/gbuffers/Basic.frag"
