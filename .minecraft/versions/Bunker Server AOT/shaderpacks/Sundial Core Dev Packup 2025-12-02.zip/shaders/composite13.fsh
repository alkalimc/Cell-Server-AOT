#version 450

#include "/programs/composite/Composite13.frag"
