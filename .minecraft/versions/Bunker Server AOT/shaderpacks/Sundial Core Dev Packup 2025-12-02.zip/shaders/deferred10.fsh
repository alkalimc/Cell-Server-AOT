#version 450

#include "/programs/deferred/Deferred10.frag"
