#version 450

#include "/programs/composite/Composite11.frag"
