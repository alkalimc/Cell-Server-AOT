#version 450

#include "/programs/composite/Composite5.frag"
