#version 450

#define ENTITIES
#define OVERLAY

#include "/programs/gbuffers/Textured.vert"
