#version 450

#include "/programs/deferred/Deferred6.comp"
