#version 450

#define ENTITIES
#define GLOWING

#include "/programs/gbuffers/Textured.vert"
