#version 450

#include "/programs/deferred/Deferred14.frag"
