#version 450

#define ALPHA_TEST
#define SHADOW_AND_SKY

#include "/programs/gbuffers/Shadow.frag"
