#version 450

#define BEACON
#define END_PORTAL
#define USE_RAIN_PUDDLE

#include "/programs/gbuffers/Textured.frag"
