#version 450

#define SHADOW_AND_SKY

#include "/programs/shadowcomp/Shadowcomp2.frag"
