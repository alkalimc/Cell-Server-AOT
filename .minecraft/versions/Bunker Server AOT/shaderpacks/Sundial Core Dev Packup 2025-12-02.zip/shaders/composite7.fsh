#version 450

#include "/programs/composite/Composite7.frag"
