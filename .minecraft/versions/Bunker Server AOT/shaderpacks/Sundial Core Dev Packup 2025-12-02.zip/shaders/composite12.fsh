#version 450

#include "/programs/composite/Composite12.frag"
