#version 450

#include "/programs/deferred/Deferred8.frag"
