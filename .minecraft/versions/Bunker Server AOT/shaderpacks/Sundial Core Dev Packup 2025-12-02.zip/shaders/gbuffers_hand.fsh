#version 450

#define HAND

#include "/programs/gbuffers/Textured.frag"
