#version 450

#include "/programs/shadowcomp/Shadowcomp.vert"
