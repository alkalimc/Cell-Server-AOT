#version 450

#include "/programs/shadowcomp/Shadowcomp4.frag"
