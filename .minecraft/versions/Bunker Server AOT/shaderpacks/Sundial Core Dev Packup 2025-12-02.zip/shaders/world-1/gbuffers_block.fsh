#version 450

#define BEACON
#define END_PORTAL

#include "/programs/gbuffers/Textured.frag"
