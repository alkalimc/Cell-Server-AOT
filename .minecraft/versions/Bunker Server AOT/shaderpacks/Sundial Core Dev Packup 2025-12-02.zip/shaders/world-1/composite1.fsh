#version 450

#define NETHER

#include "/programs/composite/Composite1.frag"
