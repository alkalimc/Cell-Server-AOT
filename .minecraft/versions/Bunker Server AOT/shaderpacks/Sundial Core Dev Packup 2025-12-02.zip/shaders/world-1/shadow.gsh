#version 450

#include "/programs/gbuffers/Shadow.geom"
