#version 450

#include "/programs/shadowcomp/Shadowcomp0.frag"
