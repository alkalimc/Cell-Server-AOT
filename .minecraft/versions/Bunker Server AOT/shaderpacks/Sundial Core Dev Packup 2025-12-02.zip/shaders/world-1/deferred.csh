#version 450

#define NETHER

#include "/programs/deferred/Deferred0.comp"
