#version 450

#define BASIC_LIGHT 0.01

#include "/programs/deferred/Deferred11.frag"
