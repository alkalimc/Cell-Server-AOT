#version 450

#include "/programs/shadowcomp/Shadowcomp2.frag"
