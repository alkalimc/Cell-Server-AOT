#version 450

#define DEFERRED_REFLECTION
#define BASIC_LIGHT 0.01
#define NETHER

#include "/programs/deferred/Deferred12.frag"
