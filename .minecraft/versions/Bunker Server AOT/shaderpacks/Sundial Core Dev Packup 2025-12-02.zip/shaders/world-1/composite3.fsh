#version 450

#define BASIC_LIGHT 0.01
#define NETHER

#include "/programs/composite/Composite3.frag"
