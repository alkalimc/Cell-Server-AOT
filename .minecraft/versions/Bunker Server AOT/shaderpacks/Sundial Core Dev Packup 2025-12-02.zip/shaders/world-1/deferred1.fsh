#version 450

#define NETHER

#include "/programs/deferred/Deferred1.frag"
