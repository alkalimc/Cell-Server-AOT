#version 450

#include "/programs/shadowcomp/Shadowcomp6.frag"
