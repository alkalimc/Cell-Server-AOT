#version 450

#define SHADOW_AND_SKY
#define BASIC_LIGHT 1e-5

#include "/programs/composite/Composite3.frag"
