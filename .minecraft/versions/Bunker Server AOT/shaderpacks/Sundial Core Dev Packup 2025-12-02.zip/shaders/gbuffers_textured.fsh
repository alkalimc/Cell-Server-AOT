#version 450

#define PARTICLE

#include "/programs/gbuffers/Textured.frag"
