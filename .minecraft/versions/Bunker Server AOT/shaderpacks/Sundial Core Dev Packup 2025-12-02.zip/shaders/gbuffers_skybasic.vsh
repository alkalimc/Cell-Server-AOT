#version 450

#include "/programs/gbuffers/SkyBasic.vert"
