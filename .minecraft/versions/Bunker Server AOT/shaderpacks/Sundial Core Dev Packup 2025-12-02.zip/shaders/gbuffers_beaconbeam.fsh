#version 450

#define BEACON
#define EMISSIVE

#include "/programs/gbuffers/Textured.frag"
