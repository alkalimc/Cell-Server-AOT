#version 450

#include "/programs/deferred/Deferred5.comp"
