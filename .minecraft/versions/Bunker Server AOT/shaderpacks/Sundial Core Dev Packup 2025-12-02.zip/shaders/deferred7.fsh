#version 450

#include "/programs/deferred/Deferred7.frag"
