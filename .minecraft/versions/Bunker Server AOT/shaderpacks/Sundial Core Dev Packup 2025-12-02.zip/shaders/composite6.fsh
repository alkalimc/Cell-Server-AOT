#version 450

#define SHADOW_AND_SKY

#include "/programs/composite/Composite6.frag"
