#version 450

#include "/programs/gbuffers/Textured.vert"
