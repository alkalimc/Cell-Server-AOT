#version 450

#define EMISSIVE

#include "/programs/gbuffers/Textured.frag"
