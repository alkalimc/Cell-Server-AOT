#version 450

#define HAND
#define TRANSPARENT

#include "/programs/gbuffers/Textured.frag"
