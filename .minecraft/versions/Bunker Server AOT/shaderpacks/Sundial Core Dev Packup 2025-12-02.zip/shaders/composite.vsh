#version 450

#define SKY_COLOR_UP

#include "/programs/common/Common.vert"
