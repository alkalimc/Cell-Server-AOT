#version 450

#define THE_END

#include "/programs/deferred/Deferred0.comp"
