#version 450

#define BASIC_LIGHT 0.01
#define THE_END

#include "/programs/composite/Composite3.frag"
