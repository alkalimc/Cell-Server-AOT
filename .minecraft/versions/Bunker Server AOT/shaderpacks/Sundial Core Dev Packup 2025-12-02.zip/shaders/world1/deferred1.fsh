#version 450

#define THE_END

#include "/programs/deferred/Deferred1.frag"
