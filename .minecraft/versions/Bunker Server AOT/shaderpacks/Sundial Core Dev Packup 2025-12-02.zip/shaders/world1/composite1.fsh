#version 450

#define THE_END

#include "/programs/composite/Composite1.frag"
