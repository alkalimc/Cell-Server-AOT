#version 450

#include "/programs/deferred/Deferred9.frag"
