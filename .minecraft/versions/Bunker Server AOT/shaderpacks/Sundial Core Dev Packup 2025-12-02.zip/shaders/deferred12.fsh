#version 450

#define DEFERRED_REFLECTION
#define SHADOW_AND_SKY
#define BASIC_LIGHT 1e-5

#include "/programs/deferred/Deferred12.frag"
