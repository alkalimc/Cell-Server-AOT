vec4 globalIlluminationFilter(vec2 offset) {
    ivec2 originTexel = ivec2(texcoord * screenSize);

    vec4 originBlendedColor = texelFetch(colortex5, originTexel, 0);
    float originDepth = texelFetch(depthtex1, originTexel, 0).r;
    #ifdef LOD
        originDepth -= float(originDepth == 1.0) * (1.0 + getLodDepthSolidDeferred(texcoord));
    #endif
    if (abs(originDepth) < 0.999999) {
        vec3 originSampleData = texelFetch(colortex6, originTexel, 0).rgb;
        #ifdef SHARP_GI_FILTER
            originSampleData = originBlendedColor.rgb;
        #endif

        float originVariance = originBlendedColor.a;
        float dotOriginColor = dot(originSampleData, originSampleData) + 1e-6;

        vec3 originNormal;
        vec3 originGeoNormal;
        getBothNormalsTexel(originTexel, originNormal, originGeoNormal);
        vec3 originViewPos;
        #ifdef LOD
            if (originDepth < 0.0) {
                originViewPos = screenToViewPosLod(texcoord, -originDepth);
            } else
        #endif
        {
            originViewPos = screenToViewPos(texcoord, originDepth);
        }
        float normalVarianceFactor = GI_DENOISER_NORMAL_STRICTNESS * exp2(-0.15 / (inversesqrt(dot(originViewPos, originViewPos)) * dotOriginColor) * originVariance);

        ivec2 coordOffset = ivec2(offset * (2.0 * blueNoiseTemporal(texcoord).x + 1.0) * exp(-0.1 / (originVariance + 0.2)) + 0.5);

        vec3 blendedFrameAccumulation = originBlendedColor.rgb;
        float varianceAccumlation = originVariance;
        float weightAccumulation = 1.0;
        for (int i = 0; i < 2; i++) {
            ivec2 sampleTexel = originTexel + coordOffset;
            coordOffset = -coordOffset;
            vec2 sampleCoord = (sampleTexel + 0.5) * texelSize;
            if (all(lessThan(sampleCoord - 0.5, vec2(0.5)))) {
                vec3 sampleNormal, sampleGeoNormal;
                getBothNormalsTexel(sampleTexel, sampleNormal, sampleGeoNormal);
                vec3 sampleData = texelFetch(colortex6, sampleTexel, 0).rgb;
                float sampleDepth = textureLod(depthtex1, sampleCoord, 0.0).r;
                vec3 sampleViewPos;
                #ifdef LOD
                    if (sampleDepth == 1.0) {
                        sampleDepth = getLodDepthSolidDeferred(sampleCoord);
                        sampleViewPos = screenToViewPosLod(sampleCoord, sampleDepth);
                    } else
                #endif
                {
                    sampleViewPos = screenToViewPos(sampleCoord, sampleDepth);
                }

                vec4 sampleBlendedData = texelFetch(colortex5, sampleTexel, 0);
                #ifdef SHARP_GI_FILTER
                    sampleData = sampleBlendedData.rgb;
                #endif
                vec3 colorDiff = originSampleData - sampleData;
                float sampleWeight =
                    clamp(exp(-dot(colorDiff, colorDiff) * inversesqrt(originVariance * max(dot(sampleData, sampleData), dotOriginColor))) * pow2(originVariance / sampleBlendedData.w), 0.0, 1.0) *
                    exp2(
                        -144.269502 * abs(dot(sampleViewPos - originViewPos, originGeoNormal)) +
                        normalVarianceFactor * log2(clamp(dot(sampleNormal, originNormal), 0.0, 1.0)) +
                        64.0 * log2(clamp(dot(sampleGeoNormal, originGeoNormal), 0.0, 1.0))
                    );
                sampleWeight = clamp(sampleWeight, 0.0, 1.0);

                blendedFrameAccumulation += sampleBlendedData.rgb * sampleWeight;
                varianceAccumlation += sampleBlendedData.w * sampleWeight * sampleWeight;
                weightAccumulation += sampleWeight;
            }
        }
        vec4 blendedColor;
        blendedColor.rgb = blendedFrameAccumulation / weightAccumulation;
        blendedColor.w = varianceAccumlation / (weightAccumulation * weightAccumulation);
        originBlendedColor = blendedColor;
    }
    return originBlendedColor;
}
