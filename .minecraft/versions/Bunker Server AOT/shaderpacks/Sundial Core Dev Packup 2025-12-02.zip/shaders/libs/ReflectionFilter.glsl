vec4 reflectionFilter(float offset, bool useNoise) {
    ivec2 centerTexel = ivec2(texcoord * screenSize);

    vec4 originData = texelFetch(colortex4, centerTexel, 0);
    float reflectionDepth = texelFetch(colortex5, centerTexel, 0).w;
    if (originData.w > 0.0025) {
        float totalSmoothness = 1.0 - sqrt(originData.w);
        float roughnessInv = 100.0 / max(originData.w, 1e-5);
        vec2 coordOffset = vec2(4.0 * offset * clamp(originData.w * 20.0, 0.0, 1.0) * (1.0 - exp(-reflectionDepth * 1000.0)));
        if (useNoise) {
            coordOffset *= blueNoiseTemporal(texcoord).x + 0.5;
        }

        vec3 originNormal = getNormalTexel(centerTexel);

        vec4 accumulation = originData;
        float weightAccumulation = 1.0;
        vec2 centerTexelCoord = centerTexel + 0.5;

        for (int i = -REFLECTION_FILTER; i < REFLECTION_FILTER + 1; i++) {
            for (int j = -REFLECTION_FILTER; j < REFLECTION_FILTER + 1; j++) {
                ivec2 sampleTexel = ivec2(centerTexelCoord + vec2(i, j) * coordOffset);
                vec4 sampleData = texelFetch(colortex4, sampleTexel, 0);
                float sampleReflectionDepth = texelFetch(colortex5, sampleTexel, 0).w;
                vec3 sampleNormal = getNormalTexel(sampleTexel);

                float weight =
                    exp2(
                        roughnessInv * log2(max(dot(originNormal, sampleNormal), 1e-6)) +
                        100.0 * log2(1.0 - abs(originData.w - sampleData.w)) -
                        1.44269502 * abs(reflectionDepth - sampleReflectionDepth) * totalSmoothness
                    ) *
                    step(0.0025, sampleData.w);
                weight = clamp(weight, 0.0, 1.0);
                if (abs(i) != -abs(j) && all(lessThan(sampleTexel * texelSize - 0.5, vec2(0.5)))) {
                    accumulation += sampleData * weight;
                    weightAccumulation += weight;
                }
            }
        }
        originData = accumulation / weightAccumulation;
    }
    return originData;
}
