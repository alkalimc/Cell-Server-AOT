vec3 getVoxelIndex(ivec2 texel) {
    vec2 texelcoord = vec2(texel);
    vec3 voxelPos = vec3(0);
    float areaCountY = floor(texelcoord.y / voxelizationDiameter);
    voxelPos.z = texelcoord.y - areaCountY * voxelizationDiameter;
    float totalLengthX = areaCountY * voxelMapResolution + texelcoord.x;
    voxelPos.y = floor(totalLengthX / voxelizationDiameter);
    voxelPos.x = totalLengthX - voxelPos.y * voxelizationDiameter;
    return voxelPos;
}

bool isVoxelIndexValid(vec3 voxelIndex) {
    vec3 voxelDistance = abs(voxelIndex / voxelizationRadius - 1.0 + 0.5 / voxelizationRadius);
    return (voxelDistance.x < 1.0 && voxelDistance.z < 1.0 && voxelDistance.y < 1.0);
}

void normalizeVoxelTexel(inout ivec2 texelcoord) {
    int outOfRange = int(floor(texelcoord.x / voxelMapResolution));
    texelcoord.y += outOfRange * int(voxelizationDiameter);
    texelcoord.x -= outOfRange * int(voxelMapResolution);
}

void spreadManhattanDistance(ivec2 texelcoord, vec4 data, vec4 centerDistance) {
    if (data.r > 4.6 / 5.0 && data.a > 0.999) {
        imageStore(shadowcolorimg0, texelcoord, centerDistance);
    }
}

void spreadManhattanDistanceX(float voxelIndexX, ivec2 texelcoord, vec4 centerDistance) {
    normalizeVoxelTexel(texelcoord);
    vec4 neighborData = texelFetch(shadowcolor0, texelcoord, 0);
    if (abs(voxelIndexX / voxelizationRadius.x - 1.0 + 0.5 / voxelizationRadius.x) < 1.0 && texelcoord.y < int(voxelMapResolution)) {
        spreadManhattanDistance(texelcoord, neighborData, centerDistance);
    }
}

void spreadManhattanDistanceY(float voxelIndexY, ivec2 texelcoord, vec4 centerDistance) {
    normalizeVoxelTexel(texelcoord);
    vec4 neighborData = texelFetch(shadowcolor0, texelcoord, 0);
    if (abs(voxelIndexY / voxelizationRadius.y - 1.0 + 0.5 / voxelizationRadius.y) < 1.0 && texelcoord.y < int(voxelMapResolution)) {
        spreadManhattanDistance(texelcoord, neighborData, centerDistance);
    }
}

void spreadManhattanDistanceZ(float voxelIndexZ, ivec2 texelcoord, vec4 centerDistance) {
    vec4 neighborData = texelFetch(shadowcolor0, texelcoord, 0);
    if (abs(voxelIndexZ / voxelizationRadius.z - 1.0 + 0.5 / voxelizationRadius.z) < 1.0 && texelcoord.y < int(voxelMapResolution)) {
        spreadManhattanDistance(texelcoord, neighborData, centerDistance);
    }
}

void buildManhattanDistanceField(float level) {
    ivec2 texelcoord = ivec2(gl_FragCoord.st);
    vec4 centerData = texelFetch(shadowcolor0, texelcoord, 0);
    float centerDistance = centerData.r;
    centerDistance -= float(centerData.a < 0.999);
    if (centerDistance > (level - 0.3) / 5.0 && centerDistance < (level + 0.6) / 5.0) {
        centerDistance += 1.0 / 5.0;
        vec4 centerDistanceData = vec4(centerDistance, 1.0, 1.0, 1.0);

        vec3 voxelIndex = getVoxelIndex(texelcoord);
        if (isVoxelIndexValid(voxelIndex)) {
            spreadManhattanDistanceX(voxelIndex.x - 1.0, texelcoord - ivec2(1, 0), centerDistanceData);
            spreadManhattanDistanceX(voxelIndex.x + 1.0, texelcoord + ivec2(1, 0), centerDistanceData);
            spreadManhattanDistanceY(voxelIndex.y - 1.0, texelcoord - ivec2(int(voxelizationDiameter), 0), centerDistanceData);
            spreadManhattanDistanceY(voxelIndex.y + 1.0, texelcoord + ivec2(int(voxelizationDiameter), 0), centerDistanceData);
            spreadManhattanDistanceZ(voxelIndex.z - 1.0, texelcoord - ivec2(0, 1), centerDistanceData);
            spreadManhattanDistanceZ(voxelIndex.z + 1.0, texelcoord + ivec2(0, 1), centerDistanceData);
        }
    }
}
