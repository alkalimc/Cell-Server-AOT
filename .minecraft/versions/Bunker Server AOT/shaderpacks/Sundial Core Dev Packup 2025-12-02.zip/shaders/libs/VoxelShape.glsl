vec4 getTargetAlbedo(
    Ray ray, sampler2D albedoSampler, vec3 originOffset, vec2 atlasTiles, vec3 baseColor, vec2 centerCoord, vec3 targetNormal, float rayLength,
    vec2 basicCoordOffset, vec2 basicCoordScale, float lod
) {
    vec3 rayHitPos = ray.direction * rayLength + originOffset;
    float yAxis = abs(targetNormal.y);
    vec2 targetTangent = vec2(yAxis + targetNormal.z, -targetNormal.x);
    vec2 targetBitangent = vec2(yAxis - 1.0, targetNormal.y);
    vec2 coordOffset = vec2(dot(targetTangent, rayHitPos.xz), dot(targetBitangent, rayHitPos.yz));
    vec2 targetCoord = (coordOffset * 0.9999 + basicCoordOffset) * basicCoordScale / atlasTiles + centerCoord;
    vec4 texColor = textureLod(albedoSampler, targetCoord, lod) * vec4(baseColor, 1.0);
    return texColor;
}

vec4 getTargetAlbedo(
    Ray ray, sampler2D albedoSampler, vec3 originOffset, vec2 atlasTiles, vec3 baseColor, vec2 centerCoord, vec3 targetNormal, float rayLength,
    vec2 basicCoordOffset, vec2 basicCoordScale, float lod, out vec2 targetCoord, out vec3 targetTangent
) {
    vec3 rayHitPos = ray.direction * rayLength + originOffset;
    float yAxis = abs(targetNormal.y);
    targetTangent = signMul(vec3(yAxis + targetNormal.z, 0.0, -targetNormal.x), vec3(basicCoordScale.x));
    vec3 targetBitangent = signMul(vec3(0.0, yAxis - 1.0, targetNormal.y), vec3(basicCoordScale.y));
    vec2 coordOffset = vec2(dot(targetTangent.xz, rayHitPos.xz), dot(targetBitangent.yz, rayHitPos.yz));
    targetCoord = (coordOffset * 0.9999 + basicCoordOffset) * abs(basicCoordScale) / atlasTiles + centerCoord;
    vec4 texColor = textureLod(albedoSampler, targetCoord, lod) * vec4(baseColor, 1.0);
    return texColor;
}

vec4 getTargetAlbedoRotated(
    Ray ray, sampler2D albedoSampler, vec3 originOffset, vec2 atlasTiles, vec2 centerCoord, vec3 targetNormal, float rayLength,
    vec2 basicCoordOffset, vec2 basicCoordScale, float lod
) {
    vec3 rayHitPos = ray.direction * rayLength + originOffset;
    float yAxis = abs(targetNormal.y);
    vec2 targetTangent = vec2(yAxis - 1.0, targetNormal.y);
    vec2 targetBitangent = vec2(yAxis + targetNormal.z, -targetNormal.x);
    vec2 coordOffset = vec2(dot(targetTangent, rayHitPos.yz), dot(targetBitangent, rayHitPos.xz));
    vec2 targetCoord = (coordOffset * 0.9999 + basicCoordOffset) * basicCoordScale / atlasTiles + centerCoord;
    vec4 texColor = textureLod(albedoSampler, targetCoord, lod);
    return texColor;
}

vec4 getTargetAlbedoRotated(
    Ray ray, sampler2D albedoSampler, vec3 originOffset, vec2 atlasTiles, vec3 baseColor, vec2 centerCoord, vec3 targetNormal, float rayLength,
    vec2 basicCoordOffset, vec2 basicCoordScale, float lod, out vec2 targetCoord, out vec3 targetTangent
) {
    vec3 rayHitPos = ray.direction * rayLength + originOffset;
    float yAxis = abs(targetNormal.y);
    targetTangent = signMul(vec3(0.0, yAxis - 1.0, targetNormal.y), vec3(basicCoordScale.x));
    vec3 targetBitangent = signMul(vec3(yAxis + targetNormal.z, 0.0, -targetNormal.x), vec3(basicCoordScale.y));
    vec2 coordOffset = vec2(dot(targetTangent.yz, rayHitPos.yz), dot(targetBitangent.xz, rayHitPos.xz));
    targetCoord = (coordOffset * 0.9999 + basicCoordOffset) * abs(basicCoordScale) / atlasTiles + centerCoord;
    vec4 texColor = textureLod(albedoSampler, targetCoord, lod) * vec4(baseColor, 1.0);
    return texColor;
}

bool isRayHitElement(Ray ray, vec3 cubeOrigin, vec3 cubeSize, inout float rayLength, inout vec3 targetNormal) {
    vec3 rayLength1 = ray.dirInv * (cubeOrigin - ray.origin);
    vec3 rayLength2 = rayLength1 + ray.dirInv * (cubeSize + 2e-5);
    vec3 lengthRequired = min(rayLength2, rayLength1);
    vec3 lengthAttachable = max(rayLength2, rayLength1);
    float hitLength = max(lengthRequired.x, max(lengthRequired.y, lengthRequired.z));
    float maxLength = min(lengthAttachable.x, min(lengthAttachable.y, lengthAttachable.z));
    float finalLength = max(0.0, hitLength);
    bool hit = min(rayLength, maxLength) > finalLength;
    if (hit) {
        targetNormal = step(vec3(hitLength), lengthRequired) * -ray.dirSigned;
        rayLength = finalLength;
    }
    return hit;
}

bool isRayHitElementCutout(
    Ray ray, sampler2D albedoSampler, vec3 originOffset, vec2 atlasTiles, vec2 centerCoord, vec3 cubeOrigin, vec3 cubeSize,
    vec2 basicCoordOffset, vec2 basicCoordScale, vec2 spreadData, inout float rayLength, inout vec3 targetNormal
) {
    vec3 rayLength1 = ray.dirInv * (cubeOrigin - ray.origin);
    vec3 rayLength2 = rayLength1 + ray.dirInv * (cubeSize + 2e-5);
    vec3 lengthRequired = min(rayLength2, rayLength1);
    vec3 lengthAttachable = max(rayLength2, rayLength1);
    float hitLength = max(lengthRequired.x, max(lengthRequired.y, lengthRequired.z));
    float maxLength = min(lengthAttachable.x, min(lengthAttachable.y, lengthAttachable.z));
    vec3 tempNormal = step(vec3(hitLength), lengthRequired) * -ray.dirSigned;
    float lod = log2(spreadData.x + spreadData.y * hitLength);
    vec4 tempAlbedo = getTargetAlbedo(
        ray, albedoSampler, originOffset, atlasTiles, vec3(1.0), centerCoord, tempNormal, hitLength,
        basicCoordOffset, basicCoordScale, lod
    );
    float finalLength = max(0.0, hitLength);
    bool hit = min(rayLength, maxLength) > finalLength && tempAlbedo.a > 0.0;
    if (hit) {
        targetNormal = tempNormal;
        rayLength = finalLength;
    }
    return hit;
}

bool isRayHitElementCutout(
    Ray ray, sampler2D albedoSampler, vec3 originOffset, vec2 atlasTiles, vec2 centerCoord, vec3 cubeOrigin, vec3 cubeSize,
    vec2 basicCoordOffset, vec2 basicCoordScale, vec3 normalFactor, vec2 spreadData, inout float rayLength, inout vec3 targetNormal
) {
    vec3 rayLength1 = ray.dirInv * (cubeOrigin - ray.origin);
    vec3 rayLength2 = rayLength1 + ray.dirInv * (cubeSize + 2e-5);
    vec3 lengthRequired = min(rayLength2, rayLength1);
    vec3 lengthAttachable = max(rayLength2, rayLength1);
    float hitLength = max(lengthRequired.x, max(lengthRequired.y, lengthRequired.z));
    float maxLength = min(lengthAttachable.x, min(lengthAttachable.y, lengthAttachable.z));
    vec3 tempNormal = step(vec3(hitLength), lengthRequired) * -ray.dirSigned;
    normalFactor *= tempNormal;
    basicCoordScale = signMul(basicCoordScale, vec2(0.5 + normalFactor.x + normalFactor.z, normalFactor.y + 0.5));
    float lod = log2(spreadData.x + spreadData.y * hitLength);
    vec4 tempAlbedo = getTargetAlbedo(
        ray, albedoSampler, originOffset, atlasTiles, vec3(1.0), centerCoord, tempNormal, hitLength,
        basicCoordOffset, basicCoordScale, lod
    );
    float finalLength = max(0.0, hitLength);
    bool hit = min(rayLength, maxLength) > finalLength && tempAlbedo.a > 0.0;
    if (hit) {
        targetNormal = tempNormal;
        rayLength = finalLength;
    }
    return hit;
}

bool isRayHitElementCutoutRotated(
    Ray ray, sampler2D albedoSampler, vec3 originOffset, vec2 atlasTiles, vec2 centerCoord, vec3 cubeOrigin, vec3 cubeSize,
    vec2 basicCoordOffset, vec2 basicCoordScale, vec3 normalFactor, vec2 spreadData, inout float rayLength, inout vec3 targetNormal
) {
    vec3 rayLength1 = ray.dirInv * (cubeOrigin - ray.origin);
    vec3 rayLength2 = rayLength1 + ray.dirInv * (cubeSize + 2e-5);
    vec3 lengthRequired = min(rayLength2, rayLength1);
    vec3 lengthAttachable = max(rayLength2, rayLength1);
    float hitLength = max(lengthRequired.x, max(lengthRequired.y, lengthRequired.z));
    float maxLength = min(lengthAttachable.x, min(lengthAttachable.y, lengthAttachable.z));
    vec3 tempNormal = -step(vec3(hitLength), lengthRequired) * ray.dirSigned;
    normalFactor *= tempNormal;
    basicCoordScale = signMul(basicCoordScale, vec2(normalFactor.y + 0.5, 0.5 + normalFactor.x + normalFactor.z));
    float lod = log2(spreadData.x + spreadData.y * hitLength);
    vec4 tempAlbedo = getTargetAlbedoRotated(
        ray, albedoSampler, originOffset, atlasTiles, centerCoord, tempNormal, hitLength,
        basicCoordOffset, basicCoordScale, lod
    );
    float finalLength = max(0.0, hitLength);
    bool hit = min(rayLength, maxLength) > finalLength && tempAlbedo.a > 0.0;
    if (hit) {
        targetNormal = tempNormal, rayLength = finalLength;
    }
    return hit;
}

bool isRayHitElementTransparent(
    Ray ray, sampler2D albedoSampler, vec3 originOffset, vec2 atlasTiles, vec3 baseColor, vec2 centerCoord, vec3 cubeOrigin, vec3 cubeSize,
    vec2 basicCoordOffset, vec2 basicCoordScale, vec2 spreadData, inout vec4 stainedColor, inout float rayLength, inout vec3 targetNormal
) {
    vec3 rayLength1 = ray.dirInv * (cubeOrigin - ray.origin);
    vec3 rayLength2 = rayLength1 + ray.dirInv * (cubeSize + 2e-5);
    vec3 lengthRequired = min(rayLength2, rayLength1);
    vec3 lengthAttachable = max(rayLength2, rayLength1);
    float hitLength = max(lengthRequired.x, max(lengthRequired.y, lengthRequired.z));
    float maxLength = min(lengthAttachable.x, min(lengthAttachable.y, lengthAttachable.z));
    vec3 tempNormal = step(vec3(hitLength), lengthRequired) * -ray.dirSigned;
    float lod = log2(spreadData.x + spreadData.y * hitLength);
    vec4 tempAlbedo = getTargetAlbedo(
        ray, albedoSampler, originOffset, atlasTiles, baseColor, centerCoord, tempNormal, hitLength,
        basicCoordOffset, basicCoordScale, lod
    );
    bool hit = false;
    float finalLength = max(0.0, hitLength);
    if (abs(tempAlbedo.a - 0.5) < 0.499 && hitLength < maxLength && hitLength > 0.0) {
        stainedColor.rgb *= pow(tempAlbedo.rgb, vec3(sqrt(tempAlbedo.w * 1.5)));
        stainedColor.a = 0.666667;
        hit = true;
        #ifdef GLOBAL_ILLUMINATION
            if (min(rayLength, maxLength) > finalLength) {
                targetNormal = tempNormal;
                rayLength = finalLength;
            }
        #endif
    } else {
        hit = min(rayLength, maxLength) > finalLength && tempAlbedo.a > 0.0;
        if (hit) {
            targetNormal = tempNormal;
            rayLength = finalLength;
        }
    }
    return hit;
}

bool isRayHitBlock(
    Ray ray, sampler2D albedoSampler, vec2 atlasTiles, vec3 baseColor, vec4 voxelData, vec3 voxelPos, vec2 spreadData,
    inout vec4 targetAlbedo, inout vec2 targetCoord, inout float rayLength, inout vec3 targetNormal, inout vec3 targetTangent, out float emissiveScale
) {
    ray.origin -= voxelPos;
    vec3 originOffset = ray.origin - vec3(0.5);
    ray.origin += 1e-5;
    vec2 centerCoord = (floor(voxelData.xy * atlasTiles) + 0.5) / atlasTiles;
    float materialID = voxelData.z;
    emissiveScale = 1.0;

    bool hit = false, elementHit = false;
    if (materialID < 1.5) {
        float opaque = float(materialID > 0.5);
        hit = isRayHitElement(ray, vec3(0.0), vec3(1.0), rayLength, targetNormal);
        float lod = log2(spreadData.x + spreadData.y * rayLength);
        targetAlbedo = getTargetAlbedo(ray, albedoSampler, originOffset, atlasTiles, baseColor, centerCoord, targetNormal, rayLength, vec2(0.0), vec2(1.0), lod, targetCoord, targetTangent);
        targetAlbedo.a += opaque;
        emissiveScale = mix(1.0, dot(targetAlbedo.rgb, targetAlbedo.rgb), opaque);
    }
    #if PATH_TRACE_GEOMETRY_QUALITY > 0
    else if (materialID < 18.5) {
        float bottomOffset = clamp(materialID * 0.5 - 8.0, 0.0, 1.0) - clamp(materialID * (3.0 / 16.0) - 51.0 / 16.0, 0.0, 1.0);
        float elementHeight = clamp(materialID / 16.0 - 1.0 / 16.0, 0.0, 1.0) - bottomOffset;
        hit = isRayHitElement(ray, vec3(0.0, bottomOffset, 0.0), vec3(1.0, elementHeight, 1.0), rayLength, targetNormal);
        float lod = log2(spreadData.x + spreadData.y * rayLength);
        targetAlbedo = getTargetAlbedo(ray, albedoSampler, originOffset, atlasTiles, baseColor, centerCoord, targetNormal, rayLength, vec2(0.0), vec2(1.0), lod, targetCoord, targetTangent);
        targetAlbedo.a += float(materialID != 4 && materialID != 18);
    }
    else if (materialID < 42.5) {
        hit = isRayHitElement(ray, vec3(0.0, float(materialID > 30.5) * 0.5, 0.0), vec3(1.0, 0.5, 1.0), rayLength, targetNormal);
        float stairShape = mod(materialID - 19.0, 12.0);
        float stairFacing = mod(stairShape, 4.0);
        if (stairShape < 7.5) {
            vec3 elementOrigin = vec3(float(stairFacing == 3.0) * 0.5, 0.0, float(stairFacing == 2.0) * 0.5);
            vec3 elementSize = mix(vec3(1.0, 1.0, 0.5), vec3(0.5, 1.0, 1.0), mod(stairShape, 2.0));
            elementHit = isRayHitElement(ray, elementOrigin, elementSize, rayLength, targetNormal);
            hit = hit || elementHit;
        }
        if (stairShape > 3.5) {
            vec3 elementOrigin = vec3(float(abs(stairFacing - 1.5) < 1.0) * 0.5, 0.0, float(stairFacing < 1.5) * 0.5);
            elementHit = isRayHitElement(ray, elementOrigin, vec3(0.5, 1.0, 0.5), rayLength, targetNormal);
            hit = hit || elementHit;
        }
        float lod = log2(spreadData.x + spreadData.y * rayLength);
        targetAlbedo = getTargetAlbedo(ray, albedoSampler, originOffset, atlasTiles, baseColor, centerCoord, targetNormal, rayLength, vec2(0.0), vec2(1.0), lod, targetCoord, targetTangent);
        targetAlbedo.a = 1.0;
    }
    else if (materialID < 46.5) {
        vec3 elementOrigin = vec3(float(materialID == 46.0) * 13.0 / 16.0, 0.0, float(materialID == 44.0) * 13.0 / 16.0);
        vec3 elementSize = mix(vec3(3.0 / 16.0, 1.0, 1.0), vec3(1.0, 1.0, 3.0 / 16.0), float(materialID < 44.5));
        hit = isRayHitElement(ray, elementOrigin, elementSize, rayLength, targetNormal);
        float lod = log2(spreadData.x + spreadData.y * rayLength);
        targetAlbedo = getTargetAlbedo(ray, albedoSampler, originOffset, atlasTiles, baseColor, centerCoord, targetNormal, rayLength, vec2(0.0), vec2(1.0), lod, targetCoord, targetTangent);
    }
    else if (materialID < 62.5) {
        hit = isRayHitElement(ray, vec3(6.0 / 16.0, 0.0, 6.0 / 16.0), vec3(4.0 / 16.0, 1.0, 4.0 / 16.0), rayLength, targetNormal);
        float eastWest = mod(materialID, 4.0);
        if (eastWest != 3.0) {
            float startPos = float(eastWest == 1.0) * 0.5, size = float(eastWest == 2.0) * 0.5 + 0.5;
            elementHit = isRayHitElement(ray, vec3(startPos, 6.0 / 16.0, 7.0 / 16.0), vec3(size, 3.0 / 16.0, 2.0 / 16.0), rayLength, targetNormal);
            hit = hit || elementHit;
            elementHit = isRayHitElement(ray, vec3(startPos, 12.0 / 16.0, 7.0 / 16.0), vec3(size, 3.0 / 16.0, 2.0 / 16.0), rayLength, targetNormal);
            hit = hit || elementHit;
        }
        if (materialID > 50.5) {
            float startPos = float(materialID < 54.5) * 0.5, size = float(materialID > 58.5) * 0.5 + 0.5;
            elementHit = isRayHitElement(ray, vec3(7.0 / 16.0, 6.0 / 16.0, startPos), vec3(2.0 / 16.0, 3.0 / 16.0, size), rayLength, targetNormal);
            hit = hit || elementHit;
            elementHit = isRayHitElement(ray, vec3(7.0 / 16.0, 12.0 / 16.0, startPos), vec3(2.0 / 16.0, 3.0 / 16.0, size), rayLength, targetNormal);
            hit = hit || elementHit;
        }
        float lod = log2(spreadData.x + spreadData.y * rayLength);
        targetAlbedo = getTargetAlbedo(ray, albedoSampler, originOffset, atlasTiles, baseColor, centerCoord, targetNormal, rayLength, vec2(0.0), vec2(1.0), lod, targetCoord, targetTangent);
        targetAlbedo.a = 1.0;
    }
    else if (materialID < 65.5) {
        vec3 elementSize = vec3(14.0 / 16.0, 0.5 / 16.0, 14.0 / 16.0);
        elementSize.y += (1.0 / 32.0) * materialID + max(14.5 / 16.0 * materialID - 959.5 / 16.0, -31.5 / 16.0);
        hit = isRayHitElement(ray, vec3(1.0 / 16.0, 0.0, 1.0 / 16.0), elementSize, rayLength, targetNormal);
        float lod = log2(spreadData.x + spreadData.y * rayLength);
        targetAlbedo = getTargetAlbedo(ray, albedoSampler, originOffset, atlasTiles, baseColor, centerCoord, targetNormal, rayLength, vec2(0.0), vec2(1.0), lod, targetCoord, targetTangent);
        targetAlbedo.a = 1.0;
    }
    else if (materialID < 146.5) {
        hit = isRayHitElement(ray, vec3(4.0 / 16.0, 0.0, 4.0 / 16.0), vec3(8.0 / 16.0, 1.0, 8.0 / 16.0), rayLength, targetNormal);
        float wallID = materialID - 66.0;
        float north = floor(wallID / 27.0);
        wallID -= 27.0 * north;
        float south = floor(wallID / 9.0);
        wallID -= 9.0 * south;
        float east = floor(wallID / 3.0);
        wallID -= 3.0 * east;
        float west = wallID;
        if (west > 0.0) {
            elementHit = isRayHitElement(ray, vec3(0.0, 0.0, 5.0 / 16.0), vec3(8.0, west * 2.0 + 12.0, 6.0) / 16.0, rayLength, targetNormal);
            hit = hit || elementHit;
        }
        if (east > 0.0) {
            elementHit = isRayHitElement(ray, vec3(0.5, 0.0, 5.0 / 16.0), vec3(8.0, east * 2.0 + 12.0, 6.0) / 16.0, rayLength, targetNormal);
            hit = hit || elementHit;
        }
        if (south > 0.0) {
            elementHit = isRayHitElement(ray, vec3(5.0 / 16.0, 0.0, 0.5), vec3(6.0, south * 2.0 + 12.0, 8.0) / 16.0, rayLength, targetNormal);
            hit = hit || elementHit;
        }
        if (north > 0.0) {
            elementHit = isRayHitElement(ray, vec3(5.0 / 16.0, 0.0, 0.0), vec3(6.0, north * 2.0 + 12.0, 8.0) / 16.0, rayLength, targetNormal);
            hit = hit || elementHit;
        }
        float lod = log2(spreadData.x + spreadData.y * rayLength);
        targetAlbedo = getTargetAlbedo(ray, albedoSampler, originOffset, atlasTiles, baseColor, centerCoord, targetNormal, rayLength, vec2(0.0), vec2(1.0), lod, targetCoord, targetTangent);
        targetAlbedo.a = 1.0;
    }
    else if (materialID < 154.5) {
        float wallID = materialID - 146.0;
        float eastWest = mod(wallID, 3.0);
        if (wallID > 2.5) {
            float height = wallID > 5.5 ? 1.0 : (14.0 / 16.0);
            elementHit = isRayHitElement(ray, vec3(5.0 / 16.0, 0.0, 0.0), vec3(6.0 / 16.0, height, 1.0), rayLength, targetNormal);
            hit = hit || elementHit;
        }
        if (eastWest > 0.5) {
            float height = eastWest > 1.5 ? 1.0 : (14.0 / 16.0);
            elementHit = isRayHitElement(ray, vec3(0.0, 0.0, 5.0 / 16.0), vec3(1.0, height, 6.0 / 16.0), rayLength, targetNormal);
            hit = hit || elementHit;
        }
        float lod = log2(spreadData.x + spreadData.y * rayLength);
        targetAlbedo = getTargetAlbedo(ray, albedoSampler, originOffset, atlasTiles, baseColor, centerCoord, targetNormal, rayLength, vec2(0.0), vec2(1.0), lod, targetCoord, targetTangent);
        targetAlbedo.a = 1.0;
    }
    #if PATH_TRACE_GEOMETRY_QUALITY > 1
    else if (materialID < 160.5) {
        float gateID = materialID - 155.0;
        float heightOffset = float(gateID > 2.5) * -3.0;
        float type = gateID + heightOffset;
        elementHit = isRayHitElement(ray, vec3(0.0, 5.0 + heightOffset, 7.0) / 16.0, vec3(2.0, 11.0, 2.0) / 16.0, rayLength, targetNormal);
        hit = hit || elementHit;
        elementHit = isRayHitElement(ray, vec3(14.0, 5.0 + heightOffset, 7.0) / 16.0, vec3(2.0, 11.0, 2.0) / 16.0, rayLength, targetNormal);
        hit = hit || elementHit;
        if (type < 0.5) {
            elementHit = isRayHitElement(ray, vec3(2.0, 6.0 + heightOffset, 7.0) / 16.0, vec3(12.0, 3.0, 2.0) / 16.0, rayLength, targetNormal);
            hit = hit || elementHit;
            elementHit = isRayHitElement(ray, vec3(2.0, 12.0 + heightOffset, 7.0) / 16.0, vec3(12.0, 3.0, 2.0) / 16.0, rayLength, targetNormal);
            hit = hit || elementHit;
            elementHit = isRayHitElement(ray, vec3(6.0, 9.0 + heightOffset, 7.0) / 16.0, vec3(4.0, 3.0, 2.0) / 16.0, rayLength, targetNormal);
        }
        else {
            float direction = 2.0 * type - 3.0;
            vec3 elementOrigin = vec3(0.0, 0.0, 0.5);
            elementHit = isRayHitElement(ray, elementOrigin + vec3(0.0, 6.0 + heightOffset, direction) / 16.0, vec3(2.0, 3.0, direction * 4.0) / 16.0, rayLength, targetNormal);
            hit = hit || elementHit;
            elementHit = isRayHitElement(ray, elementOrigin + vec3(14.0, 6.0 + heightOffset, direction) / 16.0, vec3(2.0, 3.0, direction * 4.0) / 16.0, rayLength, targetNormal);
            hit = hit || elementHit;
            elementHit = isRayHitElement(ray, elementOrigin + vec3(0.0, 12.0 + heightOffset, direction) / 16.0, vec3(2.0, 3.0, direction * 4.0) / 16.0, rayLength, targetNormal);
            hit = hit || elementHit;
            elementHit = isRayHitElement(ray, elementOrigin + vec3(14.0, 12.0 + heightOffset, direction) / 16.0, vec3(2.0, 3.0, direction * 4.0) / 16.0, rayLength, targetNormal);
            hit = hit || elementHit;
            elementHit = isRayHitElement(ray, elementOrigin + vec3(0.0, 6.0 + heightOffset, direction * 5.0) / 16.0, vec3(2.0, 9.0, direction * 2.0) / 16.0, rayLength, targetNormal);
            hit = hit || elementHit;
            elementHit = isRayHitElement(ray, elementOrigin + vec3(14.0, 6.0 + heightOffset, direction * 5.0) / 16.0, vec3(2.0, 9.0, direction * 2.0) / 16.0, rayLength, targetNormal);
        }
        hit = hit || elementHit;
        float lod = log2(spreadData.x + spreadData.y * rayLength);
        targetAlbedo = getTargetAlbedo(ray, albedoSampler, originOffset, atlasTiles, baseColor, centerCoord, targetNormal, rayLength, vec2(0.0), vec2(1.0), lod, targetCoord, targetTangent);
        targetAlbedo.a = 1.0;
    }
    else if (materialID < 166.5) {
        float gateID = materialID - 161.0;
        float heightOffset = float(gateID > 2.5) * -3.0;
        float type = gateID + heightOffset;
        elementHit = isRayHitElement(ray, vec3(7.0, 5.0 + heightOffset, 0.0) / 16.0, vec3(2.0, 11.0, 2.0) / 16.0, rayLength, targetNormal);
        hit = hit || elementHit;
        elementHit = isRayHitElement(ray, vec3(7.0, 5.0 + heightOffset, 14.0) / 16.0, vec3(2.0, 11.0, 2.0) / 16.0, rayLength, targetNormal);
        hit = hit || elementHit;
        if (type < 0.5) {
            elementHit = isRayHitElement(ray, vec3(7.0, 6.0 + heightOffset, 2.0) / 16.0, vec3(2.0, 3.0, 12.0) / 16.0, rayLength, targetNormal);
            hit = hit || elementHit;
            elementHit = isRayHitElement(ray, vec3(7.0, 12.0 + heightOffset, 2.0) / 16.0, vec3(2.0, 3.0, 12.0) / 16.0, rayLength, targetNormal);
            hit = hit || elementHit;
            elementHit = isRayHitElement(ray, vec3(7.0, 9.0 + heightOffset, 6.0) / 16.0, vec3(2.0, 3.0, 4.0) / 16.0, rayLength, targetNormal);
        }
        else {
            float direction = 2.0 * type - 3.0;
            vec3 elementOrigin = vec3(0.5, 0.0, 0.0);
            elementHit = isRayHitElement(ray, elementOrigin + vec3(direction, 6.0 + heightOffset, 0.0) / 16.0, vec3(direction * 4.0, 3.0, 2.0) / 16.0, rayLength, targetNormal);
            hit = hit || elementHit;
            elementHit = isRayHitElement(ray, elementOrigin + vec3(direction, 6.0 + heightOffset, 14.0) / 16.0, vec3(direction * 4.0, 3.0, 2.0) / 16.0, rayLength, targetNormal);
            hit = hit || elementHit;
            elementHit = isRayHitElement(ray, elementOrigin + vec3(direction, 12.0 + heightOffset, 0.0) / 16.0, vec3(direction * 4.0, 3.0, 2.0) / 16.0, rayLength, targetNormal);
            hit = hit || elementHit;
            elementHit = isRayHitElement(ray, elementOrigin + vec3(direction, 12.0 + heightOffset, 14.0) / 16.0, vec3(direction * 4.0, 3.0, 2.0) / 16.0, rayLength, targetNormal);
            hit = hit || elementHit;
            elementHit = isRayHitElement(ray, elementOrigin + vec3(direction * 5.0, 6.0 + heightOffset, 0.0) / 16.0, vec3(direction * 2.0, 9.0, 2.0) / 16.0, rayLength, targetNormal);
            hit = hit || elementHit;
            elementHit = isRayHitElement(ray, elementOrigin + vec3(direction * 5.0, 6.0 + heightOffset, 14.0) / 16.0, vec3(direction * 2.0, 9.0, 2.0) / 16.0, rayLength, targetNormal);
        }
        hit = hit || elementHit;
        float lod = log2(spreadData.x + spreadData.y * rayLength);
        targetAlbedo = getTargetAlbedo(ray, albedoSampler, originOffset, atlasTiles, baseColor, centerCoord, targetNormal, rayLength, vec2(0.0), vec2(1.0), lod, targetCoord, targetTangent);
        targetAlbedo.a = 1.0;
    }
    else if (materialID < 183.5) {
        float height = 12.0 / 16.0 + float(materialID < 167.5) * 4.0 / 16.0;
        float eastWest = mod(max(materialID - 168.0, 0.0), 4.0);
        elementHit = isRayHitElement(ray, vec3(4.0, 0.0, 4.0) / 16.0, vec3(0.5, height, 0.5), rayLength, targetNormal);
        hit = hit || elementHit;
        if (eastWest != 0.0) {
            float startPos = float(eastWest == 2.0) * 0.5, size = float(eastWest == 3.0) * 0.5 + 0.5;
            elementHit = isRayHitElement(ray, vec3(startPos, 0.25, 0.25), vec3(size, 0.5, 0.5), rayLength, targetNormal);
            hit = hit || elementHit;
        }
        if (materialID > 171.5) {
            float startPos = float(materialID < 175.5) * 0.5, size = float(materialID > 179.5) * 0.5 + 0.5;
            elementHit = isRayHitElement(ray, vec3(0.25, 0.25, startPos), vec3(0.5, 0.5, size), rayLength, targetNormal);
            hit = hit || elementHit;
        }
        float lod = log2(spreadData.x + spreadData.y * rayLength);
        targetAlbedo = getTargetAlbedo(ray, albedoSampler, originOffset, atlasTiles, baseColor, centerCoord, targetNormal, rayLength, vec2(0.0), vec2(1.0), lod, targetCoord, targetTangent);
        targetAlbedo.a = 1.0;
    }
    else if (materialID < 191.5) {
        float facing = mod(materialID, 4.0);
        float facingSigned = float(facing > 1.5);
        vec3 elementOrigin = vec3(float(facing != 0.0) * 0.25, 0.25, float(facing != 3.0) * 0.25);
        vec3 elementSize = vec3(0.75 - 0.25 * facingSigned, 0.5, facingSigned * 0.25 + 0.5);
        elementHit = isRayHitElement(ray, elementOrigin, elementSize, rayLength, targetNormal);
        hit = hit || elementHit;
        if (materialID < 187.5) {
            elementHit = isRayHitElement(ray, vec3(0.25, 0.75, 0.25), vec3(0.5, 0.25, 0.5), rayLength, targetNormal);
            hit = hit || elementHit;
        }
        float lod = log2(spreadData.x + spreadData.y * rayLength);
        targetAlbedo = getTargetAlbedo(ray, albedoSampler, originOffset, atlasTiles, baseColor, centerCoord, targetNormal, rayLength, vec2(0.0), vec2(1.0), lod, targetCoord, targetTangent);
        targetAlbedo.a = 1.0;
    }
    else if (materialID < 192.5) {
        elementHit = isRayHitElement(ray, vec3(0.0, 2.0 / 16.0, 2.0 / 16.0), vec3(1.0, 12.0 / 16.0, 12.0 / 16.0), rayLength, targetNormal);
        hit = hit || elementHit;
        elementHit = isRayHitElement(ray, vec3(2.0 / 16.0, 0.0, 2.0 / 16.0), vec3(12.0 / 16.0, 1.0, 12.0 / 16.0), rayLength, targetNormal);
        hit = hit || elementHit;
        elementHit = isRayHitElement(ray, vec3(2.0 / 16.0, 2.0 / 16.0, 0.0), vec3(12.0 / 16.0, 12.0 / 16.0, 1.0), rayLength, targetNormal);
        hit = hit || elementHit;
        float lod = log2(spreadData.x + spreadData.y * rayLength);
        targetAlbedo = getTargetAlbedo(ray, albedoSampler, originOffset, atlasTiles, baseColor, centerCoord, targetNormal, rayLength, vec2(0.0), vec2(1.0), lod, targetCoord, targetTangent);
        targetAlbedo.a = 1.0;
    }
    else if (materialID < 193.5) {
        elementHit = isRayHitElement(ray, vec3(0.0), vec3(1.0, 2.0 / 16.0, 1.0), rayLength, targetNormal);
        hit = hit || elementHit;
        elementHit = isRayHitElement(ray, vec3(0.0, 2.0 / 16.0, 0.0), vec3(1.0, 14.0 / 16.0, 2.0 / 16.0), rayLength, targetNormal);
        hit = hit || elementHit;
        elementHit = isRayHitElement(ray, vec3(0.0, 2.0 / 16.0, 0.0), vec3(2.0 / 16.0, 14.0 / 16.0, 1.0), rayLength, targetNormal);
        hit = hit || elementHit;
        elementHit = isRayHitElement(ray, vec3(0.0, 2.0 / 16.0, 14.0 / 16.0), vec3(1.0, 14.0 / 16.0, 2.0 / 16.0), rayLength, targetNormal);
        hit = hit || elementHit;
        elementHit = isRayHitElement(ray, vec3(14.0 / 16.0, 2.0 / 16.0, 0.0), vec3(2.0 / 16.0, 14.0 / 16.0, 1.0), rayLength, targetNormal);
        hit = hit || elementHit;
        float lod = log2(spreadData.x + spreadData.y * rayLength);
        targetAlbedo = getTargetAlbedo(ray, albedoSampler, originOffset, atlasTiles, baseColor, centerCoord, targetNormal, rayLength, vec2(0.0), vec2(1.0), lod, targetCoord, targetTangent);
        targetAlbedo.a = 1.0;
    }
    else if (materialID < 194.5) {
        elementHit = isRayHitElement(ray, vec3(0.0, 3.0 / 16.0, 0.0), vec3(1.0, 13.0 / 16.0, 2.0 / 16.0), rayLength, targetNormal);
        hit = hit || elementHit;
        elementHit = isRayHitElement(ray, vec3(0.0, 3.0 / 16.0, 2.0 / 16.0), vec3(2.0 / 16.0, 13.0 / 16.0, 12.0 / 16.0), rayLength, targetNormal);
        hit = hit || elementHit;
        elementHit = isRayHitElement(ray, vec3(0.0, 3.0 / 16.0, 14.0 / 16.0), vec3(1.0, 13.0 / 16.0, 2.0 / 16.0), rayLength, targetNormal);
        hit = hit || elementHit;
        elementHit = isRayHitElement(ray, vec3(14.0 / 16.0, 3.0 / 16.0, 2.0 / 16.0), vec3(2.0 / 16.0, 13.0 / 16.0, 12.0 / 16.0), rayLength, targetNormal);
        hit = hit || elementHit;
        elementHit = isRayHitElement(ray, vec3(0.0), vec3(2.0 / 16.0, 3.0 / 16.0, 4.0 / 16.0), rayLength, targetNormal);
        hit = hit || elementHit;
        elementHit = isRayHitElement(ray, vec3(2.0 / 16.0, 0.0, 0.0), vec3(2.0 / 16.0, 3.0 / 16.0, 2.0 / 16.0), rayLength, targetNormal);
        hit = hit || elementHit;
        elementHit = isRayHitElement(ray, vec3(0.0, 0.0, 12.0 / 16.0), vec3(2.0 / 16.0, 3.0 / 16.0, 4.0 / 16.0), rayLength, targetNormal);
        hit = hit || elementHit;
        elementHit = isRayHitElement(ray, vec3(2.0 / 16.0, 0.0, 14.0 / 16.0), vec3(2.0 / 16.0, 3.0 / 16.0, 2.0 / 16.0), rayLength, targetNormal);
        hit = hit || elementHit;
        elementHit = isRayHitElement(ray, vec3(14.0 / 16.0, 0.0, 0.0), vec3(2.0 / 16.0, 3.0 / 16.0, 4.0 / 16.0), rayLength, targetNormal);
        hit = hit || elementHit;
        elementHit = isRayHitElement(ray, vec3(12.0 / 16.0, 0.0, 0.0), vec3(2.0 / 16.0, 3.0 / 16.0, 2.0 / 16.0), rayLength, targetNormal);
        hit = hit || elementHit;
        elementHit = isRayHitElement(ray, vec3(14.0 / 16.0, 0.0, 12.0 / 16.0), vec3(2.0 / 16.0, 3.0 / 16.0, 2.0 / 16.0), rayLength, targetNormal);
        hit = hit || elementHit;
        elementHit = isRayHitElement(ray, vec3(12.0 / 16.0, 0.0, 14.0 / 16.0), vec3(4.0 / 16.0, 3.0 / 16.0, 2.0 / 16.0), rayLength, targetNormal);
        hit = hit || elementHit;
        elementHit = isRayHitElement(ray, vec3(2.0, 3.0, 2.0) / 16.0, vec3(12.0, 1.0 + 11.0 * step(0.4, voxelData.w), 12.0) / 16.0, rayLength, targetNormal);
        hit = hit || elementHit;
        emissiveScale = float(elementHit) * clamp(targetNormal.y, 0.0, 1.0);
        float lod = log2(spreadData.x + spreadData.y * rayLength);
        targetAlbedo = getTargetAlbedo(ray, albedoSampler, originOffset, atlasTiles, baseColor, centerCoord, targetNormal, rayLength, vec2(0.0), vec2(1.0), lod, targetCoord, targetTangent);
        targetAlbedo.a = 1.0;
    }
    else if (materialID < 196.5) {
        float direction = materialID - 195.0;
        elementHit = isRayHitElement(ray, vec3(2.0, 0.0, 2.0) / 16.0, vec3(12.0, 4.0, 12.0) / 16.0, rayLength, targetNormal);
        hit = hit || elementHit;
        elementHit = isRayHitElement(
            ray, vec3(4.0 - direction, 4.0, 3.0 + direction) / 16.0,
            vec3(8.0 + 2.0 * direction, 1.0, 10.0 - 2.0 * direction) / 16.0, rayLength, targetNormal
        );
        hit = hit || elementHit;
        elementHit = isRayHitElement(
            ray, vec3(6.0 - 2.0 * direction, 5.0, 4.0 + 2.0 * direction) / 16.0,
            vec3(4.0 + 4.0 * direction, 5.0, 8.0 - 4.0 * direction) / 16.0, rayLength, targetNormal
        );
        hit = hit || elementHit;
        elementHit = isRayHitElement(
            ray, vec3(3.0 - 3.0 * direction, 10.0, 3.0 * direction) / 16.0,
            vec3(10.0 + 6.0 * direction, 6.0, 16.0 - 6.0 * direction) / 16.0, rayLength, targetNormal
        );
        hit = hit || elementHit;
        float lod = log2(spreadData.x + spreadData.y * rayLength);
        targetAlbedo = getTargetAlbedo(ray, albedoSampler, originOffset, atlasTiles, baseColor, centerCoord, targetNormal, rayLength, vec2(0.0), vec2(1.0), lod, targetCoord, targetTangent);
        targetAlbedo.a = 1.0;
    }
    else if (materialID < 208.5) {
        float pistonID = materialID - 197.0;
        float size = float(pistonID > 5.5) * 0.5 + (4.0 / 16.0);
        float offset = 1.0 - size;
        float offsetDir = mod(pistonID, 6.0);
        vec3 baseOrigin = vec3(float(offsetDir == 2) * offset, float(offsetDir == 4) * offset, float(offsetDir == 0) * offset);
        float axisZ = float(offsetDir < 1.5);
        float axisY = float(offsetDir > 3.5);
        float axisX = axisY + axisZ;
        vec3 baseSize = vec3(size + axisX - size * axisX, 1.0 + size * axisY - axisY, 1.0 + size * axisZ - axisZ);
        vec3 rodOrigin = vec3(6.0 / 16.0 * axisX, 6.0 / 16.0 - 6.0 / 16.0 * axisY, 6.0 / 16.0 - 6.0 / 16.0 * axisZ);
        vec3 rodSize = vec3(1.0 - 12.0 / 16.0 * axisX, 4.0 / 16.0 + 12.0 / 16.0 * axisY, 4.0 / 16.0 + 12.0 / 16.0 * axisZ);
        elementHit = isRayHitElement(ray, baseOrigin, baseSize, rayLength, targetNormal);
        hit = hit || elementHit;
        elementHit = isRayHitElement(ray, rodOrigin, rodSize, rayLength, targetNormal);
        hit = hit || elementHit;
        float lod = log2(spreadData.x + spreadData.y * rayLength);
        targetAlbedo = getTargetAlbedo(ray, albedoSampler, originOffset, atlasTiles, baseColor, centerCoord, targetNormal, rayLength, vec2(0.0), vec2(1.0), lod, targetCoord, targetTangent);
        targetAlbedo.a = 1.0;
    }
    #if PATH_TRACE_GEOMETRY_QUALITY > 2
    else if (materialID < 215.5) {
        float offset = materialID * 2.0 - 418.0;
        hit = isRayHitElement(ray, vec3(1.0 + offset, 0.0, 1.0) / 16.0, vec3(14.0 - offset, 8.0, 14.0) / 16.0, rayLength, targetNormal);
        float lod = log2(spreadData.x + spreadData.y * rayLength);
        targetAlbedo = getTargetAlbedo(ray, albedoSampler, originOffset, atlasTiles, baseColor, centerCoord, targetNormal, rayLength, vec2(0.0), vec2(1.0), lod, targetCoord, targetTangent);
        targetAlbedo.a = 1.0;
    }
    else if (materialID < 219.5) {
        float grindStoneID = materialID - 216.0;
        float axisZ = float(grindStoneID > 1.5);
        float axisY = 1.0 - axisZ;
        float facing = axisZ * 2.0 - grindStoneID;
        float stoneOffsetY = (grindStoneID * 4.0 - 2.0) * axisY;
        float stoneOffsetZ = (grindStoneID * 4.0 - 10.0) * axisZ;
        float baseOffsetY = (stoneOffsetY + facing * axisY) * 3.0 + 6.0;
        float baseOffsetZ = (stoneOffsetZ + facing * axisZ) * 3.0 + 6.0;
        elementHit = isRayHitElement(ray, vec3(4.0, 2.0 - stoneOffsetY, 2.0 - stoneOffsetZ) / 16.0, vec3(8.0, 12.0, 12.0) / 16.0, rayLength, targetNormal);
        hit = hit || elementHit;
        elementHit = isRayHitElement(ray, vec3(2.0, 5.0 - stoneOffsetY, 5.0 - stoneOffsetZ) / 16.0, vec3(12.0, 6.0, 6.0) / 16.0, rayLength, targetNormal);
        hit = hit || elementHit;
        elementHit = isRayHitElement(ray, vec3(2.0, baseOffsetY, baseOffsetZ) / 16.0, vec3(2.0, axisY * 3.0 + 4.0, axisZ * 3.0 + 4.0) / 16.0, rayLength, targetNormal);
        hit = hit || elementHit;
        elementHit = isRayHitElement(ray, vec3(12.0, baseOffsetY, baseOffsetZ) / 16.0, vec3(2.0, axisY * 3.0 + 4.0, axisZ * 3.0 + 4.0) / 16.0, rayLength, targetNormal);
        hit = hit || elementHit;
        float lod = log2(spreadData.x + spreadData.y * rayLength);
        targetAlbedo = getTargetAlbedo(ray, albedoSampler, originOffset, atlasTiles, baseColor, centerCoord, targetNormal, rayLength, vec2(0.0), vec2(1.0), lod, targetCoord, targetTangent);
        targetAlbedo.a = 1.0;
    }
    else if (materialID < 223.5) {
        float grindStoneID = materialID - 220.0;
        float axisX = float(grindStoneID > 1.5);
        float axisY = 1.0 - axisX;
        float facing = axisX * 2.0 - grindStoneID;
        float stoneOffsetY = (grindStoneID * 4.0 - 2.0) * axisY;
        float stoneOffsetX = (grindStoneID * 4.0 - 10.0) * axisX;
        float baseOffsetY = (stoneOffsetY + facing * axisY) * 3.0 + 6.0;
        float baseOffsetX = (stoneOffsetX + facing * axisX) * 3.0 + 6.0;
        elementHit = isRayHitElement(ray, vec3(2.0 - stoneOffsetX, 2.0 - stoneOffsetY, 4.0) / 16.0, vec3(12.0, 12.0, 8.0) / 16.0, rayLength, targetNormal);
        hit = hit || elementHit;
        elementHit = isRayHitElement(ray, vec3(5.0 - stoneOffsetX, 5.0 - stoneOffsetY, 2.0) / 16.0, vec3(6.0, 6.0, 12.0) / 16.0, rayLength, targetNormal);
        hit = hit || elementHit;
        elementHit = isRayHitElement(ray, vec3(baseOffsetX, baseOffsetY, 2.0) / 16.0, vec3(axisX * 3.0 + 4.0, axisY * 3.0 + 4.0, 2.0) / 16.0, rayLength, targetNormal);
        hit = hit || elementHit;
        elementHit = isRayHitElement(ray, vec3(baseOffsetX, baseOffsetY, 12.0) / 16.0, vec3(axisX * 3.0 + 4.0, axisY * 3.0 + 4.0, 2.00) / 16.0, rayLength, targetNormal);
        hit = hit || elementHit;
        float lod = log2(spreadData.x + spreadData.y * rayLength);
        targetAlbedo = getTargetAlbedo(ray, albedoSampler, originOffset, atlasTiles, baseColor, centerCoord, targetNormal, rayLength, vec2(0.0), vec2(1.0), lod, targetCoord, targetTangent);
        targetAlbedo.a = 1.0;
    }
    else if (materialID < 228.5) {
        float hopperID = materialID - 224.0;
        float direction = 12.0 * mod(hopperID, 2.0) - 6.0;
        elementHit = isRayHitElement(ray, vec3(0.0, 11.0, 0.0) / 16.0, vec3(16.0, 5.0, 2.0) / 16.0, rayLength, targetNormal);
        hit = hit || elementHit;
        elementHit = isRayHitElement(ray, vec3(0.0, 11.0, 14.0) / 16.0, vec3(16.0, 5.0, 2.0) / 16.0, rayLength, targetNormal);
        hit = hit || elementHit;
        elementHit = isRayHitElement(ray, vec3(0.0, 11.0, 2.0) / 16.0, vec3(2.0, 5.0, 12.0) / 16.0, rayLength, targetNormal);
        hit = hit || elementHit;
        elementHit = isRayHitElement(ray, vec3(14.0, 11.0, 2.0) / 16.0, vec3(2.0, 5.0, 12.0) / 16.0, rayLength, targetNormal);
        hit = hit || elementHit;
        elementHit = isRayHitElement(ray, vec3(0.0, 10.0, 0.0) / 16.0, vec3(16.0, 1.0, 16.0) / 16.0, rayLength, targetNormal);
        hit = hit || elementHit;
        elementHit = isRayHitElement(ray, vec3(4.0, 4.0, 4.0) / 16.0, vec3(8.0, 6.0, 8.0) / 16.0, rayLength, targetNormal);
        hit = hit || elementHit;
        elementHit = isRayHitElement(
            ray, vec3(6.0 + direction * step(2.5, hopperID), float(hopperID > 0.5) * 4.0, 6.0 + direction * step(abs(hopperID - 1.5), 1.0)) / 16.0,
            vec3(4.0, 4.0, 4.0) / 16.0, rayLength, targetNormal
        );
        hit = hit || elementHit;
        float lod = log2(spreadData.x + spreadData.y * rayLength);
        targetAlbedo = getTargetAlbedo(ray, albedoSampler, originOffset, atlasTiles, baseColor, centerCoord, targetNormal, rayLength, vec2(0.0), vec2(1.0), lod, targetCoord, targetTangent);
    }
    else if (materialID < 229.5) {
        elementHit = isRayHitElement(ray, vec3(0.0), vec3(16.0, 2.0, 16.0) / 16.0, rayLength, targetNormal);
        hit = hit || elementHit;
        elementHit = isRayHitElement(ray, vec3(4.0, 2.0, 4.0) / 16.0, vec3(8.0, 13.0, 8.0) / 16.0, rayLength, targetNormal);
        hit = hit || elementHit;
        float lod = log2(spreadData.x + spreadData.y * rayLength);
        targetAlbedo = getTargetAlbedo(ray, albedoSampler, originOffset, atlasTiles, baseColor, centerCoord, targetNormal, rayLength, vec2(0.0), vec2(1.0), lod, targetCoord, targetTangent);
        targetAlbedo.a = 1.0;
    }
    else if (materialID < 232.5) {
        float northSouth = float(materialID == 230.0);
        float eastWest = float(materialID == 231.0);
        float upDown = clamp(1.0 - northSouth - eastWest, 0.0, 1.0);
        vec3 elementStart = 7.0 / 16.0 - 7.0 / 16.0 * vec3(eastWest, upDown, northSouth);
        vec3 elementSize = vec3(eastWest, upDown, northSouth) * 14.0 / 16.0 + 2.0 / 16.0;
        elementHit = isRayHitElement(ray, elementStart, elementSize, rayLength, targetNormal);
        hit = hit || elementHit;
        #ifdef GLOBAL_ILLUMINATION
            if (voxelData.w > 0.4) {
                elementHit = isRayHitElement(ray, vec3(4.0) / 16.0, vec3(8.0) / 16.0, rayLength, targetNormal);
                hit = hit || elementHit;
            }
            emissiveScale = 2.0;
        #endif
        float lod = log2(spreadData.x + spreadData.y * rayLength);
        targetAlbedo = getTargetAlbedo(ray, albedoSampler, originOffset, atlasTiles, baseColor, centerCoord, targetNormal, rayLength, vec2(0.0), vec2(1.0), lod, targetCoord, targetTangent);
        targetAlbedo.a = 1.0;
    }
    else if (materialID < 233.5) {
        hit = isRayHitElement(ray, vec3(7.0, 0.0, 7.0) / 16.0, vec3(2.0, 10.0, 2.0) / 16.0, rayLength, targetNormal);
        #ifdef GLOBAL_ILLUMINATION
            elementHit = false;
            if (voxelData.w > 0.4) {
                elementHit = isRayHitElement(ray, vec3(5.0, 6.0, 5.0) / 16.0, vec3(6.0, 6.0, 6.0) / 16.0, rayLength, targetNormal);
                hit = hit || elementHit;
            }
            vec2 basicCoordOffset = vec2(0.0, (elementHit ? (-abs(targetNormal.y) - 3.0) : (-abs(targetNormal.y) * (targetNormal.y * 4.0 - 3.0))) / 16.0);
            vec2 basicCoordScale = vec2(1.0 - 0.75 * float(elementHit));
            float lod = log2(spreadData.x + spreadData.y * rayLength);
            targetAlbedo = getTargetAlbedo(
                ray, albedoSampler, originOffset, atlasTiles, baseColor, centerCoord, targetNormal, rayLength,
                basicCoordOffset, basicCoordScale, lod, targetCoord, targetTangent
            );
            emissiveScale = 0.7 * dot(targetAlbedo.rgb, targetAlbedo.rgb);
        #else
            float lod = log2(spreadData.x + spreadData.y * rayLength);
            targetAlbedo = getTargetAlbedo(
                ray, albedoSampler, originOffset, atlasTiles, baseColor, centerCoord, targetNormal, rayLength,
                vec2(0.0, -abs(targetNormal.y) * (targetNormal.y * 4.0 - 3.0) / 16.0), vec2(1.0), lod, targetCoord, targetTangent
            );
        #endif
        targetAlbedo.a = 1.0;
    }
    else if (materialID < 237.5) {
        const float angle = PI / 8.0;
        const float sinAngle = sin(angle);
        const float cosAngle = cos(angle);
        float wallTorchID = materialID - 234.0;
        float direction1 = step(1.5, wallTorchID);
        float direction1Inv = 1.0 - direction1;
        float dirSigned = wallTorchID * 2.0 - direction1 * 4.0 - 1.0;
        float northSouth = dirSigned * direction1Inv;
        float eastWest = dirSigned * direction1;

        vec3 rotationOrigin = vec3(8.0, 22.8137, 8.0) / 16.0;
        float eastWestSin = sinAngle * eastWest;
        float northSouthSin = sinAngle * northSouth;
        float dir1Cos = mix(1.0, cosAngle, direction1);
        float dir1InvCos = mix(1.0, cosAngle, direction1Inv);
        vec3 rotatedRayDir = vec3(
            dir1Cos * ray.direction.x + eastWestSin * ray.direction.y,
            -eastWestSin * ray.direction.x + cosAngle * ray.direction.y + northSouthSin * ray.direction.z,
            dir1InvCos * ray.direction.z - northSouthSin * ray.direction.y
        );
        vec3 originOffset = ray.origin - 1e-5 - rotationOrigin;
        vec3 rotatedOrigin = vec3(
            dir1Cos * originOffset.x + eastWestSin * originOffset.y,
            -eastWestSin * originOffset.x + cosAngle * originOffset.y + northSouthSin * originOffset.z,
            dir1InvCos * originOffset.z - northSouthSin * originOffset.y
        );
        Ray rotatedRay = Ray(
            rotatedOrigin + rotationOrigin, rotatedRayDir, 1.0 / rotatedRayDir, signI(rotatedRayDir)
        );
        rotatedRay.origin += 1e-5;
        hit = isRayHitElement(rotatedRay, vec3(7.0, 1.9087, 7.0) / 16.0, vec3(2.0, 10.0, 2.0) / 16.0, rayLength, targetNormal);
        #ifdef GLOBAL_ILLUMINATION
            elementHit = false;
            if (voxelData.w > 0.4) {
                elementHit = isRayHitElement(rotatedRay, vec3(5.0 - eastWest, 7.9087, 5.0 + northSouth) / 16.0, vec3(6.0, 6.0, 6.0) / 16.0, rayLength, targetNormal);
                hit = hit || elementHit;
            }
            float hitLight = float(elementHit);
            emissiveScale = hitLight * 0.7;
            vec2 basicCoordOffset = vec2(0.0, (elementHit ? (-0.06820625 - 0.18179375 * abs(targetNormal.y)) : (0.11929375 + abs(targetNormal.y) * (0.06820625 - targetNormal.y / 4.0))));
            vec2 basicCoordScale = vec2(1.0 - 0.75 * hitLight);
            float lod = log2(spreadData.x + spreadData.y * rayLength);
            targetAlbedo = getTargetAlbedo(
                rotatedRay, albedoSampler, rotatedRay.origin - vec3(0.5 + 1e-5), atlasTiles, baseColor, centerCoord, targetNormal, rayLength,
                basicCoordOffset, basicCoordScale, lod, targetCoord, targetTangent
            );
            emissiveScale *= dot(targetAlbedo.rgb, targetAlbedo.rgb);
        #else
            float lod = log2(spreadData.x + spreadData.y * rayLength);
            targetAlbedo = getTargetAlbedo(
                rotatedRay, albedoSampler, rotatedRay.origin - vec3(0.5 + 1e-5), atlasTiles, baseColor, centerCoord, targetNormal, rayLength,
                vec2(0.0, 0.11929375 + abs(targetNormal.y) * (0.06820625 - targetNormal.y / 4.0)), vec2(1.0), lod, targetCoord, targetTangent
            );
        #endif
        targetAlbedo.a = 1.0;

        mat3 rotationMatrix = mat3(
            dir1Cos, eastWestSin, 0.0,
            -eastWestSin, cosAngle, northSouthSin,
            0.0, -northSouthSin, dir1InvCos
        );
        targetNormal = rotationMatrix * targetNormal;
        targetTangent = rotationMatrix * targetTangent;
    }
    else if (materialID < 239.5) {
        float lanternID = materialID - 238.0;
        elementHit = isRayHitElement(ray, vec3(5.0, lanternID, 5.0) / 16.0, vec3(6.0, 7.0, 6.0) / 16.0, rayLength, targetNormal);
        hit = hit || elementHit;
        elementHit = isRayHitElement(ray, vec3(6.0, 7.0 + lanternID, 6.0) / 16.0, vec3(4.0, 2.0, 4.0) / 16.0, rayLength, targetNormal);
        hit = hit || elementHit;
        float lod = log2(spreadData.x + spreadData.y * rayLength);
        targetAlbedo = getTargetAlbedo(
            ray, albedoSampler, originOffset, atlasTiles, baseColor, centerCoord, targetNormal, rayLength,
            vec2(-5.0, 4.0 * abs(targetNormal.y) + (lanternID - 7.0) * (1.0 - abs(targetNormal.y))) / 16.0, vec2(1.0), lod, targetCoord, targetTangent
        );
        targetAlbedo.a = 1.0;
        emissiveScale = dot(targetAlbedo.rgb, targetAlbedo.rgb);
        #ifdef GLOBAL_ILLUMINATION
            emissiveScale *= 2.0;
        #endif
    }
    else if (materialID < 241.5) {
        float eastWest = materialID - 240.0;
        float northSouth = 1.0 - eastWest;
        elementHit = isRayHitElement(ray, vec3(northSouth * 5.0, 0.0, eastWest * 5.0) / 16.0, vec3(6.0 + eastWest * 10.0, 1.0, 6.0 + northSouth * 10.0) / 16.0, rayLength, targetNormal);
        hit = hit || elementHit;
        elementHit = isRayHitElement(ray, vec3(northSouth, 0.0, eastWest) / 16.0, vec3(4.0 + eastWest * 12.0, 4.0, 4.0 + northSouth * 12.0) / 16.0, rayLength, targetNormal);
        hit = hit || elementHit;
        elementHit = isRayHitElement(ray, vec3(northSouth * 11.0, 0.0, eastWest * 11.0) / 16.0, vec3(4.0 + eastWest * 12.0, 4.0, 4.0 + northSouth * 12.0) / 16.0, rayLength, targetNormal);
        hit = hit || elementHit;
        elementHit = isRayHitElement(ray, vec3(eastWest, 3.0, northSouth) / 16.0, vec3(4.0 + northSouth * 12.0, 4.0, 4.0 + eastWest * 12.0) / 16.0, rayLength, targetNormal);
        hit = hit || elementHit;
        elementHit = isRayHitElement(ray, vec3(eastWest * 11.0, 3.0, northSouth * 11.0) / 16.0, vec3(4.0 + northSouth * 12.0, 4.0, 4.0 + eastWest * 12.0) / 16.0, rayLength, targetNormal);
        hit = hit || elementHit;
        float lod = log2(spreadData.x + spreadData.y * rayLength);
        targetAlbedo = getTargetAlbedo(ray, albedoSampler, originOffset, atlasTiles, baseColor, centerCoord, targetNormal, rayLength, vec2(0.0), vec2(1.0), lod, targetCoord, targetTangent);
        targetAlbedo.a = 1.0;
        emissiveScale = dot(targetAlbedo.rgb, targetAlbedo.rgb);
        #ifdef GLOBAL_ILLUMINATION
            emissiveScale *= 2.0;
        #endif
    }
    else if (materialID < 242.5) {
        elementHit = isRayHitElement(ray, vec3(7.0, 0.0, 7.0) / 16.0, vec3(2.0, 6.0, 2.0) / 16.0, rayLength, targetNormal);
        hit = hit || elementHit;
        #ifdef GLOBAL_ILLUMINATION
            if (voxelData.w > 0.4) {
                elementHit = isRayHitElement(ray, vec3(5.0, 5.0, 5.0) / 16.0, vec3(6.0, 6.0, 6.0) / 16.0, rayLength, targetNormal);
                hit = hit || elementHit;
            }
        #endif
        float lod = log2(spreadData.x + spreadData.y * rayLength);
        targetAlbedo = getTargetAlbedo(ray, albedoSampler, originOffset, atlasTiles, baseColor, centerCoord, targetNormal, rayLength, vec2(0.0), vec2(1.0), lod, targetCoord, targetTangent);
        targetAlbedo.a = 1.0;
    }
    else if (materialID < 243.5) {
        elementHit = isRayHitElement(ray, vec3(9.0, 0.0, 6.0) / 16.0, vec3(2.0, 6.0, 2.0) / 16.0, rayLength, targetNormal);
        hit = hit || elementHit;
        elementHit = isRayHitElement(ray, vec3(5.0, 0.0, 7.0) / 16.0, vec3(2.0, 5.0, 2.0) / 16.0, rayLength, targetNormal);
        hit = hit || elementHit;
        #ifdef GLOBAL_ILLUMINATION
            if (voxelData.w > 0.4) {
                elementHit = isRayHitElement(ray, vec3(5.0, 5.0, 5.0) / 16.0, vec3(6.0, 6.0, 6.0) / 16.0, rayLength, targetNormal);
                hit = hit || elementHit;
            }
        #endif
        float lod = log2(spreadData.x + spreadData.y * rayLength);
        targetAlbedo = getTargetAlbedo(ray, albedoSampler, originOffset, atlasTiles, baseColor, centerCoord, targetNormal, rayLength, vec2(0.0), vec2(1.0), lod, targetCoord, targetTangent);
        targetAlbedo.a = 1.0;
    }
    else if (materialID < 244.5) {
        elementHit = isRayHitElement(ray, vec3(8.0, 0.0, 6.0) / 16.0, vec3(2.0, 6.0, 2.0) / 16.0, rayLength, targetNormal);
        hit = hit || elementHit;
        elementHit = isRayHitElement(ray, vec3(5.0, 0.0, 7.0) / 16.0, vec3(2.0, 5.0, 2.0) / 16.0, rayLength, targetNormal);
        hit = hit || elementHit;
        elementHit = isRayHitElement(ray, vec3(7.0, 0.0, 9.0) / 16.0, vec3(2.0, 3.0, 2.0) / 16.0, rayLength, targetNormal);
        hit = hit || elementHit;
        #ifdef GLOBAL_ILLUMINATION
            if (voxelData.w > 0.4) {
                elementHit = isRayHitElement(ray, vec3(5.0, 5.0, 5.0) / 16.0, vec3(6.0, 6.0, 6.0) / 16.0, rayLength, targetNormal);
                hit = hit || elementHit;
            }
        #endif
        float lod = log2(spreadData.x + spreadData.y * rayLength);
        targetAlbedo = getTargetAlbedo(ray, albedoSampler, originOffset, atlasTiles, baseColor, centerCoord, targetNormal, rayLength, vec2(0.0), vec2(1.0), lod, targetCoord, targetTangent);
        targetAlbedo.a = 1.0;
    }
    else if (materialID < 245.5) {
        elementHit = isRayHitElement(ray, vec3(8.0, 0.0, 5.0) / 16.0, vec3(2.0, 6.0, 2.0) / 16.0, rayLength, targetNormal);
        hit = hit || elementHit;
        elementHit = isRayHitElement(ray, vec3(5.0, 0.0, 5.0) / 16.0, vec3(2.0, 5.0, 2.0) / 16.0, rayLength, targetNormal);
        hit = hit || elementHit;
        elementHit = isRayHitElement(ray, vec3(6.0, 0.0, 8.0) / 16.0, vec3(2.0, 3.0, 2.0) / 16.0, rayLength, targetNormal);
        hit = hit || elementHit;
        elementHit = isRayHitElement(ray, vec3(9.0, 0.0, 8.0) / 16.0, vec3(2.0, 5.0, 2.0) / 16.0, rayLength, targetNormal);
        hit = hit || elementHit;
        #ifdef GLOBAL_ILLUMINATION
            if (voxelData.w > 0.4) {
                elementHit = isRayHitElement(ray, vec3(5.0, 5.0, 5.0) / 16.0, vec3(6.0, 6.0, 6.0) / 16.0, rayLength, targetNormal);
                hit = hit || elementHit;
            }
        #endif
        float lod = log2(spreadData.x + spreadData.y * rayLength);
        targetAlbedo = getTargetAlbedo(ray, albedoSampler, originOffset, atlasTiles, baseColor, centerCoord, targetNormal, rayLength, vec2(0.0), vec2(1.0), lod, targetCoord, targetTangent);
        targetAlbedo.a = 1.0;
    }
    // else if (materialID < 246.5) {
    // }
    // else if (materialID < 247.5) {
    // }
    else if (materialID < 248.5) {
    }
    else if (materialID < 249.5) {
        vec3 sphereToOrigin = vec3(0.5 - ray.origin);
        float PdotP2 = dot(sphereToOrigin, sphereToOrigin);
        float RdotP = dot(sphereToOrigin, ray.direction);
        float rayToSphere = PdotP2 - RdotP * RdotP;
        #ifdef GLOBAL_ILLUMINATION
            hit = rayToSphere < 0.4 * 0.4;
            rayLength = RdotP + sqrt(clamp(0.4 * 0.4 - rayToSphere, 0.0, 1.0));
            hit = hit && rayLength > 0.0;
            targetAlbedo = vec4(baseColor, 1.0);
        #else
            hit = rayToSphere < 0.3 * 0.3;
            rayLength = RdotP - sqrt(clamp(0.3 * 0.3 - rayToSphere, 0.0, 1.0));
            hit = hit && rayLength > 0.0;
            targetAlbedo = vec4(baseColor * (0.3 * 0.3 - rayToSphere) * 40.0, 1.0);
        #endif
    }
    else if (materialID < 250.5) {
        elementHit = isRayHitElement(ray, vec3(1.0, 0.0, 1.0) / 16.0, vec3(14.0, 8.0, 14.0) / 16.0, rayLength, targetNormal);
        hit = hit || elementHit;
        elementHit = isRayHitElement(ray, vec3(7.0, 8.0, 7.0) / 16.0, vec3(2.0, 6.0, 2.0) / 16.0, rayLength, targetNormal);
        hit = hit || elementHit;
        float lod = log2(spreadData.x + spreadData.y * rayLength);
        targetAlbedo = getTargetAlbedo(ray, albedoSampler, originOffset, atlasTiles, baseColor, centerCoord, targetNormal, rayLength, vec2(0.0), vec2(1.0), lod, targetCoord, targetTangent);
        targetAlbedo.a = 1.0;
        emissiveScale = float(elementHit) * 2.0;
    }
    else if (materialID < 251.5) {
        #if MC_VERSION >= 11900
            elementHit = isRayHitElement(ray, vec3(1.0, 0.0, 1.0) / 16.0, vec3(6.0, 2.0, 6.0) / 16.0, rayLength, targetNormal);
            hit = hit || elementHit;
            elementHit = isRayHitElement(ray, vec3(1.0, 0.0, 9.0) / 16.0, vec3(6.0, 2.0, 6.0) / 16.0, rayLength, targetNormal);
        #else
            elementHit = isRayHitElement(ray, vec3(2.0, 0.0, 1.0) / 16.0, vec3(6.0, 2.0, 6.0) / 16.0, rayLength, targetNormal);
            hit = hit || elementHit;
            elementHit = isRayHitElement(ray, vec3(2.0, 0.0, 9.0) / 16.0, vec3(6.0, 2.0, 6.0) / 16.0, rayLength, targetNormal);
        #endif
        hit = hit || elementHit;
        elementHit = isRayHitElement(ray, vec3(9.0, 0.0, 5.0) / 16.0, vec3(6.0, 2.0, 6.0) / 16.0, rayLength, targetNormal);
        hit = hit || elementHit;
        elementHit = isRayHitElement(ray, vec3(7.0, 0.0, 7.0) / 16.0, vec3(2.0, 14.0, 2.0) / 16.0, rayLength, targetNormal);
        hit = hit || elementHit;
        float lod = log2(spreadData.x + spreadData.y * rayLength);
        targetAlbedo = getTargetAlbedo(ray, albedoSampler, originOffset, atlasTiles, baseColor, centerCoord, targetNormal, rayLength, vec2(0.0), vec2(1.0), lod, targetCoord, targetTangent);
        targetAlbedo.a = 1.0;
        emissiveScale = float(elementHit) * 2.0;
    }
    else if (materialID < 252.5) {
        elementHit = isRayHitElement(ray, vec3(6.0, 0.0, 6.0) / 16.0, vec3(4.0, 4.0, 4.0) / 16.0, rayLength, targetNormal);
        hit = hit || elementHit;
        elementHit = isRayHitElement(ray, vec3(5.0, 0.0, 5.0) / 16.0, vec3(6.0, 6.0, 1.0) / 16.0, rayLength, targetNormal);
        hit = hit || elementHit;
        elementHit = isRayHitElement(ray, vec3(5.0, 0.0, 10.0) / 16.0, vec3(6.0, 6.0, 1.0) / 16.0, rayLength, targetNormal);
        hit = hit || elementHit;
        elementHit = isRayHitElement(ray, vec3(5.0, 0.0, 6.0) / 16.0, vec3(1.0, 6.0, 4.0) / 16.0, rayLength, targetNormal);
        hit = hit || elementHit;
        elementHit = isRayHitElement(ray, vec3(10.0, 0.0, 6.0) / 16.0, vec3(1.0, 6.0, 4.0) / 16.0, rayLength, targetNormal);
        hit = hit || elementHit;
        float lod = log2(spreadData.x + spreadData.y * rayLength);
        targetAlbedo = getTargetAlbedo(ray, albedoSampler, originOffset, atlasTiles, baseColor, centerCoord, targetNormal, rayLength, vec2(0.0), vec2(1.0), lod, targetCoord, targetTangent);
        targetAlbedo.a = 1.0;
    }
    else if (materialID < 253.5) {
        elementHit = isRayHitElement(ray, vec3(3.0, 0.0, 3.0) / 16.0, vec3(10.0, 13.0, 10.0) / 16.0, rayLength, targetNormal);
        hit = hit || elementHit;
        elementHit = isRayHitElement(ray, vec3(2.0, 1.0, 2.0) / 16.0, vec3(12.0, 10.0, 12.0) / 16.0, rayLength, targetNormal);
        hit = hit || elementHit;
        elementHit = isRayHitElement(ray, vec3(1.0, 3.0, 1.0) / 16.0, vec3(14.0, 5.0, 14.0) / 16.0, rayLength, targetNormal);
        hit = hit || elementHit;
        elementHit = isRayHitElement(ray, vec3(5.0, 13.0, 5.0) / 16.0, vec3(6.0, 2.0, 6.0) / 16.0, rayLength, targetNormal);
        hit = hit || elementHit;
        elementHit = isRayHitElement(ray, vec3(6.0, 15.0, 6.0) / 16.0, vec3(4.0, 1.0, 4.0) / 16.0, rayLength, targetNormal);
        hit = hit || elementHit;
        float lod = log2(spreadData.x + spreadData.y * rayLength);
        targetAlbedo = getTargetAlbedo(ray, albedoSampler, originOffset, atlasTiles, baseColor, centerCoord, targetNormal, rayLength, vec2(0.0), vec2(1.0), lod, targetCoord, targetTangent);
        targetAlbedo.a = 1.0;
    }
    else if (materialID < 254.5) {
        elementHit = isRayHitElement(ray, vec3(0.0, 0.0, 0.0), vec3(1.0, 13.0 / 16.0, 1.0), rayLength, targetNormal);
        hit = hit || elementHit;
        elementHit = isRayHitElement(ray, vec3(0.25, 13.0 / 16.0, 0.25), vec3(0.5, 3.0 / 16.0, 0.5), rayLength, targetNormal);
        hit = hit || elementHit;
        float lod = log2(spreadData.x + spreadData.y * rayLength);
        targetAlbedo = getTargetAlbedo(ray, albedoSampler, originOffset, atlasTiles, baseColor, centerCoord, targetNormal, rayLength, vec2(0.0), vec2(1.0), lod, targetCoord, targetTangent);
        targetAlbedo.a = 1.0;
    }
    else if (materialID < 255.5) {
        elementHit = isRayHitElement(ray, vec3(1.0, 0.0, 2.0) / 16.0, vec3(14.0, 16.0, 12.0) / 16.0, rayLength, targetNormal);
        hit = hit || elementHit;
        float lod = log2(spreadData.x + spreadData.y * rayLength);
        targetAlbedo = getTargetAlbedo(ray, albedoSampler, originOffset, atlasTiles, baseColor, centerCoord, targetNormal, rayLength, vec2(0.0), vec2(1.0), lod, targetCoord, targetTangent);
        targetAlbedo.a = 1.0;
    }
    #ifdef QUALITY_CUTOUT_TRACE
    else if (materialID < 256.5) {
        float initRayLength = rayLength;
        bool glassHit = isRayHitElementCutout(
            ray, albedoSampler, originOffset, atlasTiles, centerCoord, vec3(0.0), vec3(1.0),
            vec2(0.0), vec2(1.0), spreadData, rayLength, targetNormal
        );
        if (rayLength == 0.0) {
            glassHit = false;
            rayLength = initRayLength;
        }
        hit = hit || glassHit;
        elementHit = isRayHitElement(ray, vec3(2.0, 0.0, 2.0) / 16.0, vec3(12.0, 3.0, 12.0) / 16.0, rayLength, targetNormal);
        hit = hit || elementHit;
        elementHit = isRayHitElement(ray, vec3(3.0 / 16.0), vec3(10.0, 11.0, 10.0) / 16.0, rayLength, targetNormal);
        hit = hit || elementHit;
        float lod = log2(spreadData.x + spreadData.y * rayLength);
        targetAlbedo = getTargetAlbedo(ray, albedoSampler, originOffset, atlasTiles, baseColor, centerCoord, targetNormal, rayLength, vec2(0.0), vec2(1.0), lod, targetCoord, targetTangent);
        targetAlbedo.a = 1.0;
        emissiveScale = float(elementHit) * 1.5;
    }
    else if (materialID < 272.5) {
        vec4 stainedColor = vec4(1.0, 1.0, 1.0, 0.0);
        float eastWest = mod(materialID - 1.0, 4.0);
        vec3 baseOrigin = vec3(7.0 / 16.0, 0.0, 7.0 / 16.0), baseSize = vec3(2.0 / 16.0, 1.0, 2.0 / 16.0);
        if (eastWest != 0.0) {
            baseOrigin.x *= float(eastWest == 2.0);
            baseSize.x = float(eastWest == 3.0) * 7.0 / 16.0 + 9.0 / 16.0;
            if (materialID > 260.5) {
                float start = float(materialID < 264.5) * 9.0 / 16.0, size = float(materialID > 268.5) * 9.0 / 16.0 + 7.0 / 16.0;
                elementHit = isRayHitElementTransparent(
                    ray, albedoSampler, originOffset, atlasTiles, baseColor, centerCoord, vec3(7.0 / 16.0, 0.0, start), vec3(2.0 / 16.0, 1.0, size),
                    vec2(0.0), vec2(1.0), spreadData, stainedColor, rayLength, targetNormal
                );
                hit = hit || elementHit;
            }
        }
        else {
            float northSouth = float(materialID > 260.5);
            baseSize.z = (float(materialID > 268.5) + 1.0) * northSouth * 7.0 / 16.0 + 2.0 / 16.0;
            baseOrigin.z *= float(materialID < 264.5);
        }
        elementHit = isRayHitElementTransparent(
            ray, albedoSampler, originOffset, atlasTiles, baseColor, centerCoord, baseOrigin, baseSize,
            vec2(0.0), vec2(1.0), spreadData, stainedColor, rayLength, targetNormal
        );
        hit = hit || elementHit;
        float lod = log2(spreadData.x + spreadData.y * rayLength);
        targetAlbedo = getTargetAlbedo(ray, albedoSampler, originOffset, atlasTiles, baseColor, centerCoord, targetNormal, rayLength, vec2(0.0), vec2(1.0), lod, targetCoord, targetTangent);
        targetAlbedo = mix(targetAlbedo, stainedColor, float(stainedColor.a > 0.001));
    }
    else if (materialID < 273.5) {
        const vec2 basicCoordOffset = vec2(0.0, -1.0) / 16.0;
        elementHit = isRayHitElementCutout(
            ray, albedoSampler, originOffset, atlasTiles, centerCoord, vec3(0.0, 0.0, 4.0) / 16.0, vec3(16.0, 15.0, 0.0) / 16.0,
            basicCoordOffset, vec2(1.0), spreadData, rayLength, targetNormal
        );
        hit = hit || elementHit;
        elementHit = isRayHitElementCutout(
            ray, albedoSampler, originOffset, atlasTiles, centerCoord, vec3(4.0, 0.0, 0.0) / 16.0, vec3(0.0, 15.0, 16.0) / 16.0,
            basicCoordOffset, vec2(1.0), spreadData, rayLength, targetNormal
        );
        hit = hit || elementHit;
        elementHit = isRayHitElementCutout(
            ray, albedoSampler, originOffset, atlasTiles, centerCoord, vec3(0.0, 0.0, 12.0) / 16.0, vec3(16.0, 15.0, 0.0) / 16.0,
            basicCoordOffset, vec2(1.0), spreadData, rayLength, targetNormal
        );
        hit = hit || elementHit;
        elementHit = isRayHitElementCutout(
            ray, albedoSampler, originOffset, atlasTiles, centerCoord, vec3(12.0, 0.0, 0.0) / 16.0, vec3(0.0, 15.0, 16.0) / 16.0,
            basicCoordOffset, vec2(1.0), spreadData, rayLength, targetNormal
        );
        hit = hit || elementHit;
        float lod = log2(spreadData.x + spreadData.y * rayLength);
        targetAlbedo = getTargetAlbedo(ray, albedoSampler, originOffset, atlasTiles, baseColor, centerCoord, targetNormal, rayLength, basicCoordOffset, vec2(1.0), lod, targetCoord, targetTangent);
    }
    else if (materialID < 275.5) {
        vec2 basicCoordScale = vec2(0.7856, signI(274.5 - materialID));
        const float angle = sqrt(2.0) / 2.0;
        const mat3 rotationMatrix = mat3(
            angle, 0.0, angle,
            0.0, 1.0, 0.0,
            -angle, 0.0, angle
        );
        const vec3 rotationOrigin = vec3(0.5 + 1e-5, 0.0, 0.5 + 1e-5);
        ray.origin.xz = vec2(angle * (ray.origin.x + ray.origin.z - 1.0 - 2e-5), angle * (ray.origin.z - ray.origin.x)) + (0.5 + 1e-5);
        ray.direction = vec3(angle * (ray.direction.x + ray.direction.z), ray.direction.y, angle * (ray.direction.z - ray.direction.x));
        ray.dirInv = 1.0 / ray.direction;
        ray.dirSigned = signI(ray.direction);
        elementHit = isRayHitElementCutout(
            ray, albedoSampler, ray.origin - vec3(0.5 + 1e-5), atlasTiles, centerCoord, vec3(-2.1823, 0.0, 8.0) / 16.0, vec3(20.3647, 16.0, 0.0) / 16.0,
            vec2(0.0), basicCoordScale, spreadData, rayLength, targetNormal
        );
        hit = hit || elementHit;
        elementHit = isRayHitElementCutout(
            ray, albedoSampler, ray.origin - vec3(0.5 + 1e-5), atlasTiles, centerCoord, vec3(8.0, 0.0, -2.1823) / 16.0, vec3(0.0, 16.0, 20.3647) / 16.0,
            vec2(0.0), basicCoordScale, spreadData, rayLength, targetNormal
        );
        hit = hit || elementHit;
        float lod = log2(spreadData.x + spreadData.y * rayLength);
        targetAlbedo = getTargetAlbedo(ray, albedoSampler, ray.origin - vec3(0.5 + 1e-5), atlasTiles, baseColor, centerCoord, targetNormal, rayLength, vec2(0.0), basicCoordScale, lod, targetCoord, targetTangent);

        emissiveScale = clamp(2.0 * targetAlbedo.r - 1.5 * targetAlbedo.g, 0.0, 1.0);
        targetNormal = rotationMatrix * targetNormal;
        targetTangent = rotationMatrix * targetTangent;
    }
    else if (materialID < 277.5) {
        vec2 basicCoordScale = vec2(0.7856, signI(276.5 - materialID));
        const float angle = sqrt(2.0) / 2.0;
        const mat3 rotationMatrix = mat3(
            angle, -angle, 0.0,
            angle, angle, 0.0,
            0.0, 0.0, 1.0
        );
        const vec3 rotationOrigin = vec3(0.5 + 1e-5, 0.0, 0.5 + 1e-5);
        ray.origin.xy = vec2(angle * (ray.origin.x - ray.origin.y), angle * (ray.origin.x + ray.origin.y - 1.0 - 2e-5)) + (0.5 + 1e-5);
        ray.direction = vec3(angle * (ray.direction.x - ray.direction.y), angle * (ray.direction.x + ray.direction.y), ray.direction.z);
        ray.dirInv = 1.0 / ray.direction;
        ray.dirSigned = signI(ray.direction);
        elementHit = isRayHitElementCutout(
            ray, albedoSampler, ray.origin - vec3(0.5 + 1e-5), atlasTiles, centerCoord, vec3(-2.1823, 8.0, 0.0) / 16.0, vec3(20.3647, 0.0, 16.0) / 16.0,
            vec2(0.0), basicCoordScale, vec3(0.0, 1.0, 0.0), spreadData, rayLength, targetNormal
        );
        hit = hit || elementHit;
        elementHit = isRayHitElementCutoutRotated(
            ray, albedoSampler, ray.origin - vec3(0.5 + 1e-5), atlasTiles, centerCoord, vec3(8.0, -2.1823, 0.0) / 16.0, vec3(0.0, 20.3647, 16.0) / 16.0,
            vec2(0.0), basicCoordScale, vec3(-1.0, 0.0, 0.0), spreadData, rayLength, targetNormal
        );
        hit = hit || elementHit;
        float lod = log2(spreadData.x + spreadData.y * rayLength);
        if (elementHit) {
            basicCoordScale.y = signMul(basicCoordScale.y, 0.999 - targetNormal.x);
            targetAlbedo = getTargetAlbedoRotated(ray, albedoSampler, ray.origin - vec3(0.5 + 1e-5), atlasTiles, baseColor, centerCoord, targetNormal, rayLength, vec2(0.0), basicCoordScale, lod, targetCoord, targetTangent);
        }
        else {
            basicCoordScale.y = signMul(basicCoordScale.y, targetNormal.y + 0.999);
            targetAlbedo = getTargetAlbedo(ray, albedoSampler, ray.origin - vec3(0.5 + 1e-5), atlasTiles, baseColor, centerCoord, targetNormal, rayLength, vec2(0.0), basicCoordScale, lod, targetCoord, targetTangent);
        }

        emissiveScale = clamp(2.0 * targetAlbedo.r - 1.5 * targetAlbedo.g, 0.0, 1.0);
        targetNormal = rotationMatrix * targetNormal;
        targetTangent = rotationMatrix * targetTangent;
    }
    else if (materialID < 279.5) {
        vec2 basicCoordScale = vec2(0.7856, signI(278.5 - materialID));
        const float angle = sqrt(2.0) / 2.0;
        const mat3 rotationMatrix = mat3(
            1.0, 0.0, 0.0,
            0.0, angle, -angle,
            0.0, angle, angle
        );
        const vec3 rotationOrigin = vec3(0.5 + 1e-5, 0.0, 0.5 + 1e-5);
        ray.origin.yz = vec2(angle * (ray.origin.y - ray.origin.z), angle * (ray.origin.y + ray.origin.z - 1.0 - 2e-5)) + (0.5 + 1e-5);
        ray.direction = vec3(ray.direction.x, angle * (ray.direction.y - ray.direction.z), angle * (ray.direction.y + ray.direction.z));
        ray.dirInv = 1.0 / ray.direction;
        ray.dirSigned = signI(ray.direction);
        elementHit = isRayHitElementCutoutRotated(
            ray, albedoSampler, ray.origin - vec3(0.5 + 1e-5), atlasTiles, centerCoord, vec3(0.0, 8.0, -2.1823) / 16.0, vec3(16.0, 0.0, 20.3647) / 16.0,
            vec2(0.0), basicCoordScale, vec3(0.0, 0.0, 0.0), spreadData, rayLength, targetNormal
        );
        hit = hit || elementHit;
        elementHit = isRayHitElementCutoutRotated(
            ray, albedoSampler, ray.origin - vec3(0.5 + 1e-5), atlasTiles, centerCoord, vec3(0.0, -2.1823, 8.0) / 16.0, vec3(16.0, 20.3647, 0.0) / 16.0,
            vec2(0.0), basicCoordScale, vec3(0.0, 0.0, 1.0), spreadData, rayLength, targetNormal
        );
        hit = hit || elementHit;
        basicCoordScale.y = signMul(basicCoordScale.y, targetNormal.z + 0.999);
        float lod = log2(spreadData.x + spreadData.y * rayLength);
        targetAlbedo = getTargetAlbedoRotated(ray, albedoSampler, ray.origin - vec3(0.5 + 1e-5), atlasTiles, baseColor, centerCoord, targetNormal, rayLength, vec2(0.0), basicCoordScale, lod, targetCoord, targetTangent);

        emissiveScale = clamp(2.0 * targetAlbedo.r - 1.5 * targetAlbedo.g, 0.0, 1.0);
        targetNormal = rotationMatrix * targetNormal;
        targetTangent = rotationMatrix * targetTangent;
    }
    else if (materialID < 341.5) {
        float vineID = materialID - 279.0;
        vec2 basicCoordScale = vec2(1.0);
        if (mod(vineID, 2.0) > 0.5) {
            elementHit = isRayHitElementCutout(
                ray, albedoSampler, originOffset, atlasTiles, centerCoord, vec3(0.0, 0.1, 0.0) / 16.0, vec3(1.0, 0.0, 1.0),
                vec2(0.0), vec2(1.0, 1.0), vec3(0.0, 1.0, 0.0), spreadData, rayLength, targetNormal
            );
            basicCoordScale.y = 1.0 - float(targetNormal.y < -0.999) * 2.0;
            hit = hit || elementHit;
        }
        if (mod(vineID, 4.0) > 1.5) {
            elementHit = isRayHitElementCutout(
                ray, albedoSampler, originOffset, atlasTiles, centerCoord, vec3(0.0, 15.9, 0.0) / 16.0, vec3(1.0, 0.0, 1.0),
                vec2(0.0), vec2(1.0, 1.0), vec3(0.0, -1.0, 0.0), spreadData, rayLength, targetNormal
            );
            basicCoordScale.y = mix(basicCoordScale.y, 1.0 - float(targetNormal.y > 0.999) * 2.0, float(elementHit));
            hit = hit || elementHit;
        }
        if (mod(vineID, 8.0) > 3.5) {
            elementHit = isRayHitElementCutout(
                ray, albedoSampler, originOffset, atlasTiles, centerCoord, vec3(0.1, 0.0, 0.0) / 16.0, vec3(0.0, 1.0, 1.0),
                vec2(0.0), vec2(1.0, 1.0), vec3(1.0, 0.0, 0.0), spreadData, rayLength, targetNormal
            );
            basicCoordScale.x = 1.0 - float(targetNormal.x < -0.999) * 2.0;
            hit = hit || elementHit;
        }
        if (mod(vineID, 16.0) > 7.5) {
            elementHit = isRayHitElementCutout(
                ray, albedoSampler, originOffset, atlasTiles, centerCoord, vec3(15.9, 0.0, 0.0) / 16.0, vec3(0.0, 1.0, 1.0),
                vec2(0.0), vec2(1.0, 1.0), vec3(-1.0, 0.0, 0.0), spreadData, rayLength, targetNormal
            );
            basicCoordScale.x = mix(basicCoordScale.x, 1.0 - float(targetNormal.x > 0.999) * 2.0, float(elementHit));
            hit = hit || elementHit;
        }
        if (mod(vineID, 32.0) > 15.5) {
            elementHit = isRayHitElementCutout(
                ray, albedoSampler, originOffset, atlasTiles, centerCoord, vec3(0.0, 0.0, 15.9) / 16.0, vec3(1.0, 1.0, 0.0),
                vec2(0.0), vec2(1.0, 1.0), vec3(0.0, 0.0, -1.0), spreadData, rayLength, targetNormal
            );
            basicCoordScale.x = mix(basicCoordScale.x, 1.0 - float(targetNormal.z > 0.999) * 2.0, float(elementHit));
            hit = hit || elementHit;
        }
        if (vineID > 31.5) {
            elementHit = isRayHitElementCutout(
                ray, albedoSampler, originOffset, atlasTiles, centerCoord, vec3(0.0, 0.0, 0.1) / 16.0, vec3(1.0, 1.0, 0.0),
                vec2(0.0), vec2(1.0, 1.0), vec3(0.0, 0.0, 1.0), spreadData, rayLength, targetNormal
            );
            basicCoordScale.x = mix(basicCoordScale.x, 1.0 - float(targetNormal.z < -0.999) * 2.0, float(elementHit));
            hit = hit || elementHit;
        }
        float lod = log2(spreadData.x + spreadData.y * rayLength);
        targetAlbedo = getTargetAlbedo(ray, albedoSampler, originOffset, atlasTiles, baseColor, centerCoord, targetNormal, rayLength, vec2(0.0), basicCoordScale, lod, targetCoord, targetTangent);
    }
    else if (materialID < 343.5) {
        elementHit = isRayHitElement(ray, vec3(0.0, 0.0, 0.0) / 16.0, vec3(2.0, 16.0, 2.0) / 16.0, rayLength, targetNormal);
        hit = hit || elementHit;
        elementHit = isRayHitElement(ray, vec3(0.0, 0.0, 14.0) / 16.0, vec3(2.0, 16.0, 2.0) / 16.0, rayLength, targetNormal);
        hit = hit || elementHit;
        elementHit = isRayHitElement(ray, vec3(14.0, 0.0, 0.0) / 16.0, vec3(2.0, 16.0, 2.0) / 16.0, rayLength, targetNormal);
        hit = hit || elementHit;
        elementHit = isRayHitElement(ray, vec3(14.0, 0.0, 14.0) / 16.0, vec3(2.0, 16.0, 2.0) / 16.0, rayLength, targetNormal);
        hit = hit || elementHit;
        elementHit = isRayHitElement(ray, vec3(2.0, 14.0, 0.0) / 16.0, vec3(12.0, 2.0, 2.0) / 16.0, rayLength, targetNormal);
        hit = hit || elementHit;
        elementHit = isRayHitElement(ray, vec3(2.0, 14.0, 14.0) / 16.0, vec3(12.0, 2.0, 2.0) / 16.0, rayLength, targetNormal);
        hit = hit || elementHit;
        elementHit = isRayHitElement(ray, vec3(0.0, 14.0, 2.0) / 16.0, vec3(2.0, 2.0, 12.0) / 16.0, rayLength, targetNormal);
        hit = hit || elementHit;
        elementHit = isRayHitElement(ray, vec3(14.0, 14.0, 2.0) / 16.0, vec3(2.0, 2.0, 12.0) / 16.0, rayLength, targetNormal);
        hit = hit || elementHit;
        elementHit = isRayHitElementCutout(
            ray, albedoSampler, originOffset, atlasTiles, centerCoord, vec3(2.0, 15.99, 2.0) / 16.0, vec3(12.0, 0.01, 12.0) / 16.0,
            vec2(0.0), vec2(1.0, 1.0), spreadData, rayLength, targetNormal
        );
        hit = hit || elementHit;
        if (materialID > 342.5) {
            elementHit = isRayHitElement(ray, vec3(2.0, 0.0, 0.0) / 16.0, vec3(12.0, 2.0, 2.0) / 16.0, rayLength, targetNormal);
            hit = hit || elementHit;
            elementHit = isRayHitElement(ray, vec3(2.0, 0.0, 14.0) / 16.0, vec3(12.0, 2.0, 2.0) / 16.0, rayLength, targetNormal);
            hit = hit || elementHit;
            elementHit = isRayHitElement(ray, vec3(0.0, 0.0, 2.0) / 16.0, vec3(2.0, 2.0, 12.0) / 16.0, rayLength, targetNormal);
            hit = hit || elementHit;
            elementHit = isRayHitElement(ray, vec3(14.0, 0.0, 2.0) / 16.0, vec3(2.0, 2.0, 12.0) / 16.0, rayLength, targetNormal);
            hit = hit || elementHit;
            elementHit = isRayHitElementCutout(
                ray, albedoSampler, originOffset, atlasTiles, centerCoord, vec3(2.0, 1.99, 2.0) / 16.0, vec3(12.0, 0.01, 12.0) / 16.0,
                vec2(0.0), vec2(1.0, 1.0), spreadData, rayLength, targetNormal
            );
            hit = hit || elementHit;
        }
        float lod = log2(spreadData.x + spreadData.y * rayLength);
        targetAlbedo = getTargetAlbedo(ray, albedoSampler, originOffset, atlasTiles, baseColor, centerCoord, targetNormal, rayLength, vec2(0.0), vec2(1.0), lod, targetCoord, targetTangent);
    }
    #else
    else if (materialID < 256.5) {
        float initRayLength = rayLength;
        elementHit = isRayHitElement(ray, vec3(2.0, 0.0, 2.0) / 16.0, vec3(12.0, 3.0, 12.0) / 16.0, rayLength, targetNormal);
        hit = hit || elementHit;
        elementHit = isRayHitElement(ray, vec3(3.0 / 16.0), vec3(10.0, 11.0, 10.0) / 16.0, rayLength, targetNormal);
        hit = hit || elementHit;
        float lod = log2(spreadData.x + spreadData.y * rayLength);
        targetAlbedo = getTargetAlbedo(ray, albedoSampler, originOffset, atlasTiles, baseColor, centerCoord, targetNormal, rayLength, vec2(0.0), vec2(1.0), lod, targetCoord, targetTangent);
        targetAlbedo.a = 1.0;
    }
    else if (materialID < 272.5) {
        float eastWest = mod(materialID - 1.0, 4.0);
        vec3 baseOrigin = vec3(7.0 / 16.0, 0.0, 7.0 / 16.0), baseSize = vec3(2.0 / 16.0, 1.0, 2.0 / 16.0);
        if (eastWest != 0.0) {
            baseOrigin.x *= float(eastWest == 2.0);
            baseSize.x = float(eastWest == 3.0) * 7.0 / 16.0 + 9.0 / 16.0;
            if (materialID > 174.5) {
                float start = float(materialID < 178.5) * 9.0 / 16.0, size = float(materialID > 182.5) * 9.0 / 16.0 + 7.0 / 16.0;
                elementHit = isRayHitElement(ray, vec3(7.0 / 16.0, 0.0, start), vec3(2.0 / 16.0, 1.0, size), rayLength, targetNormal);
                hit = hit || elementHit;
            }
        }
        else if (materialID > 174.5) {
            baseOrigin.z *= float(materialID < 178.5);
            baseSize.z = float(materialID > 182.5) * 7.0 / 16.0 + 9.0 / 16.0;
        }
        elementHit = isRayHitElement(ray, baseOrigin, baseSize, rayLength, targetNormal);
        hit = hit || elementHit;
        float lod = log2(spreadData.x + spreadData.y * rayLength);
        targetAlbedo = getTargetAlbedo(ray, albedoSampler, originOffset, atlasTiles, baseColor, centerCoord, targetNormal, rayLength, vec2(0.0), vec2(1.0), lod, targetCoord, targetTangent);
    }
    else if (materialID < 273.5) {
        elementHit = isRayHitElement(ray, vec3(0.0, 0.0, 4.0) / 16.0, vec3(16.0, 15.0, 0.0) / 16.0, rayLength, targetNormal);
        hit = hit || elementHit;
        elementHit = isRayHitElement(ray, vec3(4.0, 0.0, 0.0) / 16.0, vec3(0.0, 15.0, 16.0) / 16.0, rayLength, targetNormal);
        hit = hit || elementHit;
        elementHit = isRayHitElement(ray, vec3(0.0, 0.0, 12.0) / 16.0, vec3(16.0, 15.0, 0.0) / 16.0, rayLength, targetNormal);
        hit = hit || elementHit;
        elementHit = isRayHitElement(ray, vec3(12.0, 0.0, 0.0) / 16.0, vec3(0.0, 15.0, 16.0) / 16.0, rayLength, targetNormal);
        hit = hit || elementHit;
        float lod = log2(spreadData.x + spreadData.y * rayLength);
        targetAlbedo = getTargetAlbedo(ray, albedoSampler, originOffset, atlasTiles, baseColor, centerCoord, targetNormal, rayLength, vec2(0.0, -1.0) / 16.0, vec2(1.0), lod, targetCoord, targetTangent);
    }
    else if (materialID < 275.5) {
        vec2 basicCoordScale = vec2(0.7856, signI(724.5 - materialID));
        const float angle = sqrt(2.0) / 2.0;
        const mat3 rotationMatrix = mat3(
            angle, 0.0, angle,
            0.0, 1.0, 0.0,
            -angle, 0.0, angle
        );
        const vec3 rotationOrigin = vec3(0.5 + 1e-5, 0.0, 0.5 + 1e-5);
        ray.origin.xz = vec2(angle * (ray.origin.x + ray.origin.z - 1.0 - 2e-5), angle * (ray.origin.z - ray.origin.x)) + (0.5 + 1e-5);
        ray.direction = vec3(angle * (ray.direction.x + ray.direction.z), ray.direction.y, angle * (ray.direction.z - ray.direction.x));
        ray.dirInv = 1.0 / ray.direction;
        ray.dirSigned = signI(ray.direction);
        vec3 rotatedOriginOffset = ray.origin - vec3(0.5 + 1e-5);
        elementHit = isRayHitElement(ray, vec3(-2.1823, 0.0, 8.0) / 16.0, vec3(20.3647, 16.0, 0.0) / 16.0, rayLength, targetNormal);
        hit = hit || elementHit;
        elementHit = isRayHitElement(ray, vec3(8.0, 0.0, -2.1823) / 16.0, vec3(0.0, 16.0, 20.3647) / 16.0, rayLength, targetNormal);
        hit = hit || elementHit;
        float lod = log2(spreadData.x + spreadData.y * rayLength);
        targetAlbedo = getTargetAlbedo(ray, albedoSampler, rotatedOriginOffset, atlasTiles, baseColor, centerCoord, targetNormal, rayLength, vec2(0.0, 0.0), basicCoordScale, lod, targetCoord, targetTangent);

        targetNormal = rotationMatrix * targetNormal;
        targetTangent = rotationMatrix * targetTangent;
    }
    else if (materialID < 277.5) {
        vec2 basicCoordScale = vec2(0.7856, signI(276.5 - materialID));
        const float angle = sqrt(2.0) / 2.0;
        const mat3 rotationMatrix = mat3(
            angle, -angle, 0.0,
            angle, angle, 0.0,
            0.0, 0.0, 1.0
        );
        const vec3 rotationOrigin = vec3(0.5 + 1e-5, 0.0, 0.5 + 1e-5);
        ray.origin.xy = vec2(angle * (ray.origin.x - ray.origin.y), angle * (ray.origin.x + ray.origin.y - 1.0 - 2e-5)) + (0.5 + 1e-5);
        ray.direction = vec3(angle * (ray.direction.x - ray.direction.y), angle * (ray.direction.x + ray.direction.y), ray.direction.z);
        ray.dirInv = 1.0 / ray.direction;
        ray.dirSigned = signI(ray.direction);
        elementHit = isRayHitElement(ray, vec3(-2.1823, 8.0, 0.0) / 16.0, vec3(20.3647, 0.0, 16.0) / 16.0, rayLength, targetNormal);
        hit = hit || elementHit;
        elementHit = isRayHitElement(ray, vec3(8.0, -2.1823, 0.0) / 16.0, vec3(0.0, 20.3647, 16.0) / 16.0, rayLength, targetNormal);
        hit = hit || elementHit;
        float lod = log2(spreadData.x + spreadData.y * rayLength);
        if (elementHit) {
            basicCoordScale.y = signMul(basicCoordScale.y, 0.999 - targetNormal.x);
            targetAlbedo = getTargetAlbedoRotated(ray, albedoSampler, ray.origin - vec3(0.5 + 1e-5), atlasTiles, baseColor, centerCoord, targetNormal, rayLength, vec2(0.0), basicCoordScale, lod, targetCoord, targetTangent);
        }
        else {
            basicCoordScale.y = signMul(basicCoordScale.y, targetNormal.y + 0.999);
            targetAlbedo = getTargetAlbedo(ray, albedoSampler, ray.origin - vec3(0.5 + 1e-5), atlasTiles, baseColor, centerCoord, targetNormal, rayLength, vec2(0.0), basicCoordScale, lod, targetCoord, targetTangent);
        }

        emissiveScale = clamp(2.0 * targetAlbedo.r - 1.5 * targetAlbedo.g, 0.0, 1.0);
        targetNormal = rotationMatrix * targetNormal;
        targetTangent = rotationMatrix * targetTangent;
    }
    else if (materialID < 279.5) {
        vec2 basicCoordScale = vec2(0.7856, signI(278.5 - materialID));
        const float angle = sqrt(2.0) / 2.0;
        const mat3 rotationMatrix = mat3(
            1.0, 0.0, 0.0,
            0.0, angle, -angle,
            0.0, angle, angle
        );
        const vec3 rotationOrigin = vec3(0.5 + 1e-5, 0.0, 0.5 + 1e-5);
        ray.origin.yz = vec2(angle * (ray.origin.y - ray.origin.z), angle * (ray.origin.y + ray.origin.z - 1.0 - 2e-5)) + (0.5 + 1e-5);
        ray.direction = vec3(ray.direction.x, angle * (ray.direction.y - ray.direction.z), angle * (ray.direction.y + ray.direction.z));
        ray.dirInv = 1.0 / ray.direction;
        ray.dirSigned = signI(ray.direction);
        elementHit = isRayHitElement(ray, vec3(0.0, 8.0, -2.1823) / 16.0, vec3(16.0, 0.0, 20.3647) / 16.0, rayLength, targetNormal);
        hit = hit || elementHit;
        elementHit = isRayHitElement(ray, vec3(0.0, -2.1823, 8.0) / 16.0, vec3(16.0, 20.3647, 0.0) / 16.0, rayLength, targetNormal);
        hit = hit || elementHit;
        basicCoordScale.y = signMul(basicCoordScale.y, targetNormal.z + 0.999);
        float lod = log2(spreadData.x + spreadData.y * rayLength);
        targetAlbedo = getTargetAlbedoRotated(ray, albedoSampler, ray.origin - vec3(0.5 + 1e-5), atlasTiles, baseColor, centerCoord, targetNormal, rayLength, vec2(0.0), basicCoordScale, lod, targetCoord, targetTangent);

        emissiveScale = clamp(2.0 * targetAlbedo.r - 1.5 * targetAlbedo.g, 0.0, 1.0);
        targetNormal = rotationMatrix * targetNormal;
        targetTangent = rotationMatrix * targetTangent;
    }
    else if (materialID < 341.5) {
        float vineID = materialID - 279.0;
        vec2 basicCoordScale = vec2(1.0);
        if (mod(vineID, 2.0) > 0.5) {
            elementHit = isRayHitElement(ray, vec3(0.0, 0.1, 0.0) / 16.0, vec3(1.0, 0.0, 1.0), rayLength, targetNormal);
            basicCoordScale.y = float(targetNormal.y > 0.999) * 2.0 - 1.0;
            hit = hit || elementHit;
        }
        if (mod(vineID, 4.0) > 1.5) {
            elementHit = isRayHitElement(ray, vec3(0.0, 15.9, 0.0) / 16.0, vec3(1.0, 0.0, 1.0), rayLength, targetNormal);
            basicCoordScale.y = mix(basicCoordScale.y, 1.0 - float(targetNormal.y > 0.999) * 2.0, float(elementHit));
            hit = hit || elementHit;
        }
        if (mod(vineID, 8.0) > 3.5) {
            elementHit = isRayHitElement(ray, vec3(0.1, 0.0, 0.0) / 16.0, vec3(0.0, 1.0, 1.0), rayLength, targetNormal);
            basicCoordScale.x = float(targetNormal.x > 0.999) * 2.0 - 1.0;
            hit = hit || elementHit;
        }
        if (mod(vineID, 16.0) > 7.5) {
            elementHit = isRayHitElement(ray, vec3(15.9, 0.0, 0.0) / 16.0, vec3(0.0, 1.0, 1.0), rayLength, targetNormal);
            basicCoordScale.x = mix(basicCoordScale.x, 1.0 - float(targetNormal.x > 0.999) * 2.0, float(elementHit));
            hit = hit || elementHit;
        }
        if (mod(vineID, 32.0) > 15.5) {
            elementHit = isRayHitElement(ray, vec3(0.0, 0.0, 15.9) / 16.0, vec3(1.0, 1.0, 0.0), rayLength, targetNormal);
            basicCoordScale.x = mix(basicCoordScale.x, 1.0 - float(targetNormal.z > 0.999) * 2.0, float(elementHit));
            hit = hit || elementHit;
        }
        if (vineID > 31.5) {
            elementHit = isRayHitElement(ray, vec3(0.0, 0.0, 0.1) / 16.0, vec3(1.0, 1.0, 0.0), rayLength, targetNormal);
            basicCoordScale.x = mix(basicCoordScale.x, 1.0 - float(targetNormal.z < -0.999) * 2.0, float(elementHit));
            hit = hit || elementHit;
        }
        float lod = log2(spreadData.x + spreadData.y * rayLength);
        targetAlbedo = getTargetAlbedo(ray, albedoSampler, originOffset, atlasTiles, baseColor, centerCoord, targetNormal, rayLength, vec2(0.0), basicCoordScale, lod, targetCoord, targetTangent);
    }
    else if (materialID < 343.5) {
        elementHit = isRayHitElement(ray, vec3(0.0, 0.0, 0.0) / 16.0, vec3(2.0, 16.0, 2.0) / 16.0, rayLength, targetNormal);
        hit = hit || elementHit;
        elementHit = isRayHitElement(ray, vec3(0.0, 0.0, 14.0) / 16.0, vec3(2.0, 16.0, 2.0) / 16.0, rayLength, targetNormal);
        hit = hit || elementHit;
        elementHit = isRayHitElement(ray, vec3(14.0, 0.0, 0.0) / 16.0, vec3(2.0, 16.0, 2.0) / 16.0, rayLength, targetNormal);
        hit = hit || elementHit;
        elementHit = isRayHitElement(ray, vec3(14.0, 0.0, 14.0) / 16.0, vec3(2.0, 16.0, 2.0) / 16.0, rayLength, targetNormal);
        hit = hit || elementHit;
        elementHit = isRayHitElement(ray, vec3(2.0, 14.0, 0.0) / 16.0, vec3(12.0, 2.0, 2.0) / 16.0, rayLength, targetNormal);
        hit = hit || elementHit;
        elementHit = isRayHitElement(ray, vec3(2.0, 14.0, 14.0) / 16.0, vec3(12.0, 2.0, 2.0) / 16.0, rayLength, targetNormal);
        hit = hit || elementHit;
        elementHit = isRayHitElement(ray, vec3(0.0, 14.0, 2.0) / 16.0, vec3(2.0, 2.0, 12.0) / 16.0, rayLength, targetNormal);
        hit = hit || elementHit;
        elementHit = isRayHitElement(ray, vec3(14.0, 14.0, 2.0) / 16.0, vec3(2.0, 2.0, 12.0) / 16.0, rayLength, targetNormal);
        hit = hit || elementHit;
        elementHit = isRayHitElement(ray, vec3(2.0, 15.99, 2.0) / 16.0, vec3(12.0, 0.01, 12.0) / 16.0, rayLength, targetNormal);
        hit = hit || elementHit;
        if (materialID > 342.5) {
            elementHit = isRayHitElement(ray, vec3(2.0, 0.0, 0.0) / 16.0, vec3(12.0, 2.0, 2.0) / 16.0, rayLength, targetNormal);
            hit = hit || elementHit;
            elementHit = isRayHitElement(ray, vec3(2.0, 0.0, 14.0) / 16.0, vec3(12.0, 2.0, 2.0) / 16.0, rayLength, targetNormal);
            hit = hit || elementHit;
            elementHit = isRayHitElement(ray, vec3(0.0, 0.0, 2.0) / 16.0, vec3(2.0, 2.0, 12.0) / 16.0, rayLength, targetNormal);
            hit = hit || elementHit;
            elementHit = isRayHitElement(ray, vec3(14.0, 0.0, 2.0) / 16.0, vec3(2.0, 2.0, 12.0) / 16.0, rayLength, targetNormal);
            hit = hit || elementHit;
            elementHit = isRayHitElement(ray, vec3(2.0, 1.99, 2.0) / 16.0, vec3(12.0, 0.01, 12.0) / 16.0, rayLength, targetNormal);
            hit = hit || elementHit;
        }
        float lod = log2(spreadData.x + spreadData.y * rayLength);
        targetAlbedo = getTargetAlbedo(ray, albedoSampler, originOffset, atlasTiles, baseColor, centerCoord, targetNormal, rayLength, vec2(0.0), vec2(1.0), lod, targetCoord, targetTangent);
    }
    #endif
    #endif
    #endif
    #endif
    return hit;
}

bool isRayHitBlock(Ray ray, sampler2D albedoSampler, vec2 atlasTiles, vec4 voxelData, vec3 voxelPos, inout float targetOpacity, inout float rayLength) {
    ray.origin -= voxelPos;
    vec3 originOffset = ray.origin - vec3(0.5);
    ray.origin += 1e-5;
    vec2 centerCoord = (floor(voxelData.xy * atlasTiles) + 0.5) / atlasTiles;
    float materialID = voxelData.z;
    vec3 targetNormal = -ray.direction;

    bool hit = false, elementHit = false;
    if (materialID < 1.5) {
        float opaque = step(0.5, materialID);
        hit = isRayHitElement(ray, vec3(0.0), vec3(1.0), rayLength, targetNormal);
        targetOpacity = float(0.5 < materialID && voxelData.w < 0.4);
    }
    #if PATH_TRACE_GEOMETRY_QUALITY > 0
    else if (materialID < 18.5) {
        float bottomOffset = clamp(materialID * 0.5 - 8.0, 0.0, 1.0) - clamp(materialID * (3.0 / 16.0) - 51.0 / 16.0, 0.0, 1.0);
        float elementHeight = clamp(materialID / 16.0 - 1.0 / 16.0, 0.0, 1.0) - bottomOffset;
        hit = isRayHitElement(ray, vec3(0.0, bottomOffset, 0.0), vec3(1.0, elementHeight, 1.0), rayLength, targetNormal);
        targetOpacity = getTargetAlbedo(ray, albedoSampler, originOffset, atlasTiles, vec3(1.0), centerCoord, targetNormal, rayLength, vec2(0.0), vec2(1.0), 0.0).a;
        targetOpacity += float(materialID != 4 && materialID != 18);
        targetOpacity *= step(voxelData.w, 0.4);
    }
    else if (materialID < 42.5) {
        hit = isRayHitElement(ray, vec3(0.0, float(materialID > 30.5) * 0.5, 0.0), vec3(1.0, 0.5, 1.0), rayLength, targetNormal);
        float stairShape = mod(materialID - 19.0, 12.0);
        float stairFacing = mod(stairShape, 4.0);
        if (stairShape < 7.5) {
            vec3 elementOrigin = vec3(float(stairFacing == 3.0) * 0.5, 0.0, float(stairFacing == 2.0) * 0.5);
            vec3 elementSize = mod(stairShape, 2.0) == 0.0 ? vec3(1.0, 1.0, 0.5) : vec3(0.5, 1.0, 1.0);
            elementHit = isRayHitElement(ray, elementOrigin, elementSize, rayLength, targetNormal);
            hit = hit || elementHit;
        }
        if (stairShape > 3.5) {
            vec3 elementOrigin = vec3(float(abs(stairFacing - 1.5) < 1.0) * 0.5, 0.0, float(stairFacing < 1.5) * 0.5);
            elementHit = isRayHitElement(ray, elementOrigin, vec3(0.5, 1.0, 0.5), rayLength, targetNormal);
            hit = hit || elementHit;
        }
        targetOpacity = getTargetAlbedo(ray, albedoSampler, originOffset, atlasTiles, vec3(1.0), centerCoord, targetNormal, rayLength, vec2(0.0), vec2(1.0), 0.0).a;
    }
    else if (materialID < 46.5) {
        vec3 elementOrigin = vec3(materialID == 46.0 ? (13.0 / 16.0) : 0.0, 0.0, materialID == 44.0 ? (13.0 / 16.0) : 0.0);
        vec3 elementSize = materialID < 44.5 ? vec3(1.0, 1.0, 3.0 / 16.0) : vec3(3.0 / 16.0, 1.0, 1.0);
        hit = isRayHitElement(ray, elementOrigin, elementSize, rayLength, targetNormal);
        targetOpacity = getTargetAlbedo(ray, albedoSampler, originOffset, atlasTiles, vec3(1.0), centerCoord, targetNormal, rayLength, vec2(0.0), vec2(1.0), 0.0).a;
    }
    else if (materialID < 62.5) {
        hit = isRayHitElement(ray, vec3(6.0 / 16.0, 0.0, 6.0 / 16.0), vec3(4.0 / 16.0, 1.0, 4.0 / 16.0), rayLength, targetNormal);
        float eastWest = mod(materialID, 4.0);
        if (eastWest != 3.0) {
            float startPos = eastWest != 1.0 ? 0.0 : 0.5, size = eastWest == 2.0 ? 1.0 : 0.5;
            elementHit = isRayHitElement(ray, vec3(startPos, 6.0 / 16.0, 7.0 / 16.0), vec3(size, 3.0 / 16.0, 2.0 / 16.0), rayLength, targetNormal);
            hit = hit || elementHit;
            elementHit = isRayHitElement(ray, vec3(startPos, 12.0 / 16.0, 7.0 / 16.0), vec3(size, 3.0 / 16.0, 2.0 / 16.0), rayLength, targetNormal);
            hit = hit || elementHit;
        }
        if (materialID > 50.5) {
            float startPos = materialID > 54.5 ? 0.0 : 0.5, size = materialID > 58.5 ? 1.0 : 0.5;
            elementHit = isRayHitElement(ray, vec3(7.0 / 16.0, 6.0 / 16.0, startPos), vec3(2.0 / 16.0, 3.0 / 16.0, size), rayLength, targetNormal);
            hit = hit || elementHit;
            elementHit = isRayHitElement(ray, vec3(7.0 / 16.0, 12.0 / 16.0, startPos), vec3(2.0 / 16.0, 3.0 / 16.0, size), rayLength, targetNormal);
            hit = hit || elementHit;
        }
    }
    else if (materialID < 65.5) {
        vec3 elementSize = vec3(14.0 / 16.0, 0.5 / 16.0, 14.0 / 16.0);
        elementSize.y += (0.5 * materialID + max(14.5 * materialID - 959.5, -31.5)) / 16.0;
        hit = isRayHitElement(ray, vec3(1.0 / 16.0, 0.0, 1.0 / 16.0), elementSize, rayLength, targetNormal);
    }
    else if (materialID < 146.5) {
        hit = isRayHitElement(ray, vec3(4.0 / 16.0, 0.0, 4.0 / 16.0), vec3(8.0 / 16.0, 1.0, 8.0 / 16.0), rayLength, targetNormal);
        float wallID = materialID - 66.0;
        float north = floor(wallID / 27.0);
        wallID -= 27.0 * north;
        float south = floor(wallID / 9.0);
        wallID -= 9.0 * south;
        float east = floor(wallID / 3.0);
        wallID -= 3.0 * east;
        float west = wallID;
        if (west > 0.0) {
            elementHit = isRayHitElement(ray, vec3(0.0, 0.0, 5.0 / 16.0), vec3(8.0, west * 2.0 + 12.0, 6.0) / 16.0, rayLength, targetNormal);
            hit = hit || elementHit;
        }
        if (east > 0.0) {
            elementHit = isRayHitElement(ray, vec3(0.5, 0.0, 5.0 / 16.0), vec3(8.0, east * 2.0 + 12.0, 6.0) / 16.0, rayLength, targetNormal);
            hit = hit || elementHit;
        }
        if (south > 0.0) {
            elementHit = isRayHitElement(ray, vec3(5.0 / 16.0, 0.0, 0.5), vec3(6.0, south * 2.0 + 12.0, 8.0) / 16.0, rayLength, targetNormal);
            hit = hit || elementHit;
        }
        if (north > 0.0) {
            elementHit = isRayHitElement(ray, vec3(5.0 / 16.0, 0.0, 0.0), vec3(6.0, north * 2.0 + 12.0, 8.0) / 16.0, rayLength, targetNormal);
            hit = hit || elementHit;
        }
    }
    else if (materialID < 154.5) {
        float wallID = materialID - 146.0;
        float eastWest = mod(wallID, 3.0);
        if (wallID > 2.5) {
            float height = wallID > 5.5 ? 1.0 : (14.0 / 16.0);
            elementHit = isRayHitElement(ray, vec3(5.0 / 16.0, 0.0, 0.0), vec3(6.0 / 16.0, height, 1.0), rayLength, targetNormal);
            hit = hit || elementHit;
        }
        if (eastWest > 0.5) {
            float height = eastWest > 1.5 ? 1.0 : (14.0 / 16.0);
            elementHit = isRayHitElement(ray, vec3(0.0, 0.0, 5.0 / 16.0), vec3(1.0, height, 6.0 / 16.0), rayLength, targetNormal);
            hit = hit || elementHit;
        }
    }
    #if PATH_TRACE_GEOMETRY_QUALITY > 1
    else if (materialID < 160.5) {
        float gateID = materialID - 155.0;
        float heightOffset = float(gateID > 2.5) * -3.0;
        float type = gateID + heightOffset;
        elementHit = isRayHitElement(ray, vec3(0.0, 5.0 + heightOffset, 7.0) / 16.0, vec3(2.0, 11.0, 2.0) / 16.0, rayLength, targetNormal);
        hit = hit || elementHit;
        elementHit = isRayHitElement(ray, vec3(14.0, 5.0 + heightOffset, 7.0) / 16.0, vec3(2.0, 11.0, 2.0) / 16.0, rayLength, targetNormal);
        hit = hit || elementHit;
        if (type < 0.5) {
            elementHit = isRayHitElement(ray, vec3(2.0, 6.0 + heightOffset, 7.0) / 16.0, vec3(12.0, 3.0, 2.0) / 16.0, rayLength, targetNormal);
            hit = hit || elementHit;
            elementHit = isRayHitElement(ray, vec3(2.0, 12.0 + heightOffset, 7.0) / 16.0, vec3(12.0, 3.0, 2.0) / 16.0, rayLength, targetNormal);
            hit = hit || elementHit;
            elementHit = isRayHitElement(ray, vec3(6.0, 9.0 + heightOffset, 7.0) / 16.0, vec3(4.0, 3.0, 2.0) / 16.0, rayLength, targetNormal);
        }
        else {
            float direction = 2.0 * type - 3.0;
            vec3 elementOrigin = vec3(0.0, 0.0, 0.5);
            elementHit = isRayHitElement(ray, elementOrigin + vec3(0.0, 6.0 + heightOffset, direction) / 16.0, vec3(2.0, 3.0, direction * 4.0) / 16.0, rayLength, targetNormal);
            hit = hit || elementHit;
            elementHit = isRayHitElement(ray, elementOrigin + vec3(14.0, 6.0 + heightOffset, direction) / 16.0, vec3(2.0, 3.0, direction * 4.0) / 16.0, rayLength, targetNormal);
            hit = hit || elementHit;
            elementHit = isRayHitElement(ray, elementOrigin + vec3(0.0, 12.0 + heightOffset, direction) / 16.0, vec3(2.0, 3.0, direction * 4.0) / 16.0, rayLength, targetNormal);
            hit = hit || elementHit;
            elementHit = isRayHitElement(ray, elementOrigin + vec3(14.0, 12.0 + heightOffset, direction) / 16.0, vec3(2.0, 3.0, direction * 4.0) / 16.0, rayLength, targetNormal);
            hit = hit || elementHit;
            elementHit = isRayHitElement(ray, elementOrigin + vec3(0.0, 6.0 + heightOffset, direction * 5.0) / 16.0, vec3(2.0, 9.0, direction * 2.0) / 16.0, rayLength, targetNormal);
            hit = hit || elementHit;
            elementHit = isRayHitElement(ray, elementOrigin + vec3(14.0, 6.0 + heightOffset, direction * 5.0) / 16.0, vec3(2.0, 9.0, direction * 2.0) / 16.0, rayLength, targetNormal);
        }
        hit = hit || elementHit;
    }
    else if (materialID < 166.5) {
        float gateID = materialID - 161.0;
        float heightOffset = float(gateID > 2.5) * -3.0;
        float type = gateID + heightOffset;
        elementHit = isRayHitElement(ray, vec3(7.0, 5.0 + heightOffset, 0.0) / 16.0, vec3(2.0, 11.0, 2.0) / 16.0, rayLength, targetNormal);
        hit = hit || elementHit;
        elementHit = isRayHitElement(ray, vec3(7.0, 5.0 + heightOffset, 14.0) / 16.0, vec3(2.0, 11.0, 2.0) / 16.0, rayLength, targetNormal);
        hit = hit || elementHit;
        if (type < 0.5) {
            elementHit = isRayHitElement(ray, vec3(7.0, 6.0 + heightOffset, 2.0) / 16.0, vec3(2.0, 3.0, 12.0) / 16.0, rayLength, targetNormal);
            hit = hit || elementHit;
            elementHit = isRayHitElement(ray, vec3(7.0, 12.0 + heightOffset, 2.0) / 16.0, vec3(2.0, 3.0, 12.0) / 16.0, rayLength, targetNormal);
            hit = hit || elementHit;
            elementHit = isRayHitElement(ray, vec3(7.0, 9.0 + heightOffset, 6.0) / 16.0, vec3(2.0, 3.0, 4.0) / 16.0, rayLength, targetNormal);
        }
        else {
            float direction = 2.0 * type - 3.0;
            vec3 elementOrigin = vec3(0.5, 0.0, 0.0);
            elementHit = isRayHitElement(ray, elementOrigin + vec3(direction, 6.0 + heightOffset, 0.0) / 16.0, vec3(direction * 4.0, 3.0, 2.0) / 16.0, rayLength, targetNormal);
            hit = hit || elementHit;
            elementHit = isRayHitElement(ray, elementOrigin + vec3(direction, 6.0 + heightOffset, 14.0) / 16.0, vec3(direction * 4.0, 3.0, 2.0) / 16.0, rayLength, targetNormal);
            hit = hit || elementHit;
            elementHit = isRayHitElement(ray, elementOrigin + vec3(direction, 12.0 + heightOffset, 0.0) / 16.0, vec3(direction * 4.0, 3.0, 2.0) / 16.0, rayLength, targetNormal);
            hit = hit || elementHit;
            elementHit = isRayHitElement(ray, elementOrigin + vec3(direction, 12.0 + heightOffset, 14.0) / 16.0, vec3(direction * 4.0, 3.0, 2.0) / 16.0, rayLength, targetNormal);
            hit = hit || elementHit;
            elementHit = isRayHitElement(ray, elementOrigin + vec3(direction * 5.0, 6.0 + heightOffset, 0.0) / 16.0, vec3(direction * 2.0, 9.0, 2.0) / 16.0, rayLength, targetNormal);
            hit = hit || elementHit;
            elementHit = isRayHitElement(ray, elementOrigin + vec3(direction * 5.0, 6.0 + heightOffset, 14.0) / 16.0, vec3(direction * 2.0, 9.0, 2.0) / 16.0, rayLength, targetNormal);
        }
        hit = hit || elementHit;
    }
    else if (materialID < 183.5) {
        float height = 12.0 / 16.0 + float(materialID < 167.5) * 4.0 / 16.0;
        float eastWest = mod(max(materialID - 168.0, 0.0), 4.0);
        elementHit = isRayHitElement(ray, vec3(4.0, 0.0, 4.0) / 16.0, vec3(0.5, height, 0.5), rayLength, targetNormal);
        hit = hit || elementHit;
        if (eastWest != 0.0) {
            float startPos = float(eastWest == 2.0) * 0.5, size = float(eastWest == 3.0) * 0.5 + 0.5;
            elementHit = isRayHitElement(ray, vec3(startPos, 0.25, 0.25), vec3(size, 0.5, 0.5), rayLength, targetNormal);
            hit = hit || elementHit;
        }
        if (materialID > 171.5) {
            float startPos = float(materialID < 175.5) * 0.5, size = float(materialID > 179.5) * 0.5 + 0.5;
            elementHit = isRayHitElement(ray, vec3(0.25, 0.25, startPos), vec3(0.5, 0.5, size), rayLength, targetNormal);
            hit = hit || elementHit;
        }
    }
    else if (materialID < 191.5) {
        float facing = mod(materialID, 4.0);
        float facingSigned = float(facing > 1.5);
        vec3 elementOrigin = vec3(float(facing != 0.0) * 0.25, 0.25, float(facing != 3.0) * 0.25);
        vec3 elementSize = vec3(0.75 - 0.25 * facingSigned, 0.5, facingSigned * 0.25 + 0.5);
        elementHit = isRayHitElement(ray, elementOrigin, elementSize, rayLength, targetNormal);
        hit = hit || elementHit;
        if (materialID < 187.5) {
            elementHit = isRayHitElement(ray, vec3(0.25, 0.75, 0.25), vec3(0.5, 0.25, 0.5), rayLength, targetNormal);
            hit = hit || elementHit;
        }
    }
    else if (materialID < 192.5) {
        elementHit = isRayHitElement(ray, vec3(0.0, 2.0 / 16.0, 2.0 / 16.0), vec3(1.0, 12.0 / 16.0, 12.0 / 16.0), rayLength, targetNormal);
        hit = hit || elementHit;
        elementHit = isRayHitElement(ray, vec3(2.0 / 16.0, 0.0, 2.0 / 16.0), vec3(12.0 / 16.0, 1.0, 12.0 / 16.0), rayLength, targetNormal);
        hit = hit || elementHit;
        elementHit = isRayHitElement(ray, vec3(2.0 / 16.0, 2.0 / 16.0, 0.0), vec3(12.0 / 16.0, 12.0 / 16.0, 1.0), rayLength, targetNormal);
        hit = hit || elementHit;
    }
    else if (materialID < 193.5) {
        elementHit = isRayHitElement(ray, vec3(0.0), vec3(1.0, 2.0 / 16.0, 1.0), rayLength, targetNormal);
        hit = hit || elementHit;
        elementHit = isRayHitElement(ray, vec3(0.0, 2.0 / 16.0, 0.0), vec3(1.0, 14.0 / 16.0, 2.0 / 16.0), rayLength, targetNormal);
        hit = hit || elementHit;
        elementHit = isRayHitElement(ray, vec3(0.0, 2.0 / 16.0, 0.0), vec3(2.0 / 16.0, 14.0 / 16.0, 1.0), rayLength, targetNormal);
        hit = hit || elementHit;
        elementHit = isRayHitElement(ray, vec3(0.0, 2.0 / 16.0, 14.0 / 16.0), vec3(1.0, 14.0 / 16.0, 2.0 / 16.0), rayLength, targetNormal);
        hit = hit || elementHit;
        elementHit = isRayHitElement(ray, vec3(14.0 / 16.0, 2.0 / 16.0, 0.0), vec3(2.0 / 16.0, 14.0 / 16.0, 1.0), rayLength, targetNormal);
        hit = hit || elementHit;
    }
    else if (materialID < 194.5) {
        elementHit = isRayHitElement(ray, vec3(0.0, 3.0 / 16.0, 0.0), vec3(1.0, 2.0 / 16.0, 1.0), rayLength, targetNormal);
        hit = hit || elementHit;
        elementHit = isRayHitElement(ray, vec3(0.0, 3.0 / 16.0, 0.0), vec3(1.0, 13.0 / 16.0, 2.0 / 16.0), rayLength, targetNormal);
        hit = hit || elementHit;
        elementHit = isRayHitElement(ray, vec3(0.0, 3.0 / 16.0, 2.0 / 16.0), vec3(2.0 / 16.0, 13.0 / 16.0, 12.0 / 16.0), rayLength, targetNormal);
        hit = hit || elementHit;
        elementHit = isRayHitElement(ray, vec3(0.0, 3.0 / 16.0, 14.0 / 16.0), vec3(1.0, 13.0 / 16.0, 2.0 / 16.0), rayLength, targetNormal);
        hit = hit || elementHit;
        elementHit = isRayHitElement(ray, vec3(14.0 / 16.0, 3.0 / 16.0, 2.0 / 16.0), vec3(2.0 / 16.0, 13.0 / 16.0, 12.0 / 16.0), rayLength, targetNormal);
        hit = hit || elementHit;
        elementHit = isRayHitElement(ray, vec3(0.0), vec3(2.0 / 16.0, 3.0 / 16.0, 4.0 / 16.0), rayLength, targetNormal);
        hit = hit || elementHit;
        elementHit = isRayHitElement(ray, vec3(2.0 / 16.0, 0.0, 0.0), vec3(2.0 / 16.0, 3.0 / 16.0, 2.0 / 16.0), rayLength, targetNormal);
        hit = hit || elementHit;
        elementHit = isRayHitElement(ray, vec3(0.0, 0.0, 12.0 / 16.0), vec3(2.0 / 16.0, 3.0 / 16.0, 4.0 / 16.0), rayLength, targetNormal);
        hit = hit || elementHit;
        elementHit = isRayHitElement(ray, vec3(2.0 / 16.0, 0.0, 14.0 / 16.0), vec3(2.0 / 16.0, 3.0 / 16.0, 2.0 / 16.0), rayLength, targetNormal);
        hit = hit || elementHit;
        elementHit = isRayHitElement(ray, vec3(14.0 / 16.0, 0.0, 0.0), vec3(2.0 / 16.0, 3.0 / 16.0, 4.0 / 16.0), rayLength, targetNormal);
        hit = hit || elementHit;
        elementHit = isRayHitElement(ray, vec3(12.0 / 16.0, 0.0, 0.0), vec3(2.0 / 16.0, 3.0 / 16.0, 2.0 / 16.0), rayLength, targetNormal);
        hit = hit || elementHit;
        elementHit = isRayHitElement(ray, vec3(14.0 / 16.0, 0.0, 12.0 / 16.0), vec3(2.0 / 16.0, 3.0 / 16.0, 2.0 / 16.0), rayLength, targetNormal);
        hit = hit || elementHit;
        elementHit = isRayHitElement(ray, vec3(12.0 / 16.0, 0.0, 14.0 / 16.0), vec3(4.0 / 16.0, 3.0 / 16.0, 2.0 / 16.0), rayLength, targetNormal);
        hit = hit || elementHit;
    }
    else if (materialID < 196.5) {
        float direction = materialID - 195.0;
        elementHit = isRayHitElement(ray, vec3(2.0, 0.0, 2.0) / 16.0, vec3(12.0, 4.0, 12.0) / 16.0, rayLength, targetNormal);
        hit = hit || elementHit;
        elementHit = isRayHitElement(
            ray, vec3(4.0 - direction, 4.0, 3.0 + direction) / 16.0,
            vec3(8.0 + 2.0 * direction, 1.0, 10.0 - 2.0 * direction) / 16.0, rayLength, targetNormal
        );
        hit = hit || elementHit;
        elementHit = isRayHitElement(
            ray, vec3(6.0 - 2.0 * direction, 5.0, 4.0 + 2.0 * direction) / 16.0,
            vec3(4.0 + 4.0 * direction, 5.0, 8.0 - 4.0 * direction) / 16.0, rayLength, targetNormal
        );
        hit = hit || elementHit;
        elementHit = isRayHitElement(
            ray, vec3(3.0 - 3.0 * direction, 10.0, 3.0 * direction) / 16.0,
            vec3(10.0 + 6.0 * direction, 6.0, 16.0 - 6.0 * direction) / 16.0, rayLength, targetNormal
        );
        hit = hit || elementHit;
    }
    else if (materialID < 208.5) {
        float pistonID = materialID - 197.0;
        float size = float(pistonID > 5.5) * 0.5 + (4.0 / 16.0);
        float offset = 1.0 - size;
        float offsetDir = mod(pistonID, 6.0);
        vec3 baseOrigin = vec3(float(offsetDir == 2) * offset, float(offsetDir == 4) * offset, float(offsetDir == 0) * offset);
        float axisZ = float(offsetDir < 1.5);
        float axisY = float(offsetDir > 3.5);
        float axisX = axisY + axisZ;
        vec3 baseSize = vec3(size + axisX - size * axisX, 1.0 + size * axisY - axisY, 1.0 + size * axisZ - axisZ);
        vec3 rodOrigin = vec3(6.0 / 16.0 * axisX, 6.0 / 16.0 - 6.0 / 16.0 * axisY, 6.0 / 16.0 - 6.0 / 16.0 * axisZ);
        vec3 rodSize = vec3(1.0 - 12.0 / 16.0 * axisX, 4.0 / 16.0 + 12.0 / 16.0 * axisY, 4.0 / 16.0 + 12.0 / 16.0 * axisZ);
        elementHit = isRayHitElement(ray, baseOrigin, baseSize, rayLength, targetNormal);
        hit = hit || elementHit;
        elementHit = isRayHitElement(ray, rodOrigin, rodSize, rayLength, targetNormal);
        hit = hit || elementHit;
    }
    #if PATH_TRACE_GEOMETRY_QUALITY > 2
    else if (materialID < 215.5) {
        float offset = materialID * 2.0 - 418.0;
        hit = isRayHitElement(ray, vec3(1.0 + offset, 0.0, 1.0) / 16.0, vec3(14.0 - offset, 8.0, 14.0) / 16.0, rayLength, targetNormal);
    }
    else if (materialID < 219.5) {
        float grindStoneID = materialID - 216.0;
        float axisZ = floor(grindStoneID / 2.0);
        float axisY = 1.0 - axisZ;
        float facing = axisZ * 6.0 - grindStoneID * 3.0;
        float stoneOffsetY = (grindStoneID * 4.0 - 2.0) * axisY;
        float stoneOffsetZ = (grindStoneID * 4.0 - 10.0) * axisZ;
        float baseOffsetY = stoneOffsetY * 3.0 - facing * axisY + 6.0;
        float baseOffsetZ = stoneOffsetZ * 3.0 - facing * axisZ + 6.0;
        elementHit = isRayHitElement(ray, vec3(4.0, 2.0 - stoneOffsetY, 2.0 - stoneOffsetZ) / 16.0, vec3(8.0, 12.0, 12.0) / 16.0, rayLength, targetNormal);
        hit = hit || elementHit;
        elementHit = isRayHitElement(ray, vec3(2.0, 5.0 - stoneOffsetY, 5.0 - stoneOffsetZ) / 16.0, vec3(12.0, 6.0, 6.0) / 16.0, rayLength, targetNormal);
        hit = hit || elementHit;
        elementHit = isRayHitElement(ray, vec3(2.0, baseOffsetY, baseOffsetZ) / 16.0, vec3(2.0, 4.0 + axisY * 3.0, 4.0 + axisZ * 3.0) / 16.0, rayLength, targetNormal);
        hit = hit || elementHit;
        elementHit = isRayHitElement(ray, vec3(12.0, baseOffsetY, baseOffsetZ) / 16.0, vec3(2.0, 4.0 + axisY * 3.0, 4.0 + axisZ * 3.0) / 16.0, rayLength, targetNormal);
        hit = hit || elementHit;
    }
    else if (materialID < 223.5) {
        float grindStoneID = materialID - 220.0;
        float axisX = floor(grindStoneID / 2.0);
        float axisY = 1.0 - axisX;
        float facing = axisX * 6.0 - grindStoneID * 3.0;
        float stoneOffsetY = (grindStoneID * 4.0 - 2.0) * axisY;
        float stoneOffsetX = (grindStoneID * 4.0 - 10.0) * axisX;
        float baseOffsetY = stoneOffsetY * 3.0 + facing * axisY + 6.0;
        float baseOffsetX = stoneOffsetX * 3.0 + facing * axisX + 6.0;
        elementHit = isRayHitElement(ray, vec3(2.0 - stoneOffsetX, 2.0 - stoneOffsetY, 4.0) / 16.0, vec3(12.0, 12.0, 8.0) / 16.0, rayLength, targetNormal);
        hit = hit || elementHit;
        elementHit = isRayHitElement(ray, vec3(5.0 - stoneOffsetX, 5.0 - stoneOffsetY, 2.0) / 16.0, vec3(6.0, 6.0, 12.0) / 16.0, rayLength, targetNormal);
        hit = hit || elementHit;
        elementHit = isRayHitElement(ray, vec3(baseOffsetX, baseOffsetY, 2.0) / 16.0, vec3(4.0 + axisX * 3.0, 4.0 + axisY * 3.0, 2.0) / 16.0, rayLength, targetNormal);
        hit = hit || elementHit;
        elementHit = isRayHitElement(ray, vec3(baseOffsetX, baseOffsetY, 12.0) / 16.0, vec3(4.0 + axisX * 3.0, 4.0 + axisY * 3.0, 2.00) / 16.0, rayLength, targetNormal);
        hit = hit || elementHit;
    }
    else if (materialID < 228.5) {
        float hopperID = materialID - 224.0;
        float direction = 12.0 * mod(hopperID, 2.0) - 6.0;
        elementHit = isRayHitElement(ray, vec3(0.0, 11.0, 0.0) / 16.0, vec3(16.0, 5.0, 2.0) / 16.0, rayLength, targetNormal);
        hit = hit || elementHit;
        elementHit = isRayHitElement(ray, vec3(0.0, 11.0, 14.0) / 16.0, vec3(16.0, 5.0, 2.0) / 16.0, rayLength, targetNormal);
        hit = hit || elementHit;
        elementHit = isRayHitElement(ray, vec3(0.0, 11.0, 2.0) / 16.0, vec3(2.0, 5.0, 12.0) / 16.0, rayLength, targetNormal);
        hit = hit || elementHit;
        elementHit = isRayHitElement(ray, vec3(14.0, 11.0, 2.0) / 16.0, vec3(2.0, 5.0, 12.0) / 16.0, rayLength, targetNormal);
        hit = hit || elementHit;
        elementHit = isRayHitElement(ray, vec3(0.0, 10.0, 0.0) / 16.0, vec3(16.0, 1.0, 16.0) / 16.0, rayLength, targetNormal);
        hit = hit || elementHit;
        elementHit = isRayHitElement(ray, vec3(4.0, 4.0, 4.0) / 16.0, vec3(8.0, 6.0, 8.0) / 16.0, rayLength, targetNormal);
        hit = hit || elementHit;
        elementHit = isRayHitElement(
            ray, vec3(6.0 + direction * step(2.5, hopperID), float(hopperID > 0.5) * 4.0, 6.0 + direction * step(abs(hopperID - 1.5), 1.0)) / 16.0,
            vec3(4.0, 4.0, 4.0) / 16.0, rayLength, targetNormal
        );
        hit = hit || elementHit;
    }
    else if (materialID < 229.5) {
        elementHit = isRayHitElement(ray, vec3(0.0), vec3(16.0, 2.0, 16.0) / 16.0, rayLength, targetNormal);
        hit = hit || elementHit;
        elementHit = isRayHitElement(ray, vec3(4.0, 2.0, 4.0) / 16.0, vec3(8.0, 13.0, 8.0) / 16.0, rayLength, targetNormal);
        hit = hit || elementHit;
    }
    else if (materialID < 232.5) {
        float northSouth = float(materialID == 149.0);
        float eastWest = float(materialID == 150.0);
        float upDown = clamp(1.0 - northSouth - eastWest, 0.0, 1.0);
        vec3 elementStart = 7.0 / 16.0 * (1.0 - vec3(eastWest, upDown, northSouth));
        vec3 elementSize = (vec3(eastWest, upDown, northSouth) * 14.0 + 2.0) / 16.0;
        elementHit = isRayHitElement(ray, elementStart, elementSize, rayLength, targetNormal);
        hit = hit || elementHit;
    }
    else if (materialID < 233.5) {
        hit = isRayHitElement(ray, vec3(7.0, 0.0, 7.0) / 16.0, vec3(2.0, 10.0, 2.0) / 16.0, rayLength, targetNormal);
    }
    else if (materialID < 237.5) {
        const float angle = PI / 8.0;
        const float sinAngle = sin(angle);
        const float cosAngle = cos(angle);
        float wallTorchID = materialID - 234.0;
        float direction1 = step(1.5, wallTorchID);
        float direction1Inv = 1.0 - direction1;
        float dirSigned = wallTorchID * 2.0 - direction1 * 4.0 - 1.0;
        float northSouth = dirSigned * direction1Inv;
        float eastWest = dirSigned * direction1;

        vec3 rotationOrigin = vec3(8.0, 22.8137, 8.0) / 16.0;
        float eastWestSin = sinAngle * eastWest;
        float northSouthSin = sinAngle * northSouth;
        float dir1Cos = mix(1.0, cosAngle, direction1);
        float dir1InvCos = mix(1.0, cosAngle, direction1Inv);
        vec3 rotatedRayDir = vec3(
            dir1Cos * ray.direction.x + eastWestSin * ray.direction.y,
            -eastWestSin * ray.direction.x + cosAngle * ray.direction.y + northSouthSin * ray.direction.z,
            dir1InvCos * ray.direction.z - northSouthSin * ray.direction.y
        );
        vec3 originOffset = ray.origin - 1e-5 - rotationOrigin;
        vec3 rotatedOrigin = vec3(
            dir1Cos * originOffset.x + eastWestSin * originOffset.y,
            -eastWestSin * originOffset.x + cosAngle * originOffset.y + northSouthSin * originOffset.z,
            dir1InvCos * originOffset.z - northSouthSin * originOffset.y
        );
        Ray rotatedRay = Ray(
            rotatedOrigin + rotationOrigin, rotatedRayDir, 1.0 / rotatedRayDir, signI(rotatedRayDir)
        );
        rotatedRay.origin += 1e-5;
        hit = isRayHitElement(rotatedRay, vec3(7.0, 1.9087, 7.0) / 16.0, vec3(2.0, 10.0, 2.0) / 16.0, rayLength, targetNormal);
    }
    else if (materialID < 239.5) {
        float lanternID = materialID - 238.0;
        elementHit = isRayHitElement(ray, vec3(5.0, lanternID, 5.0) / 16.0, vec3(6.0, 7.0, 6.0) / 16.0, rayLength, targetNormal);
        hit = hit || elementHit;
        elementHit = isRayHitElement(ray, vec3(6.0, 7.0 + lanternID, 6.0) / 16.0, vec3(4.0, 2.0, 4.0) / 16.0, rayLength, targetNormal);
        hit = hit || elementHit;
    }
    else if (materialID < 241.5) {
        float eastWest = materialID - 240.0;
        float northSouth = 1.0 - eastWest;
        elementHit = isRayHitElement(ray, vec3(northSouth * 5.0, 0.0, eastWest * 5.0) / 16.0, vec3(6.0 + eastWest * 10.0, 1.0, 6.0 + northSouth * 10.0) / 16.0, rayLength, targetNormal);
        hit = hit || elementHit;
        elementHit = isRayHitElement(ray, vec3(northSouth, 0.0, eastWest) / 16.0, vec3(4.0 + eastWest * 12.0, 4.0, 4.0 + northSouth * 12.0) / 16.0, rayLength, targetNormal);
        hit = hit || elementHit;
        elementHit = isRayHitElement(ray, vec3(northSouth * 11.0, 0.0, eastWest * 11.0) / 16.0, vec3(4.0 + eastWest * 12.0, 4.0, 4.0 + northSouth * 12.0) / 16.0, rayLength, targetNormal);
        hit = hit || elementHit;
        elementHit = isRayHitElement(ray, vec3(eastWest, 3.0, northSouth) / 16.0, vec3(4.0 + northSouth * 12.0, 4.0, 4.0 + eastWest * 12.0) / 16.0, rayLength, targetNormal);
        hit = hit || elementHit;
        elementHit = isRayHitElement(ray, vec3(eastWest * 11.0, 3.0, northSouth * 11.0) / 16.0, vec3(4.0 + northSouth * 12.0, 4.0, 4.0 + eastWest * 12.0) / 16.0, rayLength, targetNormal);
        hit = hit || elementHit;
    }
    else if (materialID < 242.5) {
        hit = isRayHitElement(ray, vec3(7.0, 0.0, 7.0) / 16.0, vec3(2.0, 6.0, 2.0) / 16.0, rayLength, targetNormal);
    }
    else if (materialID < 243.5) {
        elementHit = isRayHitElement(ray, vec3(9.0, 0.0, 6.0) / 16.0, vec3(2.0, 6.0, 2.0) / 16.0, rayLength, targetNormal);
        hit = hit || elementHit;
        elementHit = isRayHitElement(ray, vec3(5.0, 0.0, 7.0) / 16.0, vec3(2.0, 6.0, 2.0) / 16.0, rayLength, targetNormal);
        hit = hit || elementHit;
    }
    else if (materialID < 244.5) {
        elementHit = isRayHitElement(ray, vec3(8.0, 0.0, 6.0) / 16.0, vec3(2.0, 6.0, 2.0) / 16.0, rayLength, targetNormal);
        hit = hit || elementHit;
        elementHit = isRayHitElement(ray, vec3(5.0, 0.0, 7.0) / 16.0, vec3(2.0, 6.0, 2.0) / 16.0, rayLength, targetNormal);
        hit = hit || elementHit;
        elementHit = isRayHitElement(ray, vec3(7.0, 0.0, 9.0) / 16.0, vec3(2.0, 6.0, 2.0) / 16.0, rayLength, targetNormal);
        hit = hit || elementHit;
    }
    else if (materialID < 245.5) {
        elementHit = isRayHitElement(ray, vec3(8.0, 0.0, 5.0) / 16.0, vec3(2.0, 6.0, 2.0) / 16.0, rayLength, targetNormal);
        hit = hit || elementHit;
        elementHit = isRayHitElement(ray, vec3(5.0, 0.0, 5.0) / 16.0, vec3(2.0, 6.0, 2.0) / 16.0, rayLength, targetNormal);
        hit = hit || elementHit;
        elementHit = isRayHitElement(ray, vec3(6.0, 0.0, 8.0) / 16.0, vec3(2.0, 6.0, 2.0) / 16.0, rayLength, targetNormal);
        hit = hit || elementHit;
        elementHit = isRayHitElement(ray, vec3(9.0, 0.0, 8.0) / 16.0, vec3(2.0, 5.0, 2.0) / 16.0, rayLength, targetNormal);
        hit = hit || elementHit;
    }
    // else if (materialID < 246.5) {
    // }
    // else if (materialID < 247.5) {
    // }
    // else if (materialID < 248.5) {
    // }
    else if (materialID < 249.5) {
    }
    else if (materialID < 250.5) {
        elementHit = isRayHitElement(ray, vec3(1.0, 0.0, 1.0) / 16.0, vec3(14.0, 8.0, 14.0) / 16.0, rayLength, targetNormal);
        hit = hit || elementHit;
        elementHit = isRayHitElement(ray, vec3(7.0, 8.0, 7.0) / 16.0, vec3(2.0, 6.0, 2.0) / 16.0, rayLength, targetNormal);
        hit = hit || elementHit;
    }
    else if (materialID < 251.5) {
        #if MC_VERSION >= 11900
            elementHit = isRayHitElement(ray, vec3(1.0, 0.0, 1.0) / 16.0, vec3(6.0, 2.0, 6.0) / 16.0, rayLength, targetNormal);
            hit = hit || elementHit;
            elementHit = isRayHitElement(ray, vec3(1.0, 0.0, 9.0) / 16.0, vec3(6.0, 2.0, 6.0) / 16.0, rayLength, targetNormal);
            hit = hit || elementHit;
        #else
            elementHit = isRayHitElement(ray, vec3(2.0, 0.0, 1.0) / 16.0, vec3(6.0, 2.0, 6.0) / 16.0, rayLength, targetNormal);
            hit = hit || elementHit;
            elementHit = isRayHitElement(ray, vec3(2.0, 0.0, 9.0) / 16.0, vec3(6.0, 2.0, 6.0) / 16.0, rayLength, targetNormal);
            hit = hit || elementHit;
        #endif
        elementHit = isRayHitElement(ray, vec3(9.0, 0.0, 5.0) / 16.0, vec3(6.0, 2.0, 6.0) / 16.0, rayLength, targetNormal);
        hit = hit || elementHit;
        elementHit = isRayHitElement(ray, vec3(7.0, 0.0, 7.0) / 16.0, vec3(2.0, 14.0, 2.0) / 16.0, rayLength, targetNormal);
        hit = hit || elementHit;
    }
    else if (materialID < 252.5) {
        elementHit = isRayHitElement(ray, vec3(6.0, 0.0, 6.0) / 16.0, vec3(4.0, 4.0, 4.0) / 16.0, rayLength, targetNormal);
        hit = hit || elementHit;
        elementHit = isRayHitElement(ray, vec3(5.0, 0.0, 5.0) / 16.0, vec3(6.0, 6.0, 1.0) / 16.0, rayLength, targetNormal);
        hit = hit || elementHit;
        elementHit = isRayHitElement(ray, vec3(5.0, 0.0, 10.0) / 16.0, vec3(6.0, 6.0, 1.0) / 16.0, rayLength, targetNormal);
        hit = hit || elementHit;
        elementHit = isRayHitElement(ray, vec3(5.0, 0.0, 6.0) / 16.0, vec3(1.0, 6.0, 4.0) / 16.0, rayLength, targetNormal);
        hit = hit || elementHit;
        elementHit = isRayHitElement(ray, vec3(10.0, 0.0, 6.0) / 16.0, vec3(1.0, 6.0, 4.0) / 16.0, rayLength, targetNormal);
        hit = hit || elementHit;
    }
    else if (materialID < 253.5) {
        elementHit = isRayHitElement(ray, vec3(3.0, 0.0, 3.0) / 16.0, vec3(10.0, 13.0, 10.0) / 16.0, rayLength, targetNormal);
        hit = hit || elementHit;
        elementHit = isRayHitElement(ray, vec3(2.0, 1.0, 2.0) / 16.0, vec3(12.0, 10.0, 12.0) / 16.0, rayLength, targetNormal);
        hit = hit || elementHit;
        elementHit = isRayHitElement(ray, vec3(1.0, 3.0, 1.0) / 16.0, vec3(14.0, 5.0, 14.0) / 16.0, rayLength, targetNormal);
        hit = hit || elementHit;
        elementHit = isRayHitElement(ray, vec3(5.0, 13.0, 5.0) / 16.0, vec3(6.0, 2.0, 6.0) / 16.0, rayLength, targetNormal);
        hit = hit || elementHit;
        elementHit = isRayHitElement(ray, vec3(6.0, 15.0, 6.0) / 16.0, vec3(4.0, 1.0, 4.0) / 16.0, rayLength, targetNormal);
        hit = hit || elementHit;
    }
    else if (materialID < 254.5) {
        elementHit = isRayHitElement(ray, vec3(0.0, 0.0, 0.0), vec3(1.0, 13.0 / 16.0, 1.0), rayLength, targetNormal);
        hit = hit || elementHit;
        elementHit = isRayHitElement(ray, vec3(0.25, 13.0 / 16.0, 0.25), vec3(0.5, 3.0 / 16.0, 0.5), rayLength, targetNormal);
        hit = hit || elementHit;
    }
    else if (materialID < 255.5) {
        elementHit = isRayHitElement(ray, vec3(1.0, 0.0, 2.0) / 16.0, vec3(14.0, 16.0, 12.0) / 16.0, rayLength, targetNormal);
        hit = hit || elementHit;
    }
    else if (materialID < 256.5) {
        elementHit = isRayHitElement(ray, vec3(2.0, 0.0, 2.0) / 16.0, vec3(12.0, 3.0, 12.0) / 16.0, rayLength, targetNormal);
        hit = hit || elementHit;
        elementHit = isRayHitElement(ray, vec3(3.0 / 16.0), vec3(10.0, 11.0, 10.0) / 16.0, rayLength, targetNormal);
        hit = hit || elementHit;
    }
    #ifdef QUALITY_CUTOUT_TRACE
    else if (materialID < 272.5) {
    }
    else if (materialID < 273.5) {
        const vec2 basicCoordOffset = vec2(0.0, -1.0) / 16.0;
        elementHit = isRayHitElementCutout(
            ray, albedoSampler, originOffset, atlasTiles, centerCoord, vec3(0.0, 0.0, 4.0) / 16.0, vec3(16.0, 15.0, 0.0) / 16.0,
            basicCoordOffset, vec2(1.0), vec2(0.0), rayLength, targetNormal
        );
        hit = hit || elementHit;
        elementHit = isRayHitElementCutout(
            ray, albedoSampler, originOffset, atlasTiles, centerCoord, vec3(4.0, 0.0, 0.0) / 16.0, vec3(0.0, 15.0, 16.0) / 16.0,
            basicCoordOffset, vec2(1.0), vec2(0.0), rayLength, targetNormal
        );
        hit = hit || elementHit;
        elementHit = isRayHitElementCutout(
            ray, albedoSampler, originOffset, atlasTiles, centerCoord, vec3(0.0, 0.0, 12.0) / 16.0, vec3(16.0, 15.0, 0.0) / 16.0,
            basicCoordOffset, vec2(1.0), vec2(0.0), rayLength, targetNormal
        );
        hit = hit || elementHit;
        elementHit = isRayHitElementCutout(
            ray, albedoSampler, originOffset, atlasTiles, centerCoord, vec3(12.0, 0.0, 0.0) / 16.0, vec3(0.0, 15.0, 16.0) / 16.0,
            basicCoordOffset, vec2(1.0), vec2(0.0), rayLength, targetNormal
        );
        hit = hit || elementHit;
    }
    else if (materialID < 275.5) {
        vec2 basicCoordScale = vec2(0.7856, signI(274.5 - materialID));
        const float angle = sqrt(2.0) / 2.0;
        const vec3 rotationOrigin = vec3(0.5 + 1e-5, 0.0, 0.5 + 1e-5);
        ray.origin.xz = vec2(angle * (ray.origin.x + ray.origin.z - 1.0 - 2e-5), angle * (ray.origin.z - ray.origin.x)) + (0.5 + 1e-5);
        ray.direction = vec3(angle * (ray.direction.x + ray.direction.z), ray.direction.y, angle * (ray.direction.z - ray.direction.x));
        ray.dirInv = 1.0 / ray.direction;
        ray.dirSigned = signI(ray.direction);
        vec3 rotatedOriginOffset = ray.origin - vec3(0.5 + 1e-5);
        elementHit = isRayHitElementCutout(
            ray, albedoSampler, rotatedOriginOffset, atlasTiles, centerCoord, vec3(-2.1823, 0.0, 8.0) / 16.0, vec3(20.3647, 16.0, 0.0) / 16.0,
            vec2(0.0), basicCoordScale, vec2(0.0), rayLength, targetNormal
        );
        hit = hit || elementHit;
        elementHit = isRayHitElementCutout(
            ray, albedoSampler, rotatedOriginOffset, atlasTiles, centerCoord, vec3(8.0, 0.0, -2.1823) / 16.0, vec3(0.0, 16.0, 20.3647) / 16.0,
            vec2(0.0), basicCoordScale, vec2(0.0), rayLength, targetNormal
        );
        hit = hit || elementHit;
    }
    else if (materialID < 277.5) {
        vec2 basicCoordScale = vec2(0.7856, signI(276.5 - materialID));
        const float angle = sqrt(2.0) / 2.0;
        const vec3 rotationOrigin = vec3(0.5 + 1e-5, 0.0, 0.5 + 1e-5);
        ray.origin.xy = vec2(angle * (ray.origin.x - ray.origin.y), angle * (ray.origin.x + ray.origin.y - 1.0 - 2e-5)) + (0.5 + 1e-5);
        ray.direction = vec3(angle * (ray.direction.x - ray.direction.y), angle * (ray.direction.x + ray.direction.y), ray.direction.z);
        ray.dirInv = 1.0 / ray.direction;
        ray.dirSigned = signI(ray.direction);
        elementHit = isRayHitElementCutout(
            ray, albedoSampler, ray.origin - vec3(0.5 + 1e-5), atlasTiles, centerCoord, vec3(-2.1823, 8.0, 0.0) / 16.0, vec3(20.3647, 0.0, 16.0) / 16.0,
            vec2(0.0), basicCoordScale, vec3(0.0, 1.0, 0.0), vec2(0.0), rayLength, targetNormal
        );
        hit = hit || elementHit;
        elementHit = isRayHitElementCutoutRotated(
            ray, albedoSampler, ray.origin - vec3(0.5 + 1e-5), atlasTiles, centerCoord, vec3(8.0, -2.1823, 0.0) / 16.0, vec3(0.0, 20.3647, 16.0) / 16.0,
            vec2(0.0), basicCoordScale, vec3(-1.0, 0.0, 0.0), vec2(0.0), rayLength, targetNormal
        );
        hit = hit || elementHit;
    }
    else if (materialID < 279.5) {
        vec2 basicCoordScale = vec2(0.7856, signI(278.5 - materialID));
        const float angle = sqrt(2.0) / 2.0;
        const vec3 rotationOrigin = vec3(0.5 + 1e-5, 0.0, 0.5 + 1e-5);
        ray.origin.yz = vec2(angle * (ray.origin.y - ray.origin.z), angle * (ray.origin.y + ray.origin.z - 1.0 - 2e-5)) + (0.5 + 1e-5);
        ray.direction = vec3(ray.direction.x, angle * (ray.direction.y - ray.direction.z), angle * (ray.direction.y + ray.direction.z));
        ray.dirInv = 1.0 / ray.direction;
        ray.dirSigned = signI(ray.direction);
        elementHit = isRayHitElementCutoutRotated(
            ray, albedoSampler, ray.origin - vec3(0.5 + 1e-5), atlasTiles, centerCoord, vec3(0.0, 8.0, -2.1823) / 16.0, vec3(16.0, 0.0, 20.3647) / 16.0,
            vec2(0.0), basicCoordScale, vec3(0.0, 0.0, 0.0), vec2(0.0), rayLength, targetNormal
        );
        hit = hit || elementHit;
        elementHit = isRayHitElementCutoutRotated(
            ray, albedoSampler, ray.origin - vec3(0.5 + 1e-5), atlasTiles, centerCoord, vec3(0.0, -2.1823, 8.0) / 16.0, vec3(16.0, 20.3647, 0.0) / 16.0,
            vec2(0.0), basicCoordScale, vec3(0.0, 0.0, 1.0), vec2(0.0), rayLength, targetNormal
        );
        hit = hit || elementHit;
    }
    else if (materialID < 341.5) {}
    else if (materialID < 343.5) {
        elementHit = isRayHitElement(ray, vec3(0.0, 0.0, 0.0) / 16.0, vec3(2.0, 16.0, 2.0) / 16.0, rayLength, targetNormal);
        hit = hit || elementHit;
        elementHit = isRayHitElement(ray, vec3(0.0, 0.0, 14.0) / 16.0, vec3(2.0, 16.0, 2.0) / 16.0, rayLength, targetNormal);
        hit = hit || elementHit;
        elementHit = isRayHitElement(ray, vec3(14.0, 0.0, 0.0) / 16.0, vec3(2.0, 16.0, 2.0) / 16.0, rayLength, targetNormal);
        hit = hit || elementHit;
        elementHit = isRayHitElement(ray, vec3(14.0, 0.0, 14.0) / 16.0, vec3(2.0, 16.0, 2.0) / 16.0, rayLength, targetNormal);
        hit = hit || elementHit;
        elementHit = isRayHitElement(ray, vec3(2.0, 14.0, 0.0) / 16.0, vec3(12.0, 2.0, 2.0) / 16.0, rayLength, targetNormal);
        hit = hit || elementHit;
        elementHit = isRayHitElement(ray, vec3(2.0, 14.0, 14.0) / 16.0, vec3(12.0, 2.0, 2.0) / 16.0, rayLength, targetNormal);
        hit = hit || elementHit;
        elementHit = isRayHitElement(ray, vec3(0.0, 14.0, 2.0) / 16.0, vec3(2.0, 2.0, 12.0) / 16.0, rayLength, targetNormal);
        hit = hit || elementHit;
        elementHit = isRayHitElement(ray, vec3(14.0, 14.0, 2.0) / 16.0, vec3(2.0, 2.0, 12.0) / 16.0, rayLength, targetNormal);
        hit = hit || elementHit;
        elementHit = isRayHitElementCutout(
            ray, albedoSampler, originOffset, atlasTiles, centerCoord, vec3(2.0, 15.99, 2.0) / 16.0, vec3(12.0, 0.01, 12.0) / 16.0,
            vec2(0.0), vec2(1.0, 1.0), vec2(0.0), rayLength, targetNormal
        );
        hit = hit || elementHit;
        if (materialID > 342.5) {
            elementHit = isRayHitElement(ray, vec3(2.0, 0.0, 0.0) / 16.0, vec3(12.0, 2.0, 2.0) / 16.0, rayLength, targetNormal);
            hit = hit || elementHit;
            elementHit = isRayHitElement(ray, vec3(2.0, 0.0, 14.0) / 16.0, vec3(12.0, 2.0, 2.0) / 16.0, rayLength, targetNormal);
            hit = hit || elementHit;
            elementHit = isRayHitElement(ray, vec3(0.0, 0.0, 2.0) / 16.0, vec3(2.0, 2.0, 12.0) / 16.0, rayLength, targetNormal);
            hit = hit || elementHit;
            elementHit = isRayHitElement(ray, vec3(14.0, 0.0, 2.0) / 16.0, vec3(2.0, 2.0, 12.0) / 16.0, rayLength, targetNormal);
            hit = hit || elementHit;
            elementHit = isRayHitElementCutout(
                ray, albedoSampler, originOffset, atlasTiles, centerCoord, vec3(2.0, 1.99, 2.0) / 16.0, vec3(12.0, 0.01, 12.0) / 16.0,
                vec2(0.0), vec2(1.0, 1.0), vec2(0.0), rayLength, targetNormal
            );
            hit = hit || elementHit;
        }
    }
    #else
    else if (materialID < 272.5) {
    }
    else if (materialID < 273.5) {
        elementHit = isRayHitElement(ray, vec3(0.0, 0.0, 4.0) / 16.0, vec3(16.0, 15.0, 0.0) / 16.0, rayLength, targetNormal);
        hit = hit || elementHit;
        elementHit = isRayHitElement(ray, vec3(4.0, 0.0, 0.0) / 16.0, vec3(0.0, 15.0, 16.0) / 16.0, rayLength, targetNormal);
        hit = hit || elementHit;
        elementHit = isRayHitElement(ray, vec3(0.0, 0.0, 12.0) / 16.0, vec3(16.0, 15.0, 0.0) / 16.0, rayLength, targetNormal);
        hit = hit || elementHit;
        elementHit = isRayHitElement(ray, vec3(12.0, 0.0, 0.0) / 16.0, vec3(0.0, 15.0, 16.0) / 16.0, rayLength, targetNormal);
        hit = hit || elementHit;
        targetOpacity = getTargetAlbedo(ray, albedoSampler, originOffset, atlasTiles, vec3(1.0), centerCoord, targetNormal, rayLength, vec2(0.0, -1.0) / 16.0, vec2(1.0), 0.0).a;
    }
    else if (materialID < 275.5) {
        vec2 basicCoordScale = vec2(0.7856, signI(724.5 - materialID));
        const float angle = sqrt(2.0) / 2.0;
        const vec3 rotationOrigin = vec3(0.5 + 1e-5, 0.0, 0.5 + 1e-5);
        ray.origin.xz = vec2(angle * (ray.origin.x + ray.origin.z - 1.0 - 2e-5), angle * (ray.origin.z - ray.origin.x)) + (0.5 + 1e-5);
        ray.direction = vec3(angle * (ray.direction.x + ray.direction.z), ray.direction.y, angle * (ray.direction.z - ray.direction.x));
        ray.dirInv = 1.0 / ray.direction;
        ray.dirSigned = signI(ray.direction);
        vec3 rotatedOriginOffset = ray.origin - vec3(0.5 + 1e-5);
        elementHit = isRayHitElement(ray, vec3(-2.1823, 0.0, 8.0) / 16.0, vec3(20.3647, 16.0, 0.0) / 16.0, rayLength, targetNormal);
        hit = hit || elementHit;
        elementHit = isRayHitElement(ray, vec3(8.0, 0.0, -2.1823) / 16.0, vec3(0.0, 16.0, 20.3647) / 16.0, rayLength, targetNormal);
        hit = hit || elementHit;
        targetOpacity = getTargetAlbedo(ray, albedoSampler, rotatedOriginOffset, atlasTiles, vec3(1.0), centerCoord, targetNormal, rayLength, vec2(0.0, 0.0), basicCoordScale, 0.0).a;
    }
    else if (materialID < 277.5) {
        vec2 basicCoordScale = vec2(0.7856, signI(276.5 - materialID));
        const float angle = sqrt(2.0) / 2.0;
        const vec3 rotationOrigin = vec3(0.5 + 1e-5, 0.0, 0.5 + 1e-5);
        ray.origin.xy = vec2(angle * (ray.origin.x - ray.origin.y), angle * (ray.origin.x + ray.origin.y - 1.0 - 2e-5)) + (0.5 + 1e-5);
        ray.direction = vec3(angle * (ray.direction.x - ray.direction.y), angle * (ray.direction.x + ray.direction.y), ray.direction.z);
        ray.dirInv = 1.0 / ray.direction;
        ray.dirSigned = signI(ray.direction);
        elementHit = isRayHitElement(ray, vec3(-2.1823, 8.0, 0.0) / 16.0, vec3(20.3647, 0.0, 16.0) / 16.0, rayLength, targetNormal);
        hit = hit || elementHit;
        elementHit = isRayHitElement(ray, vec3(8.0, -2.1823, 0.0) / 16.0, vec3(0.0, 20.3647, 16.0) / 16.0, rayLength, targetNormal);
        hit = hit || elementHit;
        if (elementHit) {
            basicCoordScale.y = signMul(basicCoordScale.y, 0.999 - targetNormal.x);
            targetOpacity = getTargetAlbedoRotated(ray, albedoSampler, ray.origin - vec3(0.5 + 1e-5), atlasTiles, centerCoord, targetNormal, rayLength, vec2(0.0), basicCoordScale, 0.0).w;
        }
        else {
            basicCoordScale.y = signMul(basicCoordScale.y, targetNormal.y + 0.999);
            targetOpacity = getTargetAlbedo(ray, albedoSampler, ray.origin - vec3(0.5 + 1e-5), atlasTiles, vec3(1.0), centerCoord, targetNormal, rayLength, vec2(0.0), basicCoordScale, 0.0).w;
        }
    }
    else if (materialID < 279.5) {
        vec2 basicCoordScale = vec2(0.7856, signI(278.5 - materialID));
        const float angle = sqrt(2.0) / 2.0;
        const vec3 rotationOrigin = vec3(0.5 + 1e-5, 0.0, 0.5 + 1e-5);
        ray.origin.yz = vec2(angle * (ray.origin.y - ray.origin.z), angle * (ray.origin.y + ray.origin.z - 1.0 - 2e-5)) + (0.5 + 1e-5);
        ray.direction = vec3(ray.direction.x, angle * (ray.direction.y - ray.direction.z), angle * (ray.direction.y + ray.direction.z));
        ray.dirInv = 1.0 / ray.direction;
        ray.dirSigned = signI(ray.direction);
        elementHit = isRayHitElement(ray, vec3(0.0, 8.0, -2.1823) / 16.0, vec3(16.0, 0.0, 20.3647) / 16.0, rayLength, targetNormal);
        hit = hit || elementHit;
        elementHit = isRayHitElement(ray, vec3(0.0, -2.1823, 8.0) / 16.0, vec3(16.0, 20.3647, 0.0) / 16.0, rayLength, targetNormal);
        hit = hit || elementHit;
        basicCoordScale.y = signMul(basicCoordScale.y, targetNormal.z + 0.999);
        targetOpacity = getTargetAlbedoRotated(ray, albedoSampler, ray.origin - vec3(0.5 + 1e-5), atlasTiles, centerCoord, targetNormal, rayLength, vec2(0.0), basicCoordScale, 0.0).w;
    }
    else if (materialID < 341.5) {}
    else if (materialID < 343.5) {
        elementHit = isRayHitElement(ray, vec3(0.0, 0.0, 0.0) / 16.0, vec3(2.0, 16.0, 2.0) / 16.0, rayLength, targetNormal);
        hit = hit || elementHit;
        elementHit = isRayHitElement(ray, vec3(0.0, 0.0, 14.0) / 16.0, vec3(2.0, 16.0, 2.0) / 16.0, rayLength, targetNormal);
        hit = hit || elementHit;
        elementHit = isRayHitElement(ray, vec3(14.0, 0.0, 0.0) / 16.0, vec3(2.0, 16.0, 2.0) / 16.0, rayLength, targetNormal);
        hit = hit || elementHit;
        elementHit = isRayHitElement(ray, vec3(14.0, 0.0, 14.0) / 16.0, vec3(2.0, 16.0, 2.0) / 16.0, rayLength, targetNormal);
        hit = hit || elementHit;
        elementHit = isRayHitElement(ray, vec3(2.0, 14.0, 0.0) / 16.0, vec3(12.0, 2.0, 2.0) / 16.0, rayLength, targetNormal);
        hit = hit || elementHit;
        elementHit = isRayHitElement(ray, vec3(2.0, 14.0, 14.0) / 16.0, vec3(12.0, 2.0, 2.0) / 16.0, rayLength, targetNormal);
        hit = hit || elementHit;
        elementHit = isRayHitElement(ray, vec3(0.0, 14.0, 2.0) / 16.0, vec3(2.0, 2.0, 12.0) / 16.0, rayLength, targetNormal);
        hit = hit || elementHit;
        elementHit = isRayHitElement(ray, vec3(14.0, 14.0, 2.0) / 16.0, vec3(2.0, 2.0, 12.0) / 16.0, rayLength, targetNormal);
        hit = hit || elementHit;
        elementHit = isRayHitElement(ray, vec3(2.0, 15.99, 2.0) / 16.0, vec3(12.0, 0.01, 12.0) / 16.0, rayLength, targetNormal);
        hit = hit || elementHit;
        if (materialID > 342.5) {
            elementHit = isRayHitElement(ray, vec3(2.0, 0.0, 0.0) / 16.0, vec3(12.0, 2.0, 2.0) / 16.0, rayLength, targetNormal);
            hit = hit || elementHit;
            elementHit = isRayHitElement(ray, vec3(2.0, 0.0, 14.0) / 16.0, vec3(12.0, 2.0, 2.0) / 16.0, rayLength, targetNormal);
            hit = hit || elementHit;
            elementHit = isRayHitElement(ray, vec3(0.0, 0.0, 2.0) / 16.0, vec3(2.0, 2.0, 12.0) / 16.0, rayLength, targetNormal);
            hit = hit || elementHit;
            elementHit = isRayHitElement(ray, vec3(14.0, 0.0, 2.0) / 16.0, vec3(2.0, 2.0, 12.0) / 16.0, rayLength, targetNormal);
            hit = hit || elementHit;
            elementHit = isRayHitElement(ray, vec3(2.0, 1.99, 2.0) / 16.0, vec3(12.0, 0.01, 12.0) / 16.0, rayLength, targetNormal);
            hit = hit || elementHit;
        }
    }
    #endif
    #endif
    #endif
    #endif
    return hit;
}
