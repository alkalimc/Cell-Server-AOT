vec2 clampCoordRange(vec2 coord, vec4 coordRange) {
    return coordRange.xy + fract(coord) * coordRange.zw;
}

#ifdef MC_NORMAL_MAP
    vec4 heightGather(sampler2D normalSampler, vec2 coord, vec2 coord00, vec4 coordRange, vec2 quadTexelSize, vec2 normalTexSize) {
        ivec2 texel00 = ivec2(coord00);
        ivec2 texel11 = ivec2(clampCoordRange(coord + 0.499 * quadTexelSize, coordRange) * normalTexSize);
        vec4 sh = vec4(
            texelFetch(normalSampler, ivec2(texel00.x, texel11.y), 0).a,
            texelFetch(normalSampler, texel11, 0).a,
            texelFetch(normalSampler, ivec2(texel11.x, texel00.y), 0).a,
            texelFetch(normalSampler, texel00, 0).a
        );
        sh += clamp(1.0 - sh * 1e+10, vec4(0.0), vec4(1.0));
        return sh;
    }

    float bilinearHeightSample(sampler2D normalSampler, vec2 coord, vec4 coordRange, vec2 quadTexelSize, vec2 normalTexSize) {
        vec2 coord00 = clampCoordRange(coord - 0.499 * quadTexelSize, coordRange) * normalTexSize;
        vec4 sh = heightGather(normalSampler, coord, coord00, coordRange, quadTexelSize, normalTexSize);
        vec2 fpc = fract(coord00);
        vec2 x = mix(sh.wx, sh.zy, vec2(fpc.x));
        return mix(x.x, x.y, fpc.y);
    }

    vec3 heightBasedNormal(sampler2D normalSampler, vec2 coord, vec4 coordRange, vec2 quadTexelSize, vec2 normalTexSize, vec2 pixelScale) {
        vec2 tileCoord = (coord - coordRange.xy) / coordRange.zw;
        vec2 coord00 = clampCoordRange(tileCoord - 0.499 * quadTexelSize, coordRange) * normalTexSize;
        vec4 sh = heightGather(normalSampler, tileCoord, coord00, coordRange, quadTexelSize, normalTexSize);

        vec2 fpc = fract(coord00);
        sh.y = sh.x + sh.z - sh.w - sh.y;
        vec3 normal = vec3(
            sh.y * fpc.yx + (sh.w - sh.zx),
            (5.0 / PARALLAX_DEPTH)
        );
        normal.xy /= pixelScale;

        return normal;
    }

    vec4 bilinearNormalSample(sampler2D normalSampler, vec2 coord, vec4 coordRange, vec2 quadTexelSize, vec2 normalTexSize) {
        vec4[4] sh;
        vec2 tileCoord = (coord - coordRange.xy) / coordRange.zw;
        vec2 coord00 = clampCoordRange(tileCoord - 0.5 * quadTexelSize, coordRange);
        vec2 coord11 = clampCoordRange(tileCoord + 0.5 * quadTexelSize, coordRange);
        sh = vec4[4](
            textureLod(normalSampler, vec2(coord00.x, coord11.y), 0.0),
            textureLod(normalSampler, coord11, 0.0),
            textureLod(normalSampler, vec2(coord11.x, coord00.y), 0.0),
            textureLod(normalSampler, coord00, 0.0)
        );
        vec2 fpc = fract(coord * normalTexSize + 0.5);
        return mix(
            mix(sh[3], sh[2], vec4(fpc.x)),
            mix(sh[0], sh[1], vec4(fpc.x)),
            vec4(fpc.y)
        );
    }
#endif
