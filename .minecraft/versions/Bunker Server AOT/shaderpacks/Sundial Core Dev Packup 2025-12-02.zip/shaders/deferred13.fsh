#version 450

#include "/programs/deferred/Deferred13.frag"
