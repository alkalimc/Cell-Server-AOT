#version 450

#include "/programs/composite/Composite9.frag"
