#version 450

#include "/programs/common/FlipBuffer.frag"
