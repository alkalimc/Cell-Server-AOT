#version 450

#include "/programs/prepare/Prepare0.comp"
