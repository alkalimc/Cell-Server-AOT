#version 450

#include "/programs/gbuffers/Weather.vert"
