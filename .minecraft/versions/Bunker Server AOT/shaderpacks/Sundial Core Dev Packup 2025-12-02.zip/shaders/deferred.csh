#version 450

#define SHADOW_AND_SKY

#include "/programs/deferred/Deferred0.comp"
