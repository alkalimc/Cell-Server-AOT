#version 450

#include "/programs/composite/Composite14.frag"
