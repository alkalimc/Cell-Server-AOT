#version 450

#include "/programs/composite/Composite10.frag"
