#version 450

#define ENTITIES
#define SHADOW_AND_SKY
#define TRANSPARENT

#include "/programs/gbuffers/Shadow.geom"
