#version 450

#include "/programs/deferred/Deferred2.frag"
